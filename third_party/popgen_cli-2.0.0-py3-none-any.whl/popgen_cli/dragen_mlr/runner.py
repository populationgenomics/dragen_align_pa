import os
import logging
import popgen_cli.utils.utils as utils
import json
import time
import argparse
import gzip


class MachineLearningRecalibrationRunner:

    default_mimalloc_path = '/usr/local/lib64/libmimalloc.so'
    default_dragen_path = '/opt/edico/bin/dragen'
    default_lic_creds_path = '/opt/edico/creds/dragen_sw_license_popgen.cfg'
    default_instance_id_loc_option = '--lic-instance-id-location /opt/instance-identity'
    default_bcftools_path = '/usr/local/bin/bcftools'
    default_local_gvcf_qc_bin_path = '/opt/gvcf-qc/bin/gvcf_qc'
    default_shard_list_path = '/opt/edico/resources/gg/shards.hg38.3366.102.1.1.list'
    default_num_threads = 16
    default_scratch_dir = '/scratch'
    default_min_qual = 3
    default_bin_memory = -1
    default_track_variants = True
    output_sup_dir_basename = 'supplemental'
    output_time_log_basename = 'dragen.time_log.txt'
    default_v9_hg38_alt_masked_graph_v2_hashtable_file_basename_list = [
        "anchored_rna/hash_table.cfg", "anchored_rna/hash_table.cfg.bin",
        "anchored_rna/hash_table.cmp", "anchored_rna/hash_table_stats.txt", "anchored_rna/mask.bed",
        "anchored_rna/pop_alt_liftover.sam.gz", "anchored_rna/ref_index.bin",
        "anchored_rna/ref_pop_snps.bin", "anchored_rna/reference.bin",
        "anchored_rna/repeat_mask.bin", "anchored_rna/str_table.bin", "hash_table.cfg",
        "hash_table.cfg.bin", "hash_table.cmp", "hash_table_stats.txt", "kmer_cnv.bin", "mask.bed",
        "pop_alt_liftover.sam.gz", "ref_index.bin", "ref_pop_snps.bin", "reference.bin",
        "repeat_mask.bin", "run_dragen-NA-suite10060822-stage1-replay.json",
        "run_dragen-NA-suite10060822-stage1.client_profile.csv",
        "run_dragen-NA-suite10060822-stage1.time_metrics.csv", "str_table.bin",
        "streaming_log_svc_jenkins_dragen.csv",
    ]

    def __init__(
        self,
        project_config_dict,
        job_config_dict,
        mimalloc_path=default_mimalloc_path,
        dragen_path=default_dragen_path,
        lic_creds_path=default_lic_creds_path,
        num_threads=default_num_threads,
        scratch_dir=default_scratch_dir,
        min_qual=default_min_qual,
        bin_memory=default_bin_memory,
        track_variants=default_track_variants
    ):

        self.mimalloc_path = mimalloc_path
        self.dragen_path = dragen_path
        self.lic_creds_path = lic_creds_path
        self.num_threads = num_threads or os.cpu_count()-1
        self.scratch_dir = scratch_dir
        self.min_qual = min_qual
        self.bin_memory = bin_memory
        self.track_variants = track_variants
        self.is_aws_ec2 = utils.is_aws_ec2()
        self.instance_id_loc_option = self.default_instance_id_loc_option if self.is_aws_ec2 else ""

        self.retry_runner = utils.RetryRunner()
        self.ica_client = utils.ICAClient(
            api_key=project_config_dict['ica_api_key'], retry_runner=self.retry_runner)
        self.downloader = utils.ICADownloader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)
        self.uploader = utils.ICAUploader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)

        self.ica_client._set_cache_using_project_config(
            project_config_dict=project_config_dict)
        for _project_details, _project_data_details in job_config_dict['project_data_list']:
            self.ica_client._set_cache_using_project_data(
                project_details=_project_details, project_data_details=_project_data_details)

        self.region_name = project_config_dict['ica_region']['code']
        self.storage_bundle_name = project_config_dict['ica_storage_bundle']['bundleName']
        if project_config_dict['ica_storage_configuration'] == None:
            self.storage_configuration_name = None
        else:
            self.storage_configuration_name = project_config_dict['ica_storage_configuration']['name']

        self.project_prefix = project_config_dict['ica_job_project']['name'].rstrip(
            '-jobs')
        self.config_project_name = f'{self.project_prefix}-jobs'

        self.input_dir = f'{self.scratch_dir}/input'
        self.output_dir = f'{self.scratch_dir}/output'
        self.sup_dir = f'{self.output_dir}/{self.output_sup_dir_basename}'
        self.time_log = f'{self.sup_dir}/{self.output_time_log_basename}'

        self.sample_id = None
        self.output_project_details = None
        self.output_project_data_folder_details = None

        # input and output file name convention
        self.output_gvcf_suffix = 'hard-filtered.recal.gvcf.gz'
        self.output_csv_suffix = 'hard-filtered.recal.gvcfqc-shard-metrics.csv'

        # TODO: download into this folder
        self.ref_dir = f'{self.input_dir}/ref/hg38_alt_masked_graph_v2/DRAGEN/9'
        self.input_is_cram = True
        self.input_align_path = None
        self.input_align_index_path = None
        self.input_gvcf_path = None
        self.input_gvcf_index_path = None

    def run(
        self,
        sample_id,
        input_ht_folder_url,
        output_folder_url,
        input_align_file_url,
        input_align_index_url,
        input_gvcf_file_url,
        input_gvcf_index_url,
    ):

        # prepare output in case of error do not start the job
        self.prep_output(output_folder_url)

        self.download(
            input_ht_folder_url=input_ht_folder_url,
            input_align_file_url=input_align_file_url,
            input_align_index_url=input_align_index_url,
            input_gvcf_file_url=input_gvcf_file_url,
            input_gvcf_index_url=input_gvcf_index_url)

        ecode = self.process(sample_id)
        if ecode:
            logging.error(f'DRAGEN MLR failed with exit code {ecode}, '
                          f'uploading data now for investigation')

        self.upload(output_folder_url)
        return ecode

    def prep_output(self, output_folder_url):

        # output folder url string is checked at job submission
        # expected output project folder ica://project-name/root-folder-name/subfolder-1/subfolder-2/output-folder/
        scheme, project_name, project_data_path = utils.parse_url(
            output_folder_url)

        print(f'Get/Create output project "{project_name}"')
        self.output_project_details = self.ica_client.get_or_create_project(
            project_name=project_name,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        print(
            f'Get/Create output project data "{project_data_path}"')
        self.output_project_data_folder_details = self.ica_client.get_or_create_project_data(
            project_name=project_name,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name,
            project_data_path=project_data_path,
            project_data_type='FOLDER')

        # cache the details
        self.ica_client._set_cache_using_project_data(
            project_details=self.output_project_details,
            project_data_details=self.output_project_data_folder_details)

    def download(
            self,
            input_ht_folder_url,
            input_align_file_url,
            input_align_index_url,
            input_gvcf_file_url,
            input_gvcf_index_url):

        time_start = time.time()

        # data to download
        # - input gvcf + index
        # - input cram/bam + index
        # - whole reference folder
        # ica://use1-popgen-cli-release-demo/data/ref/hashtable/hg38_alt_masked_graph_v2/DRAGEN/9/

        # support ica:// and http(s):// (psURL)
        align_basename = os.path.basename(input_align_file_url.split('?')[0])
        align_index_basename = os.path.basename(
            input_align_index_url.split('?')[0])

        gvcf_basename = os.path.basename(input_gvcf_file_url.split('?')[0])
        gvcf_index_basename = os.path.basename(
            input_gvcf_index_url.split('?')[0])

        self.input_is_cram = bool(align_basename.endswith('.cram'))
        self.input_align_path = f'{self.input_dir}/data/{align_basename}'
        self.input_align_index_path = f'{self.input_dir}/data/{align_index_basename}'
        self.input_gvcf_path = f'{self.input_dir}/data/{gvcf_basename}'
        self.input_gvcf_index_path = f'{self.input_dir}/data/{gvcf_index_basename}'

        ica_url_list = [
            input_align_file_url,
            input_align_index_url,
            input_gvcf_file_url,
            input_gvcf_index_url,
        ]
        local_path_list = [
            self.input_align_path,
            self.input_align_index_path,
            self.input_gvcf_path,
            self.input_gvcf_index_path,
        ]

        # add files in reference hash table
        input_ht_folder_url = input_ht_folder_url.rstrip('/')
        for f in self.default_v9_hg38_alt_masked_graph_v2_hashtable_file_basename_list:
            ica_url_list.append(f'{input_ht_folder_url}/{f}')
            local_path_list.append(f'{self.ref_dir}/{f}')

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # touch index for tabix and bcftools
        utils.run_command(
            f'touch {self.input_align_index_path} {self.input_gvcf_index_path}')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Download is done in {time_delta} seconds.')

    def process(self, sample_id):

        time_start = time.time()
        self.sample_id = sample_id

        # prepare local output folder
        utils.run_command(f'rm -fr {self.output_dir}')
        utils.prep_output_folder(self.output_dir)
        utils.prep_output_folder(self.sup_dir)

        # run ML recalibration
        ecode = self._run_dragen_mlr()
        if ecode:
            return ecode

        # rename the sample ID inside output gVCF if necessary
        self._run_rename_gvcf()

        # run gVCF QC and generate per shard metrics csv file for IGG
        if self.track_variants:
            ecode = self._run_gvcf_qc()
            if ecode:
                return ecode

        output_file_list = [
            f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}',
            f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}.tbi',
        ]
        if self.track_variants:
            output_file_list.append(
                f'{self.sup_dir}/{self.sample_id}.{self.output_csv_suffix}')

        # move output and add md5sum
        utils.stage_output_data(output_file_list, self.output_dir)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Process is done in {time_delta} seconds.')

        return utils.success_exit(f'DRAGEN Machine Learning Recalibration is successfully done.')

    def upload(self, output_folder_url):

        time_start = time.time()

        self.uploader.upload(
            local_dir=self.output_dir,
            ica_url=output_folder_url,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Upload is done in {time_delta} seconds.')

    def _run_dragen_mlr(self):

        # example options used in UKB, AGD, ...
        # --sw-mode
        # --lic-credentials /scratch/output/supplemental/fcac66a0e60048e7b810176c3cb26e49.cfg
        # --lic-instance-id-location /opt/instance-identity
        # --enable-map-align false
        # --enable-sort false
        # --logging-to-output-dir true
        # --qc-enable-depth-metrics false
        # --vc-run-dragstr false
        # --enable-ploidy-estimator false
        # --enable-performance-monitoring true
        # --vc-enable-profile-stats true
        # --ref-dir /scratch/input/ref
        # --bam-input /scratch/input/data/NA12878.bam
        # --ml-recalibration-input-vcf /scratch/input/data/NA12878.hard-filtered.gvcf.gz
        # --output-directory /scratch/output/supplemental
        # --output-file-prefix NA12878
        # --num-threads 16
        # --vc-ml-enable-treelite true
        # --vc-max-callable-region-memory-usage 50000000
        # (--bin_memory, default = 20*1024**3)

        input_align_option = '--cram-input' if self.input_is_cram else '--bam-input'
        bin_memory_option = '' if self.bin_memory == - \
            1 else f'--bin_memory {self.bin_memory}'

        mlr_cmd_log = [
            f'LD_PRELOAD={self.mimalloc_path}',
            f'/usr/bin/time -v -a -o {self.time_log}',
            f'{self.dragen_path}',
            f'--sw-mode',
            f'--enable-map-align false',
            f'--enable-sort false',
            f'--logging-to-output-dir true',
            f'--qc-enable-depth-metrics false',
            f'--vc-run-dragstr false',
            f'--enable-ploidy-estimator false',
            f'--enable-performance-monitoring true',
            f'--vc-enable-profile-stats true',
            f'--ref-dir {self.ref_dir}',
            f'{input_align_option} {self.input_align_path}',
            f'--ml-recalibration-input-vcf {self.input_gvcf_path}',
            f'--output-directory {self.sup_dir}',
            f'--output-file-prefix {self.sample_id}',
            f'--num-threads {self.num_threads}',
            f'--vc-ml-enable-treelite true',
            f'--vc-max-callable-region-memory-usage 50000000',
            f'{bin_memory_option}'
        ]

        mlr_cmd = mlr_cmd_log + [
            f'--lic-credentials {self.lic_creds_path}',
            f'{self.instance_id_loc_option}',
        ]

        ecode = utils.run_command(mlr_cmd, command_log=mlr_cmd_log)
        if ecode:
            logging.error(
                f'DRAGEN MLR failed with exit code {ecode}, cmd = "{mlr_cmd_log}", '
                f'early exit now.')

        # rename the gvcf with recal
        utils.run_command(
            f'mv -v {self.sup_dir}/{self.sample_id}.hard-filtered.gvcf.gz '
            f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}')
        utils.run_command(
            f'mv -v {self.sup_dir}/{self.sample_id}.hard-filtered.gvcf.gz.tbi '
            f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}.tbi')

        return 0

    def _run_rename_gvcf(self):

        # DRAGEN MLR code is very old and low priority to add new features like rename sample
        # inside gvcf, this could have been done in DRAGEN MLR instead ...
        output_gvcf = f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}'

        # get sample name
        input_sample_name = None
        for line in gzip.open(output_gvcf, 'rt'):
            line = line.strip()
            if line[:2] == '##':
                continue
            if line[0] == '#':
                data = line.split()
                input_sample_name = data[9]
                break

        if input_sample_name == self.sample_id:
            logging.info(
                f'No need to rename sample name "{self.sample_id}" in {output_gvcf}')
            return

        logging.info(
            f'Rename sample name from "{input_sample_name}" to "{self.sample_id}" '
            f'in {output_gvcf}')

        reheader_file_path = output_gvcf + '.header.txt'
        utils.prep_output_file(reheader_file_path)
        fout = open(reheader_file_path, 'w')
        print(input_sample_name, self.sample_id, file=fout)
        fout.close()

        # rehead and change sample id
        utils.run_command(
            f'{self.default_bcftools_path} reheader -s {reheader_file_path} -o {output_gvcf}.tmp '
            f'{output_gvcf}')
        # overwrite original gvcf with reheaded gvcf
        utils.run_command(
            f'mv -v {output_gvcf}.tmp {output_gvcf}')
        utils.run_command(
            f'tabix -f {output_gvcf}')
        utils.run_command(
            f'rm {reheader_file_path}')

    def _run_gvcf_qc(self):

        # set -o pipefail && LD_PRELOAD=/usr/local/lib64/libmimalloc.so
        # /usr/bin/time -v -a -o /scratch/output/supplemental/NA12878.gvcf-qc-run.time.txt
        # /opt/gvcf-qc/bin/gvcf_qc
        # -i /scratch/input/data/NA12878.hard-filtered.gvcf.gz
        # -o /scratch/output/supplemental/NA12878.hard-filtered.gvcfqc-shard-metrics.csv
        # --remove-nonref
        # --min-qual 3.0
        # -r @/scratch/input/data/shards.hg38.3366.102.1.1.txt
        # --threads 16 2>&1 | tee -a /scratch/output/supplemental/NA12878.gvcf-qc-run.txt

        output_gvcf = f'{self.sup_dir}/{self.sample_id}.{self.output_gvcf_suffix}'
        output_csv = f'{self.sup_dir}/{self.sample_id}.{self.output_csv_suffix}'

        qc_cmd = [
            f'LD_PRELOAD={self.mimalloc_path}',
            f'/usr/bin/time -v -a -o {self.time_log}',
            f'{self.default_local_gvcf_qc_bin_path}',
            f'-i {output_gvcf}',
            f'-o {output_csv}',
            f'--remove-nonref',
            f'--min-qual {self.min_qual}',
            f'-r @{self.default_shard_list_path}',
            f'--threads {self.num_threads}',
        ]
        ecode = utils.run_command(qc_cmd)
        if ecode:
            logging.error(
                f'GVCF QC failed with exit code {ecode}, cmd = "{qc_cmd}", early exit now.')
        return ecode


def parse_args():

    usage = f"""
  dragen-mlr-runner [args]

description:
  run Machine Learning Recalibration locally

"""
    parser = argparse.ArgumentParser(
        usage=usage, formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument('--job-def-str', required=True,
                        help='Job definition string [required]')

    parser.add_argument('--job-secret-file', required=True,
                        help='Job secret file [required]')

    parser.add_argument('-v', '--version', action='version',
                        version=f'Version: {utils.get_package_version()}')

    return parser.parse_args()


def main():

    time_start = time.time()

    utils.config_logging()

    args = parse_args()
    job_config_dict = utils.b64str_to_json(args.job_def_str)
    project_config_dict = utils.read_json(args.job_secret_file)

    _project_config_dict = {k: v for k, v in project_config_dict.items()}
    _project_config_dict['ica_api_key'] = '******'
    logging.info(
        f'MLR project configuration: {json.dumps(_project_config_dict, indent=2)}')
    logging.info(
        f'MLR job configuration: {json.dumps(job_config_dict, indent=2)}')

    runner = MachineLearningRecalibrationRunner(
        project_config_dict=project_config_dict,
        job_config_dict=job_config_dict,
        num_threads=job_config_dict['num_threads'],
        min_qual=job_config_dict['min_qual'],
        bin_memory=job_config_dict['bin_memory'],
        track_variants=job_config_dict['track_variants'])
    ecode = runner.run(
        sample_id=job_config_dict['sample_id'],
        input_ht_folder_url=job_config_dict['input_ht_folder_url'],
        output_folder_url=job_config_dict['output_folder_url'],
        input_align_file_url=job_config_dict['input_align_file_url'],
        input_align_index_url=job_config_dict['input_align_index_url'],
        input_gvcf_file_url=job_config_dict['input_gvcf_file_url'],
        input_gvcf_index_url=job_config_dict['input_gvcf_index_url'])

    time_end = time.time()
    time_delta = '{0:.3f}'.format(time_end - time_start)

    if ecode == 0:
        logging.info(f'::::::: ALL DONE (in {time_delta} seconds) :::::::')
    else:
        raise Exception(
            f'*ERROR* Program failed with exit code {ecode} (see details in logs above)')


if __name__ == '__main__':

    main()
