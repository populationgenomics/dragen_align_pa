from __future__ import annotations
import popgen_cli.utils.utils as utils
import popgen_cli.dragen_mlr.config as config
import popgen_cli.dragen_mlr.submit as submit
import argparse


def parse_args(sys_args):

    usage = f"""
  {utils.get_package_name()} dragen-mlr [action] [args]

description:
  manage Machine Learning Recalibration workflow

available actions:
  config      config Machine Learning Recalibration project and pipeline
  submit      submit Machine Learning Recalibration analysis

"""

    parser = argparse.ArgumentParser(usage=usage)
    parser.add_argument(
        'action', metavar='action',
        help='actions to manage Machine Learning Recalibration workflow, see actions above')

    return parser.parse_args(sys_args[1:2])


def main(sys_args):

    args = parse_args(sys_args)

    if args.action == 'config':
        config.main(sys_args[2:])

    elif args.action == 'submit':
        submit.main(sys_args[2:])

    else:
        print(
            f'*ERROR* dragen-mlr workflow action "{args.action}" is not supported.')
