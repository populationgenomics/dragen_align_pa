import sys
import argparse
import popgen_cli.dragen_igg.main as dragen_igg_main
import popgen_cli.dragen_mlr.main as dragen_mlr_main
import popgen_cli.utils.utils as utils


def main():

    usage = f"""
  {utils.get_package_name()} [workflow] [action] [args]

description:
  command line interface for running DRAGEN PopGen workflows in ICA

available workflows:
  dragen-igg     manage DRAGEN Iterative Gvcf Genotyper workflows
  dragen-mlr     manage DRAGEN Machine Learning Recalibration workflows

"""

    parser = argparse.ArgumentParser(usage=usage)
    parser.add_argument('workflow_name', metavar='workflow-name',
                        help='PopGen workflow to manage, see available workflows above')
    parser.add_argument(
        '-v', '--version', action='version',
        version=f'Version: {utils.get_package_version()}')
    args = parser.parse_args(sys.argv[1:2])

    if args.workflow_name == 'dragen-igg':
        dragen_igg_main.main(sys.argv[1:])

    elif args.workflow_name == 'dragen-mlr':
        dragen_mlr_main.main(sys.argv[1:])

    else:
        print(f'*ERROR* workflow "{args.workflow_name}" is not supported.')


if __name__ == '__main__':

    main()
