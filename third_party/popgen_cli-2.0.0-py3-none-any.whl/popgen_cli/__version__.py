"""Version information."""
__version__ = "2.0.0"
__git_version__ = "2.0.0"
__docker_tag__ = "2.0.0"
