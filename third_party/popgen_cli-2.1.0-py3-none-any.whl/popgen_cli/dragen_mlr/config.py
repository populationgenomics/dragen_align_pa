import argparse
import popgen_cli.utils.utils as utils


welcome_message = """
=======================================
    Welcome to Illumina PopGen CLI
=======================================

Let us configure a PopGen DRAGEN Machine Learning Recalibration project.

A few notes:
- You may use this command to reconfigure an existing PopGen DRAGEN MLR project
  (e.g. to deploy the pipeline with a new version).
- Please hit enter to choose the default value suggested (e.g. [default: abc]).
- To exit at any time, type Ctrl-D.

"""


def configure():

    print(welcome_message)

    # add dragen version if multiple dragen versions are supported
    # leave it empty if only one dragen version is supported, as defined in the dockrfile
    dragen_version_list = []

    config = utils.ICAConfig(
        workflow_name='dragen-mlr',
        dragen_version_list=dragen_version_list)

    config.run()


def parse_args(sys_args):

    package_name = utils.get_package_name()

    usage = f"""
  {package_name} dragen-mlr config [args]

description:
  interatively configure an Machine Learning Recalibration project

"""
    parser = argparse.ArgumentParser(
        usage=usage, formatter_class=argparse.RawTextHelpFormatter)
    args = parser.parse_args(sys_args)

    return args


def main(sys_args):

    # parse args
    args = parse_args(sys_args)

    # interactive configuration
    configure()
