import os
import logging
import popgen_cli.utils.utils as utils
import popgen_cli.dragen_igg.utils_igg as utils_igg
import json
import time
import argparse


class AggregateGvcfRunner:

    default_mimalloc_path = '/usr/local/lib64/libmimalloc.so'
    default_dragen_path = '/opt/edico/bin/dragen'
    default_lic_creds_path = '/opt/edico/creds/dragen_sw_license_popgen.cfg'
    default_num_threads = 36
    default_bcftools_path = '/usr/local/bin/bcftools'
    # TODO: change this to igg function
    default_python_path = 'python3'
    default_compare_var_script_path = '/opt/qc-scripts/src/compare/compare_vartrack.py'
    default_instance_id_loc_option = '--lic-instance-id-location /opt/instance-identity'
    default_scratch_dir = '/scratch'

    config_ref_url_basename = 'ref.csv'
    config_shard_list_basename = 'shards.txt'
    config_gvcf_version_basename = 'gvcf-version.txt'

    output_cohort_basename = 'dragen.cht.gz'
    output_census_basename = 'dragen.cns.gz'
    output_region_basename = 'dragen.reg.gz'
    output_vartrack_basename = 'dragen.VarTrackDiff.log'
    output_compare_vartrack_basename = 'dragen.CompareVarTrack.log'
    output_time_log_basename = 'dragen.time_log.txt'
    output_sup_dir_basename = 'supplemental'

    def __init__(
        self,
        project_config_dict,
        job_config_dict,
        mimalloc_path=default_mimalloc_path,
        dragen_path=default_dragen_path,
        lic_creds_path=default_lic_creds_path,
        num_threads=default_num_threads,
        bcftools_path=default_bcftools_path,
        python_path=default_python_path,
        compare_var_script_path=default_compare_var_script_path,
        scratch_dir=default_scratch_dir,
    ):
        # ica_config has following keys
        # - api_key: str
        # - project_prefix: str
        # - num_shards: int
        # - region: dict
        # - storage_bundle: dict
        # - storage_configuration: dict
        # - config_project: dict
        # - cohort_census_project: dict

        self.mimalloc_path = mimalloc_path
        self.dragen_path = dragen_path
        self.lic_creds_path = lic_creds_path
        self.num_threads = num_threads or os.cpu_count()
        self.bcftools_path = bcftools_path
        self.python_path = python_path
        self.compare_var_script_path = compare_var_script_path
        self.is_aws_ec2 = utils.is_aws_ec2()
        self.instance_id_loc_option = self.default_instance_id_loc_option if self.is_aws_ec2 else ""
        self.scratch_dir = scratch_dir

        self.retry_runner = utils.RetryRunner()
        self.ica_client = utils.ICAClient(
            api_key=project_config_dict['ica_api_key'], retry_runner=self.retry_runner)
        self.downloader = utils.ICADownloader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)
        self.uploader = utils.ICAUploader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)

        self.ica_client._set_cache_using_project_config(
            project_config_dict=project_config_dict)
        for _project_details, _project_data_details in job_config_dict['project_data_list']:
            self.ica_client._set_cache_using_project_data(
                project_details=_project_details, project_data_details=_project_data_details)

        self.region_name = project_config_dict['ica_region']['code']
        self.storage_bundle_name = project_config_dict['ica_storage_bundle']['bundleName']
        if project_config_dict['ica_storage_configuration'] == None:
            self.storage_configuration_name = None
        else:
            self.storage_configuration_name = project_config_dict['ica_storage_configuration']['name']

        self.project_prefix = project_config_dict['ica_job_project']['name'].rstrip(
            '-jobs')
        self.config_project_name = f'{self.project_prefix}-jobs'
        self.cohort_census_project_name = f'{self.project_prefix}-cohort-census'

        self.input_dir = f'{self.scratch_dir}/input'
        self.output_dir = f'{self.scratch_dir}/output'

        # to update once we get the data
        self.num_shards = 0
        # gvcf dragen version [major, minor, patch] patch can be string like 4u-1-g4ad24553
        self.gvcf_version = [None, None, None]
        self.ref_fasta_path = f'{self.input_dir}/data/ref/ref.fa'
        self.gvcf_list_path = f'{self.input_dir}/data/gvcf/gvcf.list'
        self.vartrack_list_path = f'{self.input_dir}/data/vartrack/vartrack.list'

    def run(self, batch_id, shard_id, min_qual, track_variants):

        self.download(batch_id, shard_id, track_variants)
        ecode = self.process(shard_id, min_qual, track_variants)
        if ecode:
            logging.error(f'AggregateGvcfRunner failed with exit code {ecode}, '
                          f'uploading data now for investigation')
        self.upload(batch_id, shard_id)
        return ecode

    def download(self, batch_id, shard_id, track_variants):

        time_start = time.time()

        # download config project meta data
        metadata_file_list = [
            f'meta/config/{self.config_shard_list_basename}',
            f'meta/config/{self.config_ref_url_basename}',
            f'meta/config/{self.config_gvcf_version_basename}',
            f'meta/batch-gvcf/batch-{batch_id}.gvcfs.csv',
        ]
        if track_variants:
            metadata_file_list.append(
                f'meta/batch-gvcf-qc-metrics/batch-{batch_id}.gvcf-qc-metrics.csv')

        ica_url_list = []
        local_path_list = []
        for f in metadata_file_list:
            ica_url_list.append(f'ica://{self.config_project_name}/{f}')
            local_path_list.append(f'{self.input_dir}/{f}')

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get input gVCF version
        with open(f'{self.input_dir}/meta/config/{self.config_gvcf_version_basename}', 'rt') as fin:
            self.gvcf_version = fin.read().strip().split('.')
            if len(self.gvcf_version) != 3 or None in self.gvcf_version or '' in self.gvcf_version:
                raise Exception(
                    f'Expected 3 fields from gVCF version file (major.minor.patch), '
                    f'found {self.gvcf_version}, '
                    f'please check "ica://{self.config_project_name}/meta/config/'
                    f'{self.config_gvcf_version_basename}"')
        logging.info(
            f'Read input gVCF version = {self.gvcf_version} from '
            f'"{self.input_dir}/meta/config/{self.config_gvcf_version_basename}"')

        # get number of shards
        shards_list = f'{self.input_dir}/meta/config/{self.config_shard_list_basename}'
        self.num_shards = 0
        with open(shards_list, 'rt') as fin:
            for line in fin:
                self.num_shards += 1
        logging.info(
            f'Read #shards = "{self.num_shards}" from shard list "{shards_list}"')

        # download reference fasta
        ica_url_list = []
        local_path_list = []
        with open(f'{self.input_dir}/meta/config/{self.config_ref_url_basename}', 'rt') as fin:
            for line in fin:
                data = line.strip().split(',')
                if len(data) == 1:
                    ref_url = data[0]
                    ref_idx_url = data[0] + '.fai'
                elif len(data) == 2:
                    ref_url, ref_idx_url = data
                else:
                    raise Exception(
                        f'Expected 1 or 2 fields from reference url csv, found {len(data)}, '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                if not ref_url.startswith('ica://') or not ref_idx_url.startswith('ica://'):
                    raise Exception(
                        f'Reference fasta needs to be in ICA project, with URL starting with "ica://" '
                        f'found "{ref_url}" and "{ref_idx_url}", '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                ica_url_list.extend([ref_url, ref_idx_url])
                local_path_list.extend(
                    [self.ref_fasta_path, self.ref_fasta_path+'.fai'])

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get download region
        shard_region_csv = None
        with open(shards_list, 'rt') as fin:
            for line in fin:
                data = line.strip().split()
                if int(data[0]) == shard_id:
                    shard_region_csv = data[1]
        if shard_region_csv == None:
            raise Exception(
                f'Shard "{shard_id}" is not found in shard list, '
                f'please check "ica://{self.config_project_name}/meta/config/'
                f'{self.config_shard_list_basename}"')

        # read input gVCF list, generate presign urls, handle tbi or csi
        url_list = []
        ngvcf = 0
        with open(f'{self.input_dir}/meta/batch-gvcf/batch-{batch_id}.gvcfs.csv', 'rt') as fin:
            for line in fin:
                data = line.strip().split(',')
                if len(data) == 1:
                    # only gVCF URL is provided, need to derive gVCF index URL
                    gvcf_url = data[0]
                    if gvcf_url.startswith('ica://'):
                        gvcf_idx_url = data[0] + '.tbi'

                    elif gvcf_url.startswith('https://') or gvcf_url.startswith('http://'):
                        if not '?' in gvcf_url:
                            # public static http based URL, rare but possible such as 1KG
                            gvcf_idx_url = data[0] + '.tbi'
                        else:
                            # only presigned URL of gVCF is given, tabix is missing
                            raise Exception(
                                f'Only presigned URL of gVCF is found, missing presigned URL of '
                                f'gVCF index file, please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                                f'batch-{batch_id}.gvcfs.csv", gVCF URL: "{gvcf_url}"')
                    else:
                        raise Exception(
                            f'Input gVCF schema is not one of the supported ("http://", "https://", "ica://"), '
                            f'please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                            f'batch-{batch_id}.gvcfs.csv", gVCF URL: "{gvcf_url}"')

                elif len(data) == 2:
                    gvcf_url = data[0]
                    gvcf_idx_url = data[1]
                    idx_type = gvcf_idx_url.split('?')[0].split('.')[-1]
                    if idx_type not in {'tbi', 'csi'}:
                        raise Exception(
                            f'Input gVCF index type "{idx_type}" not one of the supported ("tbi", "csi"), '
                            f'please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                            f'batch-{batch_id}.gvcfs.csv", gVCF URL: "{gvcf_url}"')

                    if not gvcf_url.startswith('ica://') and not gvcf_url.startswith('http://') \
                            and not gvcf_url.startswith('https://'):
                        raise Exception(
                            f'Input gVCF file schema is not one of the supported ("http://", "https://", "ica://"), '
                            f'please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                            f'batch-{batch_id}.gvcfs.csv", gVCF URL: "{gvcf_url}"')

                    if not gvcf_idx_url.startswith('ica://') and not gvcf_idx_url.startswith('http://') \
                            and not gvcf_idx_url.startswith('https://'):
                        raise Exception(
                            f'Input gVCF index file schema is not one of the supported ("http://", "https://", "ica://"), '
                            f'please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                            f'batch-{batch_id}.gvcfs.csv", gVCF index URL: "{gvcf_idx_url}"')

                else:
                    # input line format is not correct
                    raise Exception(
                        f'Expected 1 or 2 fields from gvcf url csv, found {len(data)}, '
                        f'please check "ica://{self.config_project_name}/meta/batch-gvcf/'
                        f'batch-{batch_id}.gvcfs.csv", input line: "{line.strip()}"')

                url_list.append([gvcf_url, gvcf_idx_url])
                ngvcf += 1

        logging.info(
            f'Found {ngvcf} gVCF files from batch gVCF list '
            f'"{self.input_dir}/meta/batch-gvcf/batch-{batch_id}.gvcfs.csv"')

        # presign ica based input
        ica_url_list = []
        for gvcf_url, gvcf_idx_url in url_list:
            if gvcf_url.startswith('ica://'):
                ica_url_list.append(gvcf_url)
            if gvcf_idx_url.startswith('ica://'):
                ica_url_list.append(gvcf_idx_url)
        presign_url_dict = self.downloader.presign(ica_url_list=ica_url_list)

        # at this point, all urls are http(s) based, prepare parital download and write local gVCF list
        remote_file_url_list = []
        remote_index_url_list = []
        local_file_path_list = []
        utils.prep_output_file(self.gvcf_list_path)
        fout = open(self.gvcf_list_path, 'wt')
        for gvcf_url, gvcf_idx_url in url_list:
            if gvcf_url.startswith('ica://'):
                gvcf_size, gvcf_url = presign_url_dict[gvcf_url]
            if gvcf_idx_url.startswith('ica://'):
                gvcf_idx_size, gvcf_idx_url = presign_url_dict[gvcf_idx_url]
            remote_file_url_list.append(gvcf_url)
            remote_index_url_list.append(gvcf_idx_url)

            _file_base = gvcf_url.split('?')[0].split('/')[-1]
            _local_path = f'{self.input_dir}/data/gvcf/{_file_base}'
            local_file_path_list.append(_local_path)
            print(_local_path, file=fout)
        fout.close()

        # concurrently partial download input gVCFs using bcftools
        utils_igg.download_using_bcftools_concurrent(
            bcftools_path=self.bcftools_path,
            remote_file_url_list=remote_file_url_list,
            remote_index_url_list=remote_index_url_list,
            local_file_path_list=local_file_path_list,
            region_csv=shard_region_csv)

        logging.info(
            f'Partially downloaded {len(local_file_path_list)} input gVCF files, '
            f'in region {shard_region_csv}.')

        # check gvcf version in each gvcf file
        for local_file_path in local_file_path_list:
            gvcf_version = utils_igg.get_gvcf_dragen_version(gvcf_path=local_file_path)
            if gvcf_version[0] != self.gvcf_version[0] or gvcf_version[1] != self.gvcf_version[1]:
                raise Exception(
                    f'Input gVCF major and minor version in version {gvcf_version} '
                    f'of gvcf file {local_file_path} do not match '
                    f'global gVCF version {self.gvcf_version} in '
                    f'"ica://{self.config_project_name}/meta/config/{self.config_gvcf_version_basename}"')

        if track_variants:
            ica_url_list = []
            local_path_list = []
            nfile = 0
            utils.prep_output_file(self.vartrack_list_path)
            fout = open(self.vartrack_list_path, 'wt')
            with open(f'{self.input_dir}/meta/batch-gvcf-qc-metrics/batch-{batch_id}.gvcf-qc-metrics.csv', 'rt') as fin:
                for line in fin:
                    # treat as single field right now
                    vartrack_url = line.strip()
                    if not vartrack_url.startswith('ica://') and not vartrack_url.startswith('https://') \
                            and not vartrack_url.startswith('http://'):
                        raise Exception(
                            f'Input gVCF vartrack file schema is not one of the supported '
                            f'("http://", "https://", "ica://"), '
                            f'please check "ica://{self.config_project_name}/meta/batch-gvcf-qc-metrics/'
                            f'batch-{batch_id}.gvcf-qc-metrics.csv", file URL: "{vartrack_url}"')

                    ica_url_list.append(vartrack_url)
                    _file_base = vartrack_url.split('?')[0].split('/')[-1]
                    _local_path = f'{self.input_dir}/data/vartrack/{_file_base}'
                    local_path_list.append(_local_path)
                    print(_local_path, file=fout)

                    nfile += 1
            fout.close()

            logging.info(
                f'Found {nfile} gVCF vartrack files from batch gVCF vartrack list '
                f'"{self.input_dir}/meta/batch-gvcf-qc-metrics/batch-{batch_id}.gvcf-qc-metrics.csv"')

            if nfile != ngvcf:
                raise Exception(
                    f'Number of vartrack files ({nfile}) does not match number of gVCF files ({ngvcf}) '
                    f'please check "ica://{self.config_project_name}/meta/batch-gvcf/batch-{batch_id}.gvcfs.csv" '
                    f'and "ica://{self.config_project_name}/meta/batch-gvcf-qc-metrics/batch-{batch_id}.gvcf-qc-metrics.csv"')

            self.downloader.download(
                ica_url_list=ica_url_list, local_path_list=local_path_list)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Download is done in {time_delta} seconds.')

    def upload(self, batch_id, shard_id):

        time_start = time.time()

        out_url = f'ica://{self.cohort_census_project_name}'
        out_url += f'/data/batch-{batch_id}/shard-{shard_id}/'
        self.uploader.upload(
            local_dir=self.output_dir,
            ica_url=out_url,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Upload is done in {time_delta} seconds.')

    def process(self, shard_id, min_qual, track_variants):

        time_start = time.time()

        # prep output folder
        sup_dir = f'{self.output_dir}/{self.output_sup_dir_basename}'
        utils.run_command(f'rm -fr {self.output_dir}')
        utils.prep_output_folder(self.output_dir)
        utils.prep_output_folder(sup_dir)
        time_log = f'{sup_dir}/{self.output_time_log_basename}'

        # get dragen version specific filtering option
        # NOTE: from this point, due to DRAGEN version check, we require always DRAGEN gVCF in ICA
        filter_option = ''
        if (int(self.gvcf_version[0]) == 4 and int(self.gvcf_version[1]) >= 3) or \
                (int(self.gvcf_version[0]) >= 5):
            # starting from v4.3 there are mosaic calls in gVCF, QUAL is not enough to filter
            # these calls. VC team recommend to always use FILTER=PASS
            # IGG has one exception, that keeps TargetedConflict also as PASS
            filter_option = '--gg-vc-filter true'

        igg_cmd_log = [
            f'LD_PRELOAD={self.mimalloc_path}',
            f'/usr/bin/time -v -a -o {time_log}',
            f'{self.dragen_path}',
            f'--sw-mode',
            f'--enable-gvcf-genotyper-iterative true',
            f'--gvcfs-to-cohort-census true',
            f'--variant-list {self.gvcf_list_path}',
            f'--shard {shard_id}/{self.num_shards}',
            f'--num-threads {self.num_threads}',
            f'--logging-to-output-dir true',
            f'--output-directory {sup_dir}',
            f'--ht-reference {self.ref_fasta_path}',
            f'--gg-min-qual {min_qual}',
            f'{filter_option}',
            f'--gg-trim-indels true',
            # this option cost runtime, but it is worthwhile due to painful per batch per shard checks
            # when a broken ref allele is introduced during large scale aggregation
            # it impacts gvcf v378, a version with 500K to million gVCFs still exist
            f'--gg-filter-broken-ref true',
            f'--gg-ingest-dp true',
            # dragen_track_variants: is optional depending on input gVCF var track data availability
            # use this optional typically when MLR is enabled
            f'--gg-track-variants {"true" if track_variants else "false"}',
        ]
        igg_cmd = igg_cmd_log + [
            f'--lic-credentials {self.lic_creds_path}',
            f'{self.instance_id_loc_option}',
        ]

        ecode = utils.run_command(igg_cmd, command_log=igg_cmd_log)
        if ecode:
            return utils.early_exit(ecode, 'DRAGEN IGG aggregate gVCFs', igg_cmd_log)

        if track_variants:
            # compare variant track
            compare_cmd = [
                f'{self.python_path}',
                f'{self.compare_var_script_path}',
                f'aggregate-gvcf',
                f'{self.vartrack_list_path}',
                f'{sup_dir}/{self.output_vartrack_basename}',
                f'{shard_id}/{self.num_shards}',
                f'{sup_dir}/{self.output_compare_vartrack_basename}',
            ]
            ecode = utils.run_command(compare_cmd)
            if ecode:
                return utils.early_exit(ecode, 'Compare IGG Cohort/Census vartrack', compare_cmd)

        # make region file
        utils_igg.census_count_sample(
            cns_path=f'{sup_dir}/{self.output_census_basename}',
            message=f'[batch_census_stats] shard={shard_id},')

        # make region file
        utils_igg.census_to_region(
            cns_path=f'{sup_dir}/{self.output_census_basename}',
            reg_path=f'{sup_dir}/{self.output_region_basename}',
            message=f'[region_stats] shard={shard_id},')

        # move primary data to main output folder level
        output_file_list = [
            f'{sup_dir}/{self.output_cohort_basename}',
            f'{sup_dir}/{self.output_cohort_basename}.tbi',
            f'{sup_dir}/{self.output_census_basename}',
            f'{sup_dir}/{self.output_census_basename}.tbi',
            f'{sup_dir}/{self.output_region_basename}',
        ]
        utils.stage_output_data(output_file_list, self.output_dir)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Process is done in {time_delta} seconds.')

        return utils.success_exit(f'DRAGEN gVCF aggregation is successfully done.')


class AggregateCensusRunner:

    default_mimalloc_path = '/usr/local/lib64/libmimalloc.so'
    default_dragen_path = '/opt/edico/bin/dragen'
    default_lic_creds_path = '/opt/edico/creds/dragen_sw_license_popgen.cfg'
    default_anno_lic_creds_path = '/opt/edico/creds/nirvana_sw_license_popgen.json'
    default_num_threads = 36
    default_instance_id_loc_option = '--lic-instance-id-location /opt/instance-identity'
    default_dotnet_path = '/usr/bin/dotnet'
    default_nirvana_path = '/opt/ica-nirvana/Nirvana.dll'
    default_scratch_dir = '/scratch'

    config_ref_url_basename = 'ref.csv'
    config_shard_list_basename = 'shards.txt'
    config_annodb_list_basename = 'annodb.txt'
    config_low_conf_bed_basename = 'low-conf.bed'

    output_census_basename = 'dragen.cns.gz'
    output_region_basename = 'dragen.reg.gz'
    output_sites_vcf_basename = 'dragen.sites.vcf.gz'
    output_annojson_prefix = 'dragen.anno'
    output_time_log_basename = 'dragen.time_log.txt'
    output_subshards_stats_basename = 'dragen.subshards.stats.tsv'
    output_subshards_count_basename = 'dragen.shard.num-subshards.csv'
    output_sup_dir_basename = 'supplemental'

    def __init__(
        self,
        project_config_dict,
        job_config_dict,
        mimalloc_path=default_mimalloc_path,
        dragen_path=default_dragen_path,
        lic_creds_path=default_lic_creds_path,
        anno_lic_creds_path=default_anno_lic_creds_path,
        num_threads=default_num_threads,
        dotnet_path=default_dotnet_path,
        nirvana_path=default_nirvana_path,
        scratch_dir=default_scratch_dir,
    ):
        self.mimalloc_path = mimalloc_path
        self.dragen_path = dragen_path
        self.lic_creds_path = lic_creds_path
        self.anno_lic_creds_path = anno_lic_creds_path
        self.num_threads = num_threads or os.cpu_count()
        self.is_aws_ec2 = utils.is_aws_ec2()
        self.instance_id_loc_option = self.default_instance_id_loc_option if self.is_aws_ec2 else ""
        self.dotnet_path = dotnet_path
        self.nirvana_path = nirvana_path
        self.scratch_dir = scratch_dir

        self.retry_runner = utils.RetryRunner()
        self.ica_client = utils.ICAClient(
            api_key=project_config_dict['ica_api_key'], retry_runner=self.retry_runner)
        self.downloader = utils.ICADownloader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)
        self.uploader = utils.ICAUploader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)

        self.ica_client._set_cache_using_project_config(
            project_config_dict=project_config_dict)
        for _project_details, _project_data_details in job_config_dict['project_data_list']:
            self.ica_client._set_cache_using_project_data(
                project_details=_project_details, project_data_details=_project_data_details)

        self.region_name = project_config_dict['ica_region']['code']
        self.storage_bundle_name = project_config_dict['ica_storage_bundle']['bundleName']
        if project_config_dict['ica_storage_configuration'] == None:
            self.storage_configuration_name = None
        else:
            self.storage_configuration_name = project_config_dict['ica_storage_configuration']['name']

        self.project_prefix = project_config_dict['ica_job_project']['name'].rstrip(
            '-jobs')
        self.config_project_name = f'{self.project_prefix}-jobs'
        self.cohort_census_project_name = f'{self.project_prefix}-cohort-census'
        self.msvcf_project_prefix_name = f'{self.project_prefix}-msvcf'

        self.input_dir = f'{self.scratch_dir}/input'
        self.output_dir = f'{self.scratch_dir}/output'

        # to update once we get the data
        self.num_shards = 0
        self.ref_fasta_path = f'{self.input_dir}/data/ref/ref.fa'
        self.cns_list_path = f'{self.input_dir}/data/census/census.list'
        self.nirvana_data_dir = f'{self.input_dir}/data/nirvana'
        self.low_conf_bed_path = f'{self.input_dir}/data/bed/{self.config_low_conf_bed_basename}'

    def run(self, version_id, shard_id, run_anno, nsite_subshard, mark_low_conf):

        self.download(version_id, shard_id, run_anno, mark_low_conf)
        ecode = self.process(shard_id, run_anno, nsite_subshard, mark_low_conf)
        if ecode:
            logging.error(f'AggregateCensusRunner failed with exit code {ecode}, '
                          f'uploading data now for investigation')
        self.upload(version_id, shard_id)
        return ecode

    def download(self, version_id, shard_id, run_anno, mark_low_conf):

        time_start = time.time()

        # download meta data
        metadata_file_list = [
            f'meta/version-batch/version-{version_id}.batches.txt',
            f'meta/config/{self.config_shard_list_basename}',
            f'meta/config/{self.config_ref_url_basename}',
            f'meta/config/{self.config_annodb_list_basename}',
        ]

        ica_url_list = []
        local_path_list = []
        for f in metadata_file_list:
            ica_url_list.append(f'ica://{self.config_project_name}/{f}')
            local_path_list.append(f'{self.input_dir}/{f}')

        if mark_low_conf:
            ica_url_list.append(f'ica://{self.config_project_name}/meta/config/{self.config_low_conf_bed_basename}')
            local_path_list.append(self.low_conf_bed_path)

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get number of shards
        shards_list = f'{self.input_dir}/meta/config/{self.config_shard_list_basename}'
        self.num_shards = 0
        with open(shards_list, 'rt') as fin:
            for line in fin:
                self.num_shards += 1
        logging.info(
            f'Read #shards = "{self.num_shards}" from shard list "{shards_list}"')

        # download reference fasta
        ica_url_list = []
        local_path_list = []
        with open(f'{self.input_dir}/meta/config/{self.config_ref_url_basename}', 'rt') as fin:
            for line in fin:
                data = line.strip().split(',')
                if len(data) == 1:
                    ref_url = data[0]
                    ref_idx_url = data[0] + '.fai'
                elif len(data) == 2:
                    ref_url, ref_idx_url = data
                else:
                    raise Exception(
                        f'Expected 1 or 2 fields from reference url csv, found {len(data)}, '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                if not ref_url.startswith('ica://') or not ref_idx_url.startswith('ica://'):
                    raise Exception(
                        f'Reference fasta needs to be in ICA project, with URL starting with "ica://" '
                        f'found "{ref_url}" and "{ref_idx_url}", '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                ica_url_list.extend([ref_url, ref_idx_url])
                local_path_list.extend(
                    [self.ref_fasta_path, self.ref_fasta_path+'.fai'])

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get batch ids in this version
        batch_id_list = []
        version_batch_list = f'{self.input_dir}/meta/version-batch/version-{version_id}.batches.txt'
        with open(version_batch_list, 'rt') as fin:
            for line in fin:
                batch_id_list.append(int(line.strip()))
        logging.info(
            f'Found {len(batch_id_list)} batches from version batch list "{version_batch_list}"')

        # download census files and write census files
        ica_url_list = []
        local_path_list = []
        census_path_list = []
        utils.prep_output_file(self.cns_list_path)
        nfile = 0
        with open(self.cns_list_path, 'wt') as fout:
            for batch_id in batch_id_list:
                census_url = f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/dragen.cns.gz'
                census_idx_url = census_url + '.tbi'
                census_path = f'{self.input_dir}/data/census/batch-{batch_id}/shard-{shard_id}/dragen.cns.gz'
                census_idx_path = census_path + '.tbi'
                census_path_list.append(census_path)
                ica_url_list.extend([
                    census_url, census_url + '.md5',
                    census_idx_url, census_idx_url + '.md5'])
                local_path_list.extend([
                    census_path, census_path + '.md5',
                    census_idx_path, census_idx_path + '.md5'])
                print(os.path.realpath(census_path), file=fout)
                nfile += 1

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # check md5sum
        md5sum_check_list = []
        for census_path in census_path_list:
            md5sum_check_list.append(census_path)
            md5sum_check_list.append(census_path+'.tbi')
        utils.check_input_data_md5(md5sum_check_list)

        logging.info(
            f'Downloaded "{len(batch_id_list)}" census files and written census list "{self.cns_list_path}"')

        # touch index
        for census_idx_path in census_path_list:
            utils.run_command(f'touch {census_idx_path}.tbi')

        # download nirvana
        if not run_anno:
            return

        ica_url_list = []
        local_path_list = []
        annodb_list = f'{self.input_dir}/meta/config/{self.config_annodb_list_basename}'
        annodb_folder_url = None
        with open(annodb_list, 'rt') as fin:
            for line in fin:
                line = line.strip()
                if line.startswith('#'):
                    # the first line is important
                    # e.g. ica://use1-popgen-cli-release-demo/data2/nirvana
                    annodb_folder_url = line[1:].strip().strip('/') + '/'
                    continue
                if not line.startswith(annodb_folder_url):
                    continue
                # ica://use1-popgen-cli-release-demo/data2/nirvana/References/Homo_sapiens.GRCh38.Nirvana.dat
                ica_url_list.append(line)
                ica_url_list.append(line + '.md5')
                # /scratch/input/data/nirvana/References/...
                data_path = f'{self.nirvana_data_dir}/{line[len(annodb_folder_url):]}'
                local_path_list.append(data_path)
                local_path_list.append(data_path + '.md5')

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # check md5sum
        utils.check_input_data_md5(
            [x for x in local_path_list if not x.endswith('.md5')])

        logging.info(
            f'Downloaded "{len(local_path_list)}" files to nirvana database folder "{self.nirvana_data_dir}"')

        utils.run_command(f'find {self.nirvana_data_dir} -type f | sort')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Download is done in {time_delta} seconds.')

    def upload(self, version_id, shard_id):

        time_start = time.time()

        out_url = f'ica://{self.msvcf_project_prefix_name}-version-{version_id}'
        out_url += f'/data/global-census/shard-{shard_id}/'
        self.uploader.upload(
            local_dir=self.output_dir,
            ica_url=out_url,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Upload is done in {time_delta} seconds.')

    def process(self, shard_id, run_anno, nsite_subshard, mark_low_conf):

        time_start = time.time()

        # prep output folder
        sup_dir = f'{self.output_dir}/{self.output_sup_dir_basename}'
        utils.run_command(f'rm -fr {self.output_dir}')
        utils.prep_output_folder(self.output_dir)
        utils.prep_output_folder(sup_dir)
        time_log = f'{sup_dir}/{self.output_time_log_basename}'

        igg_cmd_log = [
            f'LD_PRELOAD={self.mimalloc_path}',
            f'/usr/bin/time -v -a -o {time_log}',
            f'{self.dragen_path}',
            f'--sw-mode',
            f'--enable-gvcf-genotyper-iterative true',
            f'--aggregate-censuses true',
            f'--variant-list {self.cns_list_path}',
            f'--shard {shard_id}/{self.num_shards}',
            f'--num-threads {self.num_threads}',
            f'--logging-to-output-dir true',
            f'--output-directory {sup_dir}',
            f'--ht-reference {self.ref_fasta_path}',
        ]
        igg_cmd = igg_cmd_log + [
            f'--lic-credentials {self.lic_creds_path}',
            f'{self.instance_id_loc_option}',
        ]

        ecode = utils.run_command(igg_cmd, command_log=igg_cmd_log)
        if ecode:
            return utils.early_exit(ecode, 'DRAGEN IGG aggregate Census files', igg_cmd_log)

        nsample1 = utils_igg.census_count_sample(
            cns_path=f'{sup_dir}/{self.output_census_basename}',
            message=f'[global_census_stats] shard={shard_id},')

        if nsample1 == 0:
            logging.error(
                f'no sample found in global census, need to check results.')
            return 1

        if nsite_subshard < 1:
            nsite_subshard = int(30*1e9 / nsample1)
        logging.info(
            f'STATS: [global_census] #sample = {nsample1}')
        logging.info(
            f'STATS: [subshard_size] max #sites per subshard = {nsite_subshard}')

        # make region file
        utils_igg.census_to_region(
            cns_path=f'{sup_dir}/{self.output_census_basename}',
            reg_path=f'{sup_dir}/{self.output_region_basename}',
            message=f'[region_stats] shard={shard_id},')

        # make sites vcf file
        npos1, nvar1 = utils_igg.census_to_sites_vcf(
            cns_path=f'{sup_dir}/{self.output_census_basename}',
            sites_vcf_path=f'{sup_dir}/{self.output_sites_vcf_basename}',
            message=f'shard={shard_id},')

        # annotate sites vcf with low confidence region
        if mark_low_conf:
            utils_igg.annotate_sites_vcf(
                sites_vcf_path=f'{sup_dir}/{self.output_sites_vcf_basename}',
                low_conf_bed_path=self.low_conf_bed_path,
                message=f'shard={shard_id},')

        # make subshard stats
        npos2, nvar2 = utils_igg.make_subshards_stats(
            shard_id=shard_id,
            in_sites_vcf_path=f'{sup_dir}/{self.output_sites_vcf_basename}',
            out_subshards_stats_path=f'{sup_dir}/{self.output_subshards_stats_basename}',
            out_subshards_count_path=f'{sup_dir}/{self.output_subshards_count_basename}',
            nsite_subshard=nsite_subshard)

        # consistency check census/sites vcf <=> subshard stats
        if npos2 != npos1 or nvar2 != nvar1:
            logging.error(
                f'#pos or #var mismatch between census ({npos1}, {nvar1}) '
                f'and sum of subshards ({npos2}, {nvar2}), need to check results.')
            return 1

        if run_anno:
            nirvana_cache_dir = f'{self.nirvana_data_dir}/Cache'
            nirvana_database_dir = f'{self.nirvana_data_dir}/SupplementaryAnnotation/GRCh38'
            nirvana_ref_path = f'{self.nirvana_data_dir}/References/Homo_sapiens.GRCh38.Nirvana.dat'

            nirvana_cmd_log = [
                f'LD_PRELOAD={self.mimalloc_path}',
                f'/usr/bin/time -v -a -o {time_log}',
                f'{self.dotnet_path}',
                f'{self.nirvana_path}',
                f'--cache {nirvana_cache_dir}',
                f'--sd {nirvana_database_dir}',
                f'--ref {nirvana_ref_path}',
                f'--in {sup_dir}/{self.output_sites_vcf_basename}',
                f'--out {sup_dir}/{self.output_annojson_prefix}',

            ]
            nirvana_cmd = nirvana_cmd_log + [
                f'--credentialsFile {self.anno_lic_creds_path}'
            ]

            ecode = utils.run_command(nirvana_cmd, command_log=nirvana_cmd_log)
            if ecode:
                return utils.early_exit(ecode, 'Nirvana annotation', nirvana_cmd_log)

            npos3 = utils_igg.anno_json_count_var(
                anno_json_path=f'{sup_dir}/{self.output_annojson_prefix}.json.gz',
                message=f'shard={shard_id},')

            # consistency check census/sites vcf <=> annotation
            if npos3 != npos1:
                logging.error(
                    f'#pos mismatch between census ({npos1}) '
                    f'and annotation json ({npos3}), need to check results.')
                return 1

        # move primary data to main output folder level
        output_file_list = [
            f'{sup_dir}/{self.output_census_basename}',
            f'{sup_dir}/{self.output_census_basename}.tbi',
            f'{sup_dir}/{self.output_region_basename}',
            f'{sup_dir}/{self.output_sites_vcf_basename}',
            f'{sup_dir}/{self.output_sites_vcf_basename}.tbi',
            f'{sup_dir}/{self.output_subshards_stats_basename}',
            f'{sup_dir}/{self.output_subshards_count_basename}',
        ]
        if run_anno:
            output_file_list.append(
                f'{sup_dir}/{self.output_annojson_prefix}.json.gz')
            output_file_list.append(
                f'{sup_dir}/{self.output_annojson_prefix}.json.gz.jsi')

        utils.stage_output_data(output_file_list, self.output_dir)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Process is done in {time_delta} seconds.')

        return utils.success_exit(f'DRAGEN Census aggregation is successfully done.')


class GenerateMsvcfRunner:

    default_mimalloc_path = '/usr/local/lib64/libmimalloc.so'
    default_dragen_path = '/opt/edico/bin/dragen'
    default_postproc_bin_path = '/opt/msvcf2bgen/bin/msvcf2bgen'
    default_postproc2_bin_path = '/opt/msvcf2bgen2/bin/msvcf2bgen'
    default_postproc_model_path = '/usr/local/share/ml-model/mlsq.485fb69.bin'
    default_plink2_path = '/usr/local/bin/plink2'
    default_bcftools_path = '/usr/local/bin/bcftools'
    default_tabix_path = '/usr/local/bin/tabix'
    default_bgzip_path = '/usr/local/bin/bgzip'
    default_lic_creds_path = '/opt/edico/creds/dragen_sw_license_popgen.cfg'
    default_num_threads = 36
    default_instance_id_loc_option = '--lic-instance-id-location /opt/instance-identity'
    default_scratch_dir = '/scratch'

    config_ref_url_basename = 'ref.csv'
    config_shard_list_basename = 'shards.txt'
    config_low_conf_bed_basename = 'low-conf.bed'

    output_vcf_basename = 'dragen.vcf.gz'
    output_sites_vcf_basename = 'dragen.sites.vcf.gz'
    output_subshards_stats_basename = 'dragen.subshards.stats.tsv'
    output_stats_vcf_basename = 'dragen.stats.vcf.gz'
    output_feature_list_basename = 'dragen.features.list.gz'
    output_pgen_prefix = 'dragen'

    output_time_log_basename = 'dragen.time_log.txt'
    output_sup_dir_basename = 'supplemental'

    def __init__(
        self,
        project_config_dict,
        job_config_dict,
        mimalloc_path=default_mimalloc_path,
        dragen_path=default_dragen_path,
        lic_creds_path=default_lic_creds_path,
        num_threads=default_num_threads,
        postproc_bin_path=default_postproc_bin_path,
        postproc2_bin_path=default_postproc2_bin_path,
        postproc_model_path=default_postproc_model_path,
        plink2_path=default_plink2_path,
        bcftools_path=default_bcftools_path,
        tabix_path=default_tabix_path,
        bgzip_path=default_bgzip_path,
        scratch_dir=default_scratch_dir,
    ):
        self.mimalloc_path = mimalloc_path
        self.dragen_path = dragen_path
        self.lic_creds_path = lic_creds_path
        self.num_threads = num_threads or os.cpu_count()
        self.is_aws_ec2 = utils.is_aws_ec2()
        self.instance_id_loc_option = self.default_instance_id_loc_option if self.is_aws_ec2 else ""
        self.postproc_bin_path = postproc_bin_path
        self.postproc2_bin_path = postproc2_bin_path
        self.postproc_model_path = postproc_model_path
        self.plink2_path = plink2_path
        self.bcftools_path = bcftools_path
        self.tabix_path = tabix_path
        self.bgzip_path = bgzip_path
        self.scratch_dir = scratch_dir

        self.retry_runner = utils.RetryRunner()
        self.ica_client = utils.ICAClient(
            api_key=project_config_dict['ica_api_key'], retry_runner=self.retry_runner)
        self.downloader = utils.ICADownloader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)
        self.uploader = utils.ICAUploader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)

        self.ica_client._set_cache_using_project_config(
            project_config_dict=project_config_dict)
        for _project_details, _project_data_details in job_config_dict['project_data_list']:
            self.ica_client._set_cache_using_project_data(
                project_details=_project_details, project_data_details=_project_data_details)

        self.region_name = project_config_dict['ica_region']['code']
        self.storage_bundle_name = project_config_dict['ica_storage_bundle']['bundleName']
        if project_config_dict['ica_storage_configuration'] == None:
            self.storage_configuration_name = None
        else:
            self.storage_configuration_name = project_config_dict['ica_storage_configuration']['name']

        self.project_prefix = project_config_dict['ica_job_project']['name'].rstrip(
            '-jobs')
        self.config_project_name = f'{self.project_prefix}-jobs'
        self.cohort_census_project_name = f'{self.project_prefix}-cohort-census'
        self.msvcf_project_prefix_name = f'{self.project_prefix}-msvcf'

        self.input_dir = f'{self.scratch_dir}/input'
        self.output_dir = f'{self.scratch_dir}/output'

        # to update once we get the data
        self.num_shards = 0
        self.ref_fasta_path = f'{self.input_dir}/data/ref/ref.fa'
        self.input_subshards_stats_path = f'{self.input_dir}/data/subshards-stats/{self.output_subshards_stats_basename}'
        self.cht_cns_csv_path = f'{self.input_dir}/data/cohort-census/batch-cohort-census-global-census.csv'
        self.gender_list_path = None
        self.subshard_region = None
        self.low_conf_bed_path = f'{self.input_dir}/data/bed/{self.config_low_conf_bed_basename}'

    def run(self, version_id, shard_id, subshard_id, mark_low_conf):

        self.download(version_id, shard_id, subshard_id, mark_low_conf)
        ecode = self.process(shard_id, subshard_id, mark_low_conf)
        if ecode:
            logging.error(f'GenerateMsvcfRunner failed with exit code {ecode}, '
                          f'uploading data now for investigation')
        self.upload(version_id, shard_id, subshard_id)
        return ecode

    def download(self, version_id, shard_id, subshard_id, mark_low_conf):

        time_start = time.time()

        # data to download
        # - shard list (job project) => total number of shards
        # - batch shard (job project) => which cohort/census to partial download
        # - gender list (job project) => used for plink2
        # - shard subshard stats (from msvcf project) => to know the subshard stats for checking
        # - full region files to determine expected #record from partial download

        # - cohort, census, global census (from cohort/census, msvcf projects)

        # download meta data
        _msvcf_project_name = f'{self.msvcf_project_prefix_name}-version-{version_id}'

        _shard_list_relpath = f'meta/config/{self.config_shard_list_basename}'
        _ref_url_relpath = f'meta/config/{self.config_ref_url_basename}'
        _version_batch_list_relpath = f'meta/version-batch/version-{version_id}.batches.txt'
        _version_gender_list_relpath = f'meta/version-gender/version-{version_id}.genders.tsv'
        self.gender_list_path = f'{self.input_dir}/{_version_gender_list_relpath}'

        metadata_file_list = [
            _shard_list_relpath,
            _ref_url_relpath,
            _version_batch_list_relpath,
            _version_gender_list_relpath,
        ]

        ica_url_list = []
        local_path_list = []
        for f in metadata_file_list:
            ica_url_list.append(f'ica://{self.config_project_name}/{f}')
            local_path_list.append(f'{self.input_dir}/{f}')

        if mark_low_conf:
            ica_url_list.append(f'ica://{self.config_project_name}/meta/config/{self.config_low_conf_bed_basename}')
            local_path_list.append(self.low_conf_bed_path)

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get number of shards
        shards_list = f'{self.input_dir}/{_shard_list_relpath}'
        self.num_shards = 0
        with open(shards_list, 'rt') as fin:
            for line in fin:
                self.num_shards += 1
        logging.info(
            f'Read #shards = "{self.num_shards}" from shard list "{shards_list}"')

        # download reference fasta
        ica_url_list = []
        local_path_list = []
        with open(f'{self.input_dir}/{_ref_url_relpath}', 'rt') as fin:
            for line in fin:
                data = line.strip().split(',')
                if len(data) == 1:
                    ref_url = data[0]
                    ref_idx_url = data[0] + '.fai'
                elif len(data) == 2:
                    ref_url, ref_idx_url = data
                else:
                    raise Exception(
                        f'Expected 1 or 2 fields from reference url csv, found {len(data)}, '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                if not ref_url.startswith('ica://') or not ref_idx_url.startswith('ica://'):
                    raise Exception(
                        f'Reference fasta needs to be in ICA project, with URL starting with "ica://" '
                        f'found "{ref_url}" and "{ref_idx_url}", '
                        f'please check "ica://{self.config_project_name}/meta/config/'
                        f'{self.config_ref_url_basename}"')
                ica_url_list.extend([ref_url, ref_idx_url])
                local_path_list.extend(
                    [self.ref_fasta_path, self.ref_fasta_path+'.fai'])

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get batch ids in this version
        batch_id_list = []
        version_batch_list = f'{self.input_dir}/{_version_batch_list_relpath}'
        with open(version_batch_list, 'rt') as fin:
            for line in fin:
                batch_id_list.append(int(line.strip()))
        logging.info(
            f'Found {len(batch_id_list)} batches from version batch list '
            f'"{version_batch_list}"')

        # download subshard stats, full region file from global census folder
        download_jobs = []
        download_jobs.append([
            f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{self.output_subshards_stats_basename}',
            f'{self.input_subshards_stats_path}',
        ])
        download_jobs.append([
            f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{self.output_subshards_stats_basename}.md5',
            f'{self.input_subshards_stats_path}.md5',
        ])

        for f in ['dragen.reg.gz', 'dragen.reg.gz.md5']:
            download_jobs.append([
                f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{f}',
                f'{self.input_dir}/data/region/global/{f}',
            ])

        # download full region file from cohort census folder
        for batch_id in batch_id_list:
            for f in ['dragen.reg.gz', 'dragen.reg.gz.md5']:
                download_jobs.append([
                    f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/{f}',
                    f'{self.input_dir}/data/region/batch-{batch_id}/{f}',
                ])

        ica_url_list = [x[0] for x in download_jobs]
        local_path_list = [x[1] for x in download_jobs]
        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        md5sum_check_list = [x[1]
                             for x in download_jobs if not x[1].endswith('.md5')]
        utils.check_input_data_md5(md5sum_check_list)

        logging.info(
            f'Downloaded "{len(download_jobs)}" region files and subshards stats file')

        # get subshard region
        self.subshard_region, npos0, nvar0 = utils_igg.get_subshard_details(
            self.input_subshards_stats_path, shard_id, subshard_id)
        if npos0 == 0 or nvar0 == 0 or self.subshard_region == '.':
            logging.error(
                f'Skip shard {shard_id} subshard {subshard_id} region {self.subshard_region} '
                f'with no variants.')
            return 0
        if self.subshard_region == None:
            raise Exception(
                f'shard id {shard_id} subshard id {subshard_id} is not found in '
                f'subshard stats tsv file "{self.input_subshards_stats_path}"')
        logging.info(
            f'Shard id: {shard_id}, subshard id: {subshard_id}, region: "{self.subshard_region}"')

        # get number of regions in subshard in batch and global region files
        region_file_path_list = []
        region_file_path_list.append(
            f'{self.input_dir}/data/region/global/dragen.reg.gz')
        for batch_id in batch_id_list:
            region_file_path_list.append(
                f'{self.input_dir}/data/region/batch-{batch_id}/dragen.reg.gz')
        _num_records_list = utils_igg.region_file_count_record_concurrent(
            region_file_path_list=region_file_path_list, region_str=self.subshard_region)
        logging.info(
            f'Scanned {len(region_file_path_list)} region files for #records '
            f'overlapping with region "{self.subshard_region}", '
            f'and got {len(_num_records_list)} #records results')

        # presign batch cohort and census files, global census file, and their index
        ica_url_list = []
        for f in ['dragen.cns.gz']:
            for ff in [f, f+'.tbi']:
                ica_url_list.append(
                    f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{ff}')
        for batch_id in batch_id_list:
            for f in ['dragen.cns.gz', 'dragen.cht.gz']:
                for ff in [f, f+'.tbi']:
                    ica_url_list.append(
                        f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/{ff}')
        cohort_census_psurl_dict = self.downloader.presign(
            ica_url_list=ica_url_list)

        # prepare input lists for tabix partial download with #records check
        remote_file_url_list = []
        remote_index_url_list = []
        local_file_path_list = []
        num_records_list = []

        # firstly, global census partial download
        remote_file_url_list.append(cohort_census_psurl_dict[
            f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/dragen.cns.gz'
        ][1])
        remote_index_url_list.append(cohort_census_psurl_dict[
            f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/dragen.cns.gz.tbi'
        ][1])
        local_file_path_list.append(
            f'{self.input_dir}/data/cohort-census/global/dragen.cns.gz')
        num_records_list.append(_num_records_list[0])

        # then, per batch cohort and census partial download
        for idx, batch_id in enumerate(batch_id_list):
            # census
            remote_file_url_list.append(cohort_census_psurl_dict[
                f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/dragen.cns.gz'
            ][1])
            remote_index_url_list.append(cohort_census_psurl_dict[
                f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/dragen.cns.gz.tbi'
            ][1])
            local_file_path_list.append(
                f'{self.input_dir}/data/cohort-census/batch-{batch_id}/dragen.cns.gz')
            num_records_list.append(_num_records_list[idx+1])

        for idx, batch_id in enumerate(batch_id_list):
            # cohort
            remote_file_url_list.append(cohort_census_psurl_dict[
                f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/dragen.cht.gz'
            ][1])
            remote_index_url_list.append(cohort_census_psurl_dict[
                f'ica://{self.cohort_census_project_name}/data/batch-{batch_id}/shard-{shard_id}/dragen.cht.gz.tbi'
            ][1])
            local_file_path_list.append(
                f'{self.input_dir}/data/cohort-census/batch-{batch_id}/dragen.cht.gz')
            num_records_list.append(_num_records_list[idx+1])

        utils_igg.download_using_tabix_concurrent(
            tabix_path=self.tabix_path,
            bgzip_path=self.bgzip_path,
            remote_file_url_list=remote_file_url_list,
            remote_index_url_list=remote_index_url_list,
            local_file_path_list=local_file_path_list,
            region_csv=self.subshard_region,
            num_records_list=num_records_list)
        logging.info(
            f'Partially downloaded {len(local_file_path_list)} input batch/global cohort/census files, '
            f'in region {self.subshard_region}, with number of records check.')

        # construct batch/global cohort census list (NOTE: batch id first column),
        # write to self.cht_cns_csv_path
        # columns: batch_id, batch_cht_path, batch_cns_path, global_cns_path
        utils.prep_output_file(self.cht_cns_csv_path)
        nline = 0
        with open(self.cht_cns_csv_path, 'wt') as fout:
            for batch_id in batch_id_list:
                print(
                    batch_id,
                    f'{self.input_dir}/data/cohort-census/batch-{batch_id}/dragen.cht.gz',
                    f'{self.input_dir}/data/cohort-census/batch-{batch_id}/dragen.cns.gz',
                    f'{self.input_dir}/data/cohort-census/global/dragen.cns.gz',
                    sep=',', file=fout)
                nline += 1
        logging.info(
            f'Written {nline} lines to "{self.cht_cns_csv_path}", with batch id, batch cohort, '
            f'batch census and global census file paths.')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Download is done in {time_delta} seconds.')

    def upload(self, version_id, shard_id, subshard_id):

        time_start = time.time()

        out_url = f'ica://{self.msvcf_project_prefix_name}-version-{version_id}'
        out_url += f'/data/shard-msvcf/shard-{shard_id}/subshard-{subshard_id}/'
        self.uploader.upload(
            local_dir=self.output_dir,
            ica_url=out_url,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Upload is done in {time_delta} seconds.')

    def process(self, shard_id, subshard_id, mark_low_conf):

        time_start = time.time()

        shard_id = int(shard_id)
        subshard_id = int(subshard_id)

        # prep output folder
        sup_dir = f'{self.output_dir}/{self.output_sup_dir_basename}'
        utils.run_command(f'rm -fr {self.output_dir}')
        utils.prep_output_folder(self.output_dir)
        utils.prep_output_folder(sup_dir)
        time_log = f'{sup_dir}/{self.output_time_log_basename}'

        # get subshard region, #pos, #var
        subshard_region, npos0, nvar0 = utils_igg.get_subshard_details(
            self.input_subshards_stats_path, shard_id, subshard_id)
        if npos0 == 0 or nvar0 == 0 or subshard_region == '.':
            logging.error(
                f'Skip shard {shard_id} subshard {subshard_id} region {subshard_region} '
                f'with no variants.')
            return 0

        global_cns_path = None
        with open(self.cht_cns_csv_path, 'rt') as fin:
            for line in fin:
                if line[0] == '#':
                    continue
                _batch_id, _batch_cht_path, _batch_cns_path, global_cns_path = line.strip().split(',')
                break

        nsample0 = utils_igg.census_count_sample(
            cns_path=global_cns_path,
            message=f'[global_census_stats] shard={shard_id}, subshard={subshard_id},')

        # generate regions for concurrency
        gg_regions = utils_igg.get_concurrency_regions(
            subshard_region, self.num_threads)

        # loop through all batch generation
        batch_vcf_list = []
        batch_dir_list = []
        for line in open(self.cht_cns_csv_path):
            batch_id, batch_cht_path, batch_cns_path, global_cns_path = line.strip().split(',')
            batch_output_dir = f'{sup_dir}/batch-{batch_id}'
            utils.run_command(f'rm -fr {batch_output_dir}')
            utils.prep_output_folder(batch_output_dir)
            batch_dir_list.append(batch_output_dir)
            igg_cmd_log = [
                f'LD_PRELOAD={self.mimalloc_path}',
                f'/usr/bin/time -v -a -o {time_log}',
                f'{self.dragen_path}',
                f'--sw-mode',
                f'--enable-gvcf-genotyper-iterative true',
                f'--generate-msvcf true',
                f'--input-cohort-file {batch_cht_path}',
                f'--input-census-file {batch_cns_path}',
                f'--input-global-census-file {global_cns_path}',
                f'--gg-regions {gg_regions}',
                f'--num-threads {self.num_threads}',
                f'--logging-to-output-dir true',
                f'--output-directory {batch_output_dir}',
                f'--ht-reference {self.ref_fasta_path}',
                f'--gg-enable-indexing false',
                f'--gg-msvcf-format-fields "GT:GQ:LAD:FT:LPL:LAA:LAF:DP:QL:MQR"',
                f'--gg-msvcf-info-fields "AC;AN;NS;NS_GT;NS_NOGT;NS_NODATA;IC;HWE;ExcHet;HWEc2;ABHom;ABHet"',
            ]
            igg_cmd = igg_cmd_log + [
                f'--lic-credentials {self.lic_creds_path}',
                f'{self.instance_id_loc_option}',
            ]
            batch_vcf_list.append(
                f'{batch_output_dir}/{self.output_vcf_basename}')
            ecode = utils.run_command(igg_cmd, command_log=igg_cmd_log)
            if ecode:
                return utils.early_exit(ecode, 'DRAGEN IGG generate msVCF', igg_cmd_log)

        # merge batch msVCF
        merge_output_dir = f'{sup_dir}/merge'
        utils.run_command(f'rm -fr {merge_output_dir}')
        utils.prep_output_folder(merge_output_dir)

        if len(batch_vcf_list) == 1:
            # iGG merge does not work with 1 batch, just copy the msvcf file
            utils.run_command(
                f'cp -v {batch_vcf_list[0]} {merge_output_dir}/{self.output_vcf_basename}')

        else:
            batch_vcf_list_path = f'{merge_output_dir}/vcfs.merge.list'
            utils.prep_output_file(batch_vcf_list_path)
            with open(batch_vcf_list_path, 'wt') as fout:
                for line in batch_vcf_list:
                    print(line, file=fout)

            merge_cmd_log = [
                f'LD_PRELOAD={self.mimalloc_path}',
                f'/usr/bin/time -v -a -o {time_log}',
                f'{self.dragen_path}',
                f'--sw-mode',
                f'--enable-gvcf-genotyper-iterative true',
                f'--merge-batches true',
                f'--gg-enable-indexing false',
                f'--input-batch-list {batch_vcf_list_path}',
                f'--num-threads {self.num_threads}',
                f'--logging-to-output-dir true',
                f'--output-directory {merge_output_dir}',
            ]
            merge_cmd = merge_cmd_log + [
                f'--lic-credentials {self.lic_creds_path}',
                f'{self.instance_id_loc_option}',
            ]
            ecode = utils.run_command(merge_cmd, command_log=merge_cmd_log)
            if ecode:
                return utils.early_exit(ecode, 'DRAGEN IGG merge msVCF', merge_cmd_log)

        # index merge output using bcftools
        # (--gg-enable-indexing had 2/9k chance of generating corrupt tbi index)
        index_cmd = [
            f'{self.bcftools_path}',
            f'index',
            f'--threads {self.num_threads}',
            f'--force',
            f'--tbi',
            f'{merge_output_dir}/{self.output_vcf_basename}',
        ]
        ecode = utils.run_command(index_cmd)
        if ecode:
            return utils.early_exit(ecode, 'DRAGEN IGG merge msVCF index', index_cmd)

        # this is multiallelic msvcf, so #record = #pos
        npos1 = utils_igg.vcf_index_count_var(
            bcftools_path=f'{self.bcftools_path}',
            vcf_path=f'{merge_output_dir}/{self.output_vcf_basename}',
            message=f'[merge_stats] shard={shard_id}, subshard={subshard_id},')
        if npos1 != npos0:
            logging.error(
                f'#pos mismatch between merge VCF ({npos1}) '
                f'and expected from input subshard ({npos0}), need to check results.')
            return 1

        # consisntecy check number of samples in the merge msVCF
        sample_list1 = utils_igg.vcf_get_samples(
            vcf_path=f'{merge_output_dir}/{self.output_vcf_basename}',
            message=f'[merge_stats] shard={shard_id}, subshard={subshard_id},')
        if len(sample_list1) != nsample0:
            logging.error(
                f'#sample mismatch between merge VCF ({len(sample_list1)}) '
                f'and expected from global census ({nsample0}), need to check results.')
            return 1

        # clean batch output dir
        for batch_output_dir in batch_dir_list:
            utils.run_command(f'rm -fr {batch_output_dir}')

        # cohort ML filtering
        postproc_output_dir = f'{sup_dir}/postproc'
        postproc_vcf_output_dir = f'{postproc_output_dir}/vcf'
        utils.run_command(f'rm -fr {postproc_vcf_output_dir}')
        utils.prep_output_folder(postproc_vcf_output_dir)

        # if not subshard_region.startswith('chrY:'):
        if True:
            postproc_cmd = [
                f'LD_PRELOAD={self.mimalloc_path}',
                f'/usr/bin/time -v -a -o {time_log}',
                f'{self.postproc_bin_path}',
                f'--input-vcf-name {merge_output_dir}/{self.output_vcf_basename}',
                f'--output-vcf-name {postproc_vcf_output_dir}/{self.output_vcf_basename}',
                f'--input-region {subshard_region}',
                f'--input-model {self.postproc_model_path}',
                f'--output-stats true',
                f'--output-features true',
                f'--output-sites true',
                f'--skip-index false',
                f'--threads-read {self.num_threads}',
                f'--threads-proc {self.num_threads}',
            ]
        else:
            # chrY specific build (currently not merged for testing)
            postproc_cmd = [
                f'LD_PRELOAD={self.mimalloc_path}',
                f'/usr/bin/time -v -a -o {time_log}',
                f'{self.postproc2_bin_path}',
                f'--input-vcf-name {merge_output_dir}/{self.output_vcf_basename}',
                f'--output-vcf-name {postproc_vcf_output_dir}/{self.output_vcf_basename}',
                f'--input-region {subshard_region}',
                f'--input-ped-name {self.gender_list_path}',
                f'--input-model {self.postproc_model_path}',
                f'--output-stats true',
                f'--output-features true',
                f'--output-sites true',
                f'--skip-index false',
                f'--threads-read {self.num_threads}',
                f'--threads-proc {self.num_threads}',
            ]
        ecode = utils.run_command(postproc_cmd)
        if ecode:
            return utils.early_exit(ecode, 'DRAGEN postprocess msVCF', postproc_cmd)

        # consistency check: this is biallelic msvcf, so #record = #var
        nvar2 = utils_igg.vcf_index_count_var(
            bcftools_path=f'{self.bcftools_path}',
            vcf_path=f'{postproc_vcf_output_dir}/{self.output_vcf_basename}',
            message=f'[postproc_vcf_stats] shard={shard_id}, subshard={subshard_id},')
        if nvar2 != nvar0:
            logging.error(
                f'#var mismatch between postproc VCF ({nvar2}) '
                f'and expected from input subshard ({nvar0}), need to check results.')
            return 1

        # consisntecy check number of samples in the postproc msVCF
        sample_list2 = utils_igg.vcf_get_samples(
            vcf_path=f'{postproc_vcf_output_dir}/{self.output_vcf_basename}',
            message=f'[postproc_vcf_stats] shard={shard_id}, subshard={subshard_id},')
        if len(sample_list2) != nsample0:
            logging.error(
                f'#sample mismatch between postproc VCF ({len(sample_list2)}) '
                f'and expected from global census ({nsample0}), need to check results.')
            return 1

        # annotate sites vcf with low confidence region
        sites_vcf_path = f'{postproc_vcf_output_dir}/{self.output_sites_vcf_basename}'
        if mark_low_conf:
            utils_igg.annotate_sites_vcf(
                sites_vcf_path=sites_vcf_path,
                low_conf_bed_path=self.low_conf_bed_path,
                message=f'shard={shard_id}, subshard={subshard_id},')

        # make subshard stats with biallelic sites vcf
        subshards_stats_path = f'{postproc_vcf_output_dir}/{self.output_subshards_stats_basename}'
        utils.prep_output_file(subshards_stats_path)
        region3 = None
        npos3 = 0
        nvar3 = 0
        with open(subshards_stats_path, 'wt') as fout:
            stats_dict = utils_igg.make_sites_vcf_stats(sites_vcf_path)
            if stats_dict['npos'] == 0:
                logging.error(f'postproc biallelic VCF is empty')
                return 1
            region3 = f'{stats_dict["range"][0][0]}:{stats_dict["range"][0][1]}-{stats_dict["range"][1][1]}'
            npos3 = stats_dict["npos"]
            nvar3 = stats_dict["nvar"]
            logging.info(f'STATS: [postproc_sites_vcf_stats] shard={shard_id}, subshard={subshard_id}, '
                         f'#pos={npos3}, #var={nvar3}, region={region3}')
            print(shard_id, subshard_id, region3, stats_dict["npos"], stats_dict["nvar"],
                  json.dumps(stats_dict), sep='\t', file=fout)

        # concsistency check
        if npos3 != npos0 or nvar3 != nvar0 or region3 != subshard_region:
            logging.error(
                f'#pos or #var or region mismatch between postproc sites vcf ({npos3}, {nvar3}, {region3}) '
                f'and expected from input subshard ({npos0}, {nvar0}, {subshard_region}), need to check results.')
            return 1

        # make pgen files
        postproc_pgen_output_dir = f'{postproc_output_dir}/pgen'
        utils.run_command(f'rm -fr {postproc_pgen_output_dir}')
        utils.prep_output_folder(postproc_pgen_output_dir)

        # pgen conversion

        # do not detech available ram from psutil.virtual_memory() as due to bin-packing k8s scheduling
        # max_ram = max(16000, int(
        #     psutil.virtual_memory().available/1000000*0.90))  # in MB
        instance_ram = 72000  # MB assuming 36 vCPU 72GB RAM
        max_ram = int(instance_ram * 0.95 / 1.024)

        _gender_list_path = f'{postproc_pgen_output_dir}/genders.list'
        utils.prep_output_file(_gender_list_path)
        if self.gender_list_path == None:
            # this is currenlty not an option as gender list is required from input meta folder
            logging.info(
                f'sample gender list is not provided, will generate a dummy one "{_gender_list_path}"')
            sample_list = utils_igg.vcf_get_samples(
                f'{postproc_vcf_output_dir}/{self.output_vcf_basename}')
            utils_igg.write_sample_gender(
                sample_list, _gender_list_path)
        else:
            if not os.path.isfile(self.gender_list_path):
                raise Exception(
                    f'gender list "{self.gender_list_path}" is provided but not a file.')
            cmd = [f'cp -v {self.gender_list_path} {_gender_list_path}']
            utils.run_command(cmd)

        vcf2pgen_cmd = [
            f'LD_PRELOAD={self.mimalloc_path}',
            f'/usr/bin/time -v -a -o {time_log}',
            f'{self.plink2_path}',
            f'--vcf {postproc_vcf_output_dir}/{self.output_vcf_basename}',
            f'--make-pgen',
            f'--double-id',
            f'--threads {self.num_threads}',
            f'--memory {max_ram}',
            f'--out {postproc_pgen_output_dir}/{self.output_pgen_prefix}',
            f'--update-sex {_gender_list_path}',
            f'--split-par hg38',
        ]

        ecode = utils.run_command(vcf2pgen_cmd)
        if ecode:
            return utils.early_exit(ecode, 'Plink2 VCF/PGEN conversion', vcf2pgen_cmd)

        # get stats from pvar files
        nvar4, npos4, filt_stats = utils_igg.pvar_count_var(
            pvar_path=f'{postproc_pgen_output_dir}/{self.output_pgen_prefix}.pvar',
            message=f'[postproc_pgen_stats] shard={shard_id}, subshard={subshard_id},')

        nsample4, gender_stats = utils_igg.psam_count_sample(
            psam_path=f'{postproc_pgen_output_dir}/{self.output_pgen_prefix}.psam',
            message=f'[postproc_pgen_stats] shard={shard_id}, subshard={subshard_id},')

        # consistency check
        if npos4 != npos0 or nvar4 != nvar0:
            logging.error(
                f'#pos or #var mismatch between postproc PGEN ({npos4}, {nvar4}) '
                f'and expected from input subshard ({npos0}, {nvar0}), need to check results.')
            return 1
        if nsample4 != nsample0:
            logging.error(
                f'#sample mismatch between postproc PGEN ({nsample4}) '
                f'and expected from input subshard ({nsample0}), need to check results.')
            return 1

        # move primary data to main output folder level
        output_file_list = [
            f'{merge_output_dir}/{self.output_vcf_basename}',
            f'{merge_output_dir}/{self.output_vcf_basename}.tbi',
        ]
        utils.stage_output_data(output_file_list, self.output_dir)

        output_file_list = [
            f'{postproc_vcf_output_dir}/{self.output_vcf_basename}',
            f'{postproc_vcf_output_dir}/{self.output_vcf_basename}.tbi',
            f'{postproc_vcf_output_dir}/{self.output_sites_vcf_basename}',
            f'{postproc_vcf_output_dir}/{self.output_sites_vcf_basename}.tbi',
            f'{postproc_vcf_output_dir}/{self.output_stats_vcf_basename}',
            f'{postproc_vcf_output_dir}/{self.output_stats_vcf_basename}.tbi',
            f'{postproc_vcf_output_dir}/{self.output_feature_list_basename}',
            f'{postproc_vcf_output_dir}/{self.output_subshards_stats_basename}',
        ]
        utils.stage_output_data(
            output_file_list, f'{self.output_dir}/postproc/vcf')

        output_file_list = [
            f'{postproc_pgen_output_dir}/{self.output_pgen_prefix}.pgen',
            f'{postproc_pgen_output_dir}/{self.output_pgen_prefix}.psam',
            f'{postproc_pgen_output_dir}/{self.output_pgen_prefix}.pvar',
        ]
        utils.stage_output_data(
            output_file_list, f'{self.output_dir}/postproc/pgen')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Process is done in {time_delta} seconds.')

        return utils.success_exit(f'DRAGEN msVCF/PGEN generation is successfully done.')


class ConcatMsvcfRunner:

    default_mimalloc_path = '/usr/local/lib64/libmimalloc.so'
    default_plink2_path = '/usr/local/bin/plink2'
    default_bcftools_path = '/usr/local/bin/bcftools'
    default_dotnet_path = '/usr/bin/dotnet'
    default_nirvana_path = '/opt/ica-nirvana/Nirvana.dll'
    default_jist_path = '/opt/ica-nirvana/Jist.dll'
    default_jasix_path = '/opt/ica-nirvana/Jasix.dll'

    default_num_threads = 36
    default_scratch_dir = '/scratch'

    config_shard_list_basename = 'shards.txt'
    config_chrom_list_basename = 'chroms.txt'

    output_vcf_basename = 'dragen.vcf.gz'
    output_sites_vcf_basename = 'dragen.sites.vcf.gz'
    output_anno_json_basename = 'dragen.anno.json.gz'
    output_subshards_stats_basename = 'dragen.subshards.stats.tsv'
    output_subshards_count_basename = 'dragen.shard.num-subshards.csv'
    output_pgen_prefix = 'dragen'

    output_time_log_basename = 'dragen.time_log.txt'
    output_sup_dir_basename = 'supplemental'

    def __init__(
        self,
        project_config_dict,
        job_config_dict,
        mimalloc_path=default_mimalloc_path,
        num_threads=default_num_threads,
        plink2_path=default_plink2_path,
        bcftools_path=default_bcftools_path,
        dotnet_path=default_dotnet_path,
        nirvana_path=default_nirvana_path,
        jist_path=default_jist_path,
        jasix_path=default_jasix_path,
        scratch_dir=default_scratch_dir,
    ):
        self.mimalloc_path = mimalloc_path
        self.num_threads = num_threads or os.cpu_count()
        self.plink2_path = plink2_path
        self.bcftools_path = bcftools_path
        self.dotnet_path = dotnet_path
        self.nirvana_path = nirvana_path
        self.jist_path = jist_path
        self.jasix_path = jasix_path
        self.scratch_dir = scratch_dir

        self.retry_runner = utils.RetryRunner()
        self.ica_client = utils.ICAClient(
            api_key=project_config_dict['ica_api_key'], retry_runner=self.retry_runner)
        self.downloader = utils.ICADownloader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)
        self.uploader = utils.ICAUploader(
            ica_client=self.ica_client, retry_runner=self.retry_runner)

        self.ica_client._set_cache_using_project_config(
            project_config_dict=project_config_dict)
        for _project_details, _project_data_details in job_config_dict['project_data_list']:
            self.ica_client._set_cache_using_project_data(
                project_details=_project_details, project_data_details=_project_data_details)

        self.region_name = project_config_dict['ica_region']['code']
        self.storage_bundle_name = project_config_dict['ica_storage_bundle']['bundleName']
        if project_config_dict['ica_storage_configuration'] == None:
            self.storage_configuration_name = None
        else:
            self.storage_configuration_name = project_config_dict['ica_storage_configuration']['name']

        self.project_prefix = project_config_dict['ica_job_project']['name'].rstrip(
            '-jobs')
        self.config_project_name = f'{self.project_prefix}-jobs'
        self.cohort_census_project_name = f'{self.project_prefix}-cohort-census'
        self.msvcf_project_prefix_name = f'{self.project_prefix}-msvcf'

        self.input_dir = f'{self.scratch_dir}/input'
        self.output_dir = f'{self.scratch_dir}/output'

        # to update once we get the data
        self.num_shards = 0
        self.contig_name = None
        self.contig_shard_num_subshards_list = []

        self.concat_options = set()

        self.vcf_list_path = f'{self.input_dir}/data/vcf.list'
        self.sites_vcf_list_path = f'{self.input_dir}/data/site-vcf.list'
        self.reduced_vcf_list_path = f'{self.input_dir}/data/reduced-vcf.list'
        self.reduced_sites_vcf_list_path = f'{self.input_dir}/data/reduced-site.vcf.list'
        self.pgen_prefix_list_path = f'{self.input_dir}/data/pgen-prefix.list'
        self.anno_json_folder_path = f'{self.input_dir}/data/anno-json'

        self.num_vcfs = 0
        self.num_sites_vcfs = 0
        self.num_reduced_vcfs = 0
        self.num_reduced_sites_vcfs = 0
        self.num_pgen_prefixes = 0
        self.num_anno_jsons = 0

        self.npos = 0
        self.nvar = 0
        self.nsample = -1

    def run(self, version_id, chrom_id, concat_options, index_msvcf):

        self.download(version_id, chrom_id, concat_options)
        ecode = self.process(chrom_id, index_msvcf)
        if ecode:
            logging.error(f'ConcatMsvcfRunner failed with exit code {ecode}, '
                          f'uploading data now for investigation')
        self.upload(version_id, chrom_id)
        return ecode

    def download(self, version_id, chrom_id, concat_options):

        time_start = time.time()

        # data to download

        # config
        # /meta/config/chroms.txt
        # /meta/config/shards.txt

        # per shard

        # /data/global-census/shard-12/dragen.shard.num-subshards.csv
        # /data/global-census/shard-12/dragen.shard.num-subshards.csv.md5
        # /data/global-census/shard-12/dragen.subshards.stats.tsv
        # /data/global-census/shard-12/dragen.subshards.stats.tsv.md5
        # /data/global-census/shard-12/dragen.anno.json.gz
        # /data/global-census/shard-12/dragen.anno.json.gz.md5
        # /data/global-census/shard-12/dragen.anno.json.gz.jsi
        # /data/global-census/shard-12/dragen.anno.json.gz.jsi.md5
        # /data/global-census/shard-12/dragen.sites.vcf.gz
        # /data/global-census/shard-12/dragen.sites.vcf.gz.md5
        # /data/global-census/shard-12/dragen.sites.vcf.gz.tbi
        # /data/global-census/shard-12/dragen.sites.vcf.gz.tbi.md5

        # per subshard

        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.vcf.gz
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.vcf.gz.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.vcf.gz.tbi
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.vcf.gz.tbi.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.sites.vcf.gz
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.sites.vcf.gz.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.sites.vcf.gz.tbi
        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.sites.vcf.gz.tbi.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.pgen
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.pgen.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.psam
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.psam.md5
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.pvar
        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.pvar.md5

        # process concat options
        full_options = {'pgen', 'reduced-vcf',
                        'reduced-site-vcf', 'site-vcf', 'anno-json', 'vcf'}
        if concat_options == 'all':
            self.concat_options = full_options
        else:
            for option in concat_options.split(','):
                if option not in full_options:
                    raise Exception(
                        f'concat option "{option}" is not supported.')
                self.concat_options.add(option)

        # download meta data
        metadata_file_list = [
            f'meta/config/{self.config_shard_list_basename}',
            f'meta/config/{self.config_chrom_list_basename}',
        ]

        ica_url_list = []
        local_path_list = []
        for f in metadata_file_list:
            ica_url_list.append(f'ica://{self.config_project_name}/{f}')
            local_path_list.append(f'{self.input_dir}/{f}')

        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # get contig name mapped to chrom_id
        _chroms_list = f'{self.input_dir}/meta/config/{self.config_chrom_list_basename}'
        with open(_chroms_list, 'rt') as fin:
            for line in fin:
                # 4	chr4, 25 chrM, 26 chrZ (=alt contigs, anything else)
                _chrom_id, _contig_name = line.strip().split('\t')
                _chrom_id = int(_chrom_id)
                if _chrom_id == chrom_id:
                    self.contig_name = _contig_name
                    break
        if self.contig_name == None:
            raise Exception(
                f'Can not find contig name mapped to chrom id "{chrom_id}" in "{_chroms_list}"')
        logging.info(
            f'chrom id "{chrom_id}" is mapped to contig name "{self.contig_name}"')

        # get list of shards for this contig
        _shards_list = f'{self.input_dir}/meta/config/{self.config_shard_list_basename}'
        self.num_shards = 0
        with open(_shards_list, 'rt') as fin:
            for line in fin:
                # 3	chr1:69198057-103797084
                self.num_shards += 1
                _shard_id, _shard_region_csv = line.strip().split('\t')
                _shard_id = int(_shard_id)
                _contig_name_list = [x.split(':')[0]
                                     for x in _shard_region_csv.split(',')]
                _shard_overlap = False
                for _contig_name in _contig_name_list:
                    if _contig_name == self.contig_name:
                        _shard_overlap = True
                if _shard_overlap:
                    self.contig_shard_num_subshards_list.append([_shard_id, 0])
        logging.info(
            f'Found "{self.num_shards}" shards from shard list "{_shards_list}"')

        if self.contig_name == 'chrZ':
            # only take the last shard
            self.contig_shard_num_subshards_list.append([self.num_shards, 0])

        if len(self.contig_shard_num_subshards_list) == 0:
            raise Exception(
                f'Can not find shard IDs mapped to contig name "{self.contig_name}"')

        logging.info(
            f'Found "{len(self.contig_shard_num_subshards_list)}" shard IDs (including empty shards) mapped to '
            f'contig name "{self.contig_name}"')

        # get number of subshards per shard and subshard stats per shard
        _msvcf_project_name = f'{self.msvcf_project_prefix_name}-version-{version_id}'
        download_jobs = []
        for x in self.contig_shard_num_subshards_list:
            shard_id = x[0]
            for _basename in [self.output_subshards_stats_basename, self.output_subshards_count_basename]:
                for x in [_basename, _basename+'.md5']:
                    download_jobs.append([
                        f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{x}',
                        f'{self.input_dir}/data/subshards-stats/shard-{shard_id}/{x}',
                    ])

        ica_url_list = [x[0] for x in download_jobs]
        local_path_list = [x[1] for x in download_jobs]
        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # check md5sum
        md5sum_check_list = [x[1]
                             for x in download_jobs if not x[1].endswith('.md5')]
        utils.check_input_data_md5(md5sum_check_list)
        logging.info(
            f'Downloaded "{len(download_jobs)}" subshards stats and count file')

        # update number of subshards per shard
        total_num_subshards = 0
        for x in self.contig_shard_num_subshards_list:
            shard_id = x[0]
            _subshards_count = f'{self.input_dir}/data/subshards-stats/shard-{shard_id}/{self.output_subshards_count_basename}'
            for line in open(_subshards_count):
                _shard_id, _num_subshards = line.strip().split(',')
                _shard_id = int(_shard_id)
                _num_subshards = int(_num_subshards)
                if _shard_id != shard_id:
                    raise Exception(
                        f'subshard count file "{_subshards_count}" does not contain info about '
                        f'shard "{shard_id}": line={line.strip()}')
                x[1] = _num_subshards
                total_num_subshards += _num_subshards

        logging.info(
            f'Found "{total_num_subshards}" subshard IDs mapped to '
            f'contig name "{self.contig_name}"')

        # exclude empty shard (causing problem with concat anno json)
        self.contig_shard_num_subshards_list = [
            x for x in self.contig_shard_num_subshards_list if x[1] > 0]

        logging.info(
            f'Found "{len(self.contig_shard_num_subshards_list)}" shard IDs (non-empty) mapped to '
            f'contig name "{self.contig_name}"')

        # update number of positions and variants per chrom
        self.npos = 0
        self.nvar = 0
        for shard_id, num_subshards in self.contig_shard_num_subshards_list:
            for subshard_id in range(1, num_subshards+1):
                _subshards_stats = f'{self.input_dir}/data/subshards-stats/shard-{shard_id}/{self.output_subshards_stats_basename}'
                _, _npos, _nvar = utils_igg.get_subshard_details(
                    _subshards_stats, shard_id, subshard_id)
                self.npos += _npos
                self.nvar += _nvar

        if self.npos == 0:
            raise Exception(
                f'No positions to conat on contig "{self.contig_name}"')
        if self.nvar == 0:
            raise Exception(
                f'No variants to conat on contig "{self.contig_name}"')
        logging.info(
            f'Expected #pos = {self.npos} and #var = {self.nvar} on contig "{self.contig_name}"')

        # download input data depending on concat options
        download_jobs = []
        fout_dict = dict()
        if 'vcf' in self.concat_options:
            utils.prep_output_file(self.vcf_list_path)
            fout_dict['vcf'] = open(self.vcf_list_path, 'wt')
        if 'site-vcf' in self.concat_options:
            utils.prep_output_file(self.sites_vcf_list_path)
            fout_dict['site-vcf'] = open(self.sites_vcf_list_path, 'wt')
        if 'reduced-vcf' in self.concat_options:
            utils.prep_output_file(self.reduced_vcf_list_path)
            fout_dict['reduced-vcf'] = open(self.reduced_vcf_list_path, 'wt')
        if 'reduced-site-vcf' in self.concat_options:
            utils.prep_output_file(self.reduced_sites_vcf_list_path)
            fout_dict['reduced-site-vcf'] = open(
                self.reduced_sites_vcf_list_path, 'wt')
        if 'pgen' in self.concat_options:
            utils.prep_output_file(self.pgen_prefix_list_path)
            fout_dict['pgen'] = open(self.pgen_prefix_list_path, 'wt')

        for shard_id, num_subshards in self.contig_shard_num_subshards_list:

            # download per shard sites vcf
            if 'site-vcf' in self.concat_options:
                # /data/global-census/shard-12/dragen.sites.vcf.gz
                _basename = self.output_sites_vcf_basename
                for x in [_basename, _basename+'.tbi', _basename+'.md5', _basename+'.tbi.md5']:
                    download_jobs.append([
                        f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{x}',
                        f'{self.input_dir}/data/site-vcf/shard-{shard_id}/{x}',
                    ])
                print(f'{self.input_dir}/data/site-vcf/shard-{shard_id}/{_basename}',
                      file=fout_dict['site-vcf'])
                self.num_sites_vcfs += 1

            # download per shard annotation json
            if 'anno-json' in self.concat_options:
                # /data/global-census/shard-12/dragen.anno.json.gz
                _basename = self.output_anno_json_basename
                for x in [_basename, _basename+'.jsi', _basename+'.md5', _basename+'.jsi.md5']:
                    download_jobs.append([
                        f'ica://{_msvcf_project_name}/data/global-census/shard-{shard_id}/{x}',
                        f'{self.input_dir}/data/anno-json/shard-{shard_id}/{x}',
                    ])
                self.num_anno_jsons += 1

            for subshard_id in range(1, num_subshards+1):

                if 'vcf' in self.concat_options:
                    _basename = self.output_vcf_basename
                    for x in [_basename, _basename+'.tbi', _basename+'.md5', _basename+'.tbi.md5']:
                        # /data/shard-msvcf/shard-12/subshard-1/dragen.vcf.gz
                        download_jobs.append([
                            f'ica://{_msvcf_project_name}/data/shard-msvcf/shard-{shard_id}/subshard-{subshard_id}/{x}',
                            f'{self.input_dir}/data/vcf/shard-{shard_id}/subshard-{subshard_id}/{x}',
                        ])
                    print(f'{self.input_dir}/data/vcf/shard-{shard_id}/subshard-{subshard_id}/{_basename}',
                          file=fout_dict['vcf'])
                    self.num_vcfs += 1

                if 'reduced-vcf' in self.concat_options:
                    _basename = self.output_vcf_basename
                    for x in [_basename, _basename+'.tbi', _basename+'.md5', _basename+'.tbi.md5']:
                        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.vcf.gz
                        download_jobs.append([
                            f'ica://{_msvcf_project_name}/data/shard-msvcf/shard-{shard_id}/subshard-{subshard_id}/postproc/vcf/{x}',
                            f'{self.input_dir}/data/reduced-vcf/shard-{shard_id}/subshard-{subshard_id}/{x}',
                        ])
                    print(f'{self.input_dir}/data/reduced-vcf/shard-{shard_id}/subshard-{subshard_id}/{_basename}',
                          file=fout_dict['reduced-vcf'])
                    self.num_reduced_vcfs += 1

                if 'reduced-site-vcf' in self.concat_options:
                    _basename = self.output_sites_vcf_basename
                    for x in [_basename, _basename+'.tbi', _basename+'.md5', _basename+'.tbi.md5']:
                        # /data/shard-msvcf/shard-12/subshard-1/postproc/vcf/dragen.sites.vcf.gz
                        download_jobs.append([
                            f'ica://{_msvcf_project_name}/data/shard-msvcf/shard-{shard_id}/subshard-{subshard_id}/postproc/vcf/{x}',
                            f'{self.input_dir}/data/reduced-site-vcf/shard-{shard_id}/subshard-{subshard_id}/{x}',
                        ])
                    print(f'{self.input_dir}/data/reduced-site-vcf/shard-{shard_id}/subshard-{subshard_id}/{_basename}',
                          file=fout_dict['reduced-site-vcf'])
                    self.num_reduced_sites_vcfs += 1

                if 'pgen' in self.concat_options:
                    _basename = self.output_pgen_prefix
                    for x in [_basename + '.pgen', _basename+'.pvar', _basename+'.psam',
                              _basename + '.pgen.md5', _basename+'.pvar.md5', _basename+'.psam.md5']:
                        # /data/shard-msvcf/shard-12/subshard-1/postproc/pgen/dragen.pgen
                        download_jobs.append([
                            f'ica://{_msvcf_project_name}/data/shard-msvcf/shard-{shard_id}/subshard-{subshard_id}/postproc/pgen/{x}',
                            f'{self.input_dir}/data/pgen/shard-{shard_id}/subshard-{subshard_id}/{x}',
                        ])
                    print(f'{self.input_dir}/data/pgen/shard-{shard_id}/subshard-{subshard_id}/{_basename}',
                          file=fout_dict['pgen'])
                    self.num_pgen_prefixes += 1

        for k in fout_dict:
            fout_dict[k].close()

        if 'vcf' in self.concat_options and self.num_vcfs == 0:
            raise Exception(
                f'No VCFs to concat on contig "{self.contig_name}"')
        if 'site-vcf' in self.concat_options and self.num_sites_vcfs == 0:
            raise Exception(
                f'No sites vcfs to concat on contig "{self.contig_name}"')
        if 'anno-json' in self.concat_options and self.num_anno_jsons == 0:
            raise Exception(
                f'No annotation JSONs to concat on contig "{self.contig_name}"')
        if 'reduced-vcf' in self.concat_options and self.num_reduced_vcfs == 0:
            raise Exception(
                f'No reduced VCFs to concat on contig "{self.contig_name}"')
        if 'reduced-site-vcf' in self.concat_options and self.num_reduced_sites_vcfs == 0:
            raise Exception(
                f'No reduced sites vcfs to concat on contig "{self.contig_name}"')
        if 'pgen' in self.concat_options and self.num_pgen_prefixes == 0:
            raise Exception(
                f'No PGEN files to concat on contig "{self.contig_name}"')

        if 'vcf' in self.concat_options:
            logging.info(f'Will concat {self.num_vcfs} VCFs')
        if 'site-vcf' in self.concat_options:
            logging.info(f'Will concat {self.num_sites_vcfs} sites vcfs')
        if 'anno-json' in self.concat_options:
            logging.info(f'Will concat {self.num_anno_jsons} annotation JSONs')
        if 'reduced-vcf' in self.concat_options:
            logging.info(f'Will concat {self.num_reduced_vcfs} reduced VCFs')
        if 'reduced-site-vcf' in self.concat_options:
            logging.info(
                f'Will concat {self.num_reduced_sites_vcfs} reduced sites vcfs')
        if 'pgen' in self.concat_options:
            logging.info(f'Will concat {self.num_pgen_prefixes} PGENs')

        ica_url_list = [x[0] for x in download_jobs]
        local_path_list = [x[1] for x in download_jobs]
        self.downloader.download(
            ica_url_list=ica_url_list, local_path_list=local_path_list)

        # check md5sum
        md5sum_check_list = [x[1]
                             for x in download_jobs if not x[1].endswith('.md5')]
        utils.check_input_data_md5(md5sum_check_list)
        logging.info(
            f'Downloaded "{len(download_jobs)}" per shard or per subshard input files to concat')

        # move anno json since Nirvana Jist expects a prefix with file name sorted in suffix
        if 'anno-json' in self.concat_options:
            _index = 0
            _basename = self.output_anno_json_basename
            for shard_id, num_subshards in self.contig_shard_num_subshards_list:
                file_id = str(_index).zfill(6)
                utils.run_command(
                    f'mv {self.input_dir}/data/anno-json/shard-{shard_id}/{_basename} '
                    f'{self.input_dir}/data/anno-json/dragen.anno.{file_id}.json.gz')
                utils.run_command(
                    f'mv {self.input_dir}/data/anno-json/shard-{shard_id}/{_basename}.jsi '
                    f'{self.input_dir}/data/anno-json/dragen.anno.{file_id}.json.gz.jsi')
                utils.run_command(
                    f'rm -fr {self.input_dir}/data/anno-json/shard-{shard_id}')
                _index += 1

        # check psam sample size
        if 'pgen' in self.concat_options:
            with open(self.pgen_prefix_list_path) as fin:
                for line in fin:
                    _psam_file = line.strip() + '.psam'
                    _nsample, _gender_stats = utils_igg.psam_count_sample(
                        psam_path=_psam_file,
                        message=f'[subshard_pgen_stats]')
                    if self.nsample == -1:
                        self.nsample = _nsample
                    else:
                        if self.nsample != _nsample:
                            raise Exception(
                                f'number of samples mismatch, expected {self.nsample}, found {_nsample} '
                                f'in input psam file "{_psam_file}"')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Download is done in {time_delta} seconds.')

    def upload(self, version_id, chrom_id):

        time_start = time.time()

        out_url = f'ica://{self.msvcf_project_prefix_name}-version-{version_id}'
        out_url += f'/data/chrom-msvcf/chrom-{chrom_id}/'
        self.uploader.upload(
            local_dir=self.output_dir,
            ica_url=out_url,
            region_name=self.region_name,
            storage_bundle_name=self.storage_bundle_name,
            storage_configuration_name=self.storage_configuration_name)

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Upload is done in {time_delta} seconds.')

    def process(self, chrom_id, index_msvcf):

        time_start = time.time()

        # prep output folder
        sup_dir = f'{self.output_dir}/{self.output_sup_dir_basename}'
        utils.run_command(f'rm -fr {self.output_dir}')
        utils.prep_output_folder(self.output_dir)
        utils.prep_output_folder(sup_dir)
        time_log = f'{sup_dir}/{self.output_time_log_basename}'

        # self.vcf_list_path = f'{self.input_dir}/data/vcf.list'
        # self.sites_vcf_list_path = f'{self.input_dir}/data/site-vcf.list'
        # self.reduced_vcf_list_path = f'{self.input_dir}/data/reduced-vcf.list'
        # self.reduced_sites_vcf_list_path = f'{self.input_dir}/data/reduced-site.vcf.list'
        # self.pgen_prefix_list_path = f'{self.input_dir}/data/pgen-prefix.list'
        # self.anno_json_folder_path = f'{self.input_dir}/data/anno-json'

        if 'vcf' in self.concat_options:
            ecode = utils_igg.concat_vcf(
                bcftools_path=self.bcftools_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                in_vcf_list_path=self.vcf_list_path,
                out_vcf_path=f'{sup_dir}/vcf/{self.output_vcf_basename}',
                index_vcf=index_msvcf)

            if ecode:
                logging.error(
                    f'Failed to concat VCF, exit code {ecode}, early exit now.')
                return ecode

            if index_msvcf:
                # check #pos (#record = #pos)
                npos = utils_igg.vcf_index_count_var(
                    bcftools_path=self.bcftools_path,
                    vcf_path=f'{sup_dir}/vcf/{self.output_vcf_basename}',
                    message=f'[concat_vcf_stats] VCF chrom={chrom_id},')
                if npos != self.npos:
                    logging.error(
                        f'number of positions mismatch after concat, '
                        f'concat VCF #pos = {npos} while expected #pos = {self.npos}')
                    return 1

        if 'site-vcf' in self.concat_options:
            ecode = utils_igg.concat_vcf(
                bcftools_path=self.bcftools_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                in_vcf_list_path=self.sites_vcf_list_path,
                out_vcf_path=f'{sup_dir}/site-vcf/{self.output_sites_vcf_basename}',
                index_vcf=True)

            if ecode:
                logging.error(
                    f'Failed to concat sites vcf, exit code {ecode}, early exit now.')
                return ecode

            # check #var (#records = #pos)
            npos = utils_igg.vcf_index_count_var(
                bcftools_path=self.bcftools_path,
                vcf_path=f'{sup_dir}/site-vcf/{self.output_sites_vcf_basename}',
                message=f'[concat_vcf_stats] sites vcf, chrom={chrom_id},')
            if npos != self.npos:
                logging.error(
                    f'number of positions mismatch after concat, '
                    f'concat sites vcf #pos = {npos} while expected #pos = {self.npos}')
                return 1

        if 'reduced-vcf' in self.concat_options:
            ecode = utils_igg.concat_vcf(
                bcftools_path=self.bcftools_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                in_vcf_list_path=self.reduced_vcf_list_path,
                out_vcf_path=f'{sup_dir}/reduced-vcf/{self.output_vcf_basename}',
                index_vcf=index_msvcf)

            if ecode:
                logging.error(
                    f'Failed to concat reduced VCF, exit code {ecode}, early exit now.')
                return ecode

            if index_msvcf:
                # check #var (#record = #var)
                nvar = utils_igg.vcf_index_count_var(
                    bcftools_path=self.bcftools_path,
                    vcf_path=f'{sup_dir}/reduced-vcf/{self.output_vcf_basename}',
                    message=f'[concat_vcf_stats] reduced VCF chrom={chrom_id},')
                if nvar != self.nvar:
                    logging.error(
                        f'number of variants mismatch after concat, '
                        f'concat reduced VCF #var = {nvar} while expected #var = {self.nvar}')
                    return 1

        if 'reduced-site-vcf' in self.concat_options:
            ecode = utils_igg.concat_vcf(
                bcftools_path=self.bcftools_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                in_vcf_list_path=self.reduced_sites_vcf_list_path,
                out_vcf_path=f'{sup_dir}/reduced-site-vcf/{self.output_sites_vcf_basename}',
                index_vcf=True)

            if ecode:
                logging.error(
                    f'Failed to concat reduced sites vcf, exit code {ecode}, early exit now.')
                return ecode

            # check #var (#record = #var)
            nvar = utils_igg.vcf_index_count_var(
                bcftools_path=self.bcftools_path,
                vcf_path=f'{sup_dir}/reduced-site-vcf/{self.output_sites_vcf_basename}',
                message=f'[concat_vcf_stats] reduced sites vcf chrom={chrom_id},')
            if nvar != self.nvar:
                logging.error(
                    f'number of variants mismatch after concat, '
                    f'concat reduced sites vcf #var = {nvar} while expected #var = {self.nvar}')
                return 1

        if 'pgen' in self.concat_options:
            instance_ram = 72000  # MB assuming 36 vCPU 72GB RAM
            max_ram = int(instance_ram * 0.95 / 1.024)
            ecode = utils_igg.concat_pgen(
                plink2_path=self.plink2_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                max_ram=max_ram,
                in_pgen_prefix_list_path=self.pgen_prefix_list_path,
                out_pgen_prefix=f'{sup_dir}/pgen/{self.output_pgen_prefix}')

            if ecode:
                logging.error(
                    f'Failed to concat PGEN, exit code {ecode}, early exit now.')
                return ecode

            # check #var
            nvar, npos, filt_stats = utils_igg.pvar_count_var(
                pvar_path=f'{sup_dir}/pgen/{self.output_pgen_prefix}.pvar',
                message=f'[concat_pgen_stats] chrom={chrom_id},')
            if nvar != self.nvar:
                logging.error(
                    f'number of variants mismatch after concat, '
                    f'concat PGEN #var = {nvar} while expected #var = {self.nvar}')
                return 1
            if npos != self.npos:
                logging.error(
                    f'number of positions mismatch after concat, '
                    f'concat PGEN #pos = {npos} while expected #pos = {self.npos}')
                return 1

            # check #sample
            nsample, gender_stats = utils_igg.psam_count_sample(
                psam_path=f'{sup_dir}/pgen/{self.output_pgen_prefix}.psam',
                message=f'[concat_pgen_stats] chrom={chrom_id},')
            if nsample != self.nsample:
                logging.error(
                    f'number of samples mismatch after concat, '
                    f'concat PGEN #sample = {nsample} while expected #sample = {self.nsample}')
                return 1

        if 'anno-json' in self.concat_options:
            ecode = utils_igg.concat_anno_json(
                dotnet_path=self.dotnet_path,
                jist_path=self.jist_path,
                jasix_path=self.jasix_path,
                mimalloc_path=self.mimalloc_path,
                time_log=time_log,
                num_threads=self.num_threads,
                in_json_folder_path=self.anno_json_folder_path,
                in_json_prefix='dragen.anno.',
                out_json_gz_path=f'{sup_dir}/anno-json/{self.output_anno_json_basename}')

            if ecode:
                logging.error(
                    f'Failed to concat annotation JSON, exit code {ecode}, early exit now.')
                return ecode

            # check #var (#record = #pos)
            npos = utils_igg.anno_json_count_var(
                anno_json_path=f'{sup_dir}/anno-json/{self.output_anno_json_basename}',
                message=f'chrom={chrom_id},')

            # consistency check census/sites vcf <=> annotation
            if npos != self.npos:
                logging.error(
                    f'number of positions mismatch after concat, '
                    f'concat annotation JSON #pos = {npos} while expected #pos = {self.npos}')
                return 1

        # move primary data to main output folder level and check md5sum
        if 'vcf' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/vcf/{self.output_vcf_basename}',
            ]
            if index_msvcf:
                output_file_list.append(
                    f'{sup_dir}/vcf/{self.output_vcf_basename}.tbi')
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/full-vcf')

        if 'site-vcf' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/site-vcf/{self.output_sites_vcf_basename}',
                f'{sup_dir}/site-vcf/{self.output_sites_vcf_basename}.tbi',
            ]
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/full-vcf')

        if 'reduced-vcf' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/reduced-vcf/{self.output_vcf_basename}',
            ]
            if index_msvcf:
                output_file_list.append(
                    f'{sup_dir}/reduced-vcf/{self.output_vcf_basename}.tbi')
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/postproc-vcf')

        if 'reduced-site-vcf' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/reduced-site-vcf/{self.output_sites_vcf_basename}',
                f'{sup_dir}/reduced-site-vcf/{self.output_sites_vcf_basename}.tbi',
            ]
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/postproc-vcf')

        if 'pgen' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/pgen/{self.output_pgen_prefix}.pgen',
                f'{sup_dir}/pgen/{self.output_pgen_prefix}.psam',
                f'{sup_dir}/pgen/{self.output_pgen_prefix}.pvar',
            ]
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/postproc-pgen')

        if 'anno-json' in self.concat_options:
            output_file_list = [
                f'{sup_dir}/anno-json/{self.output_anno_json_basename}',
                f'{sup_dir}/anno-json/{self.output_anno_json_basename}.jsi',
            ]
            utils.stage_output_data(
                output_file_list, f'{self.output_dir}/full-anno')

        time_end = time.time()
        time_delta = '{0:.3f}'.format(time_end - time_start)
        logging.info(f'[TIME CHECK] Process is done in {time_delta} seconds.')

        return utils.success_exit(f'DRAGEN msVCF/PGEN/annotation concat is successfully done.')


def parse_args():

    usage = f"""
  dragen-igg-runner [args]

description:
  run Iterative Gvcf Genotyper step locally

"""
    parser = argparse.ArgumentParser(
        usage=usage, formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument('--job-def-str', required=True,
                        help='Job definition string [required]')

    parser.add_argument('--job-secret-file', required=True,
                        help='Job secret file [required]')

    parser.add_argument('-v', '--version', action='version',
                        version=f'Version: {utils.get_package_version()}')

    return parser.parse_args()


def main():

    time_start = time.time()

    utils.config_logging()

    args = parse_args()
    job_config_dict = utils.b64str_to_json(args.job_def_str)
    project_config_dict = utils.read_json(args.job_secret_file)

    _project_config_dict = {k: v for k, v in project_config_dict.items()}
    _project_config_dict['ica_api_key'] = '******'
    logging.info(
        f'IGG project configuration: {json.dumps(_project_config_dict, indent=2)}')
    logging.info(
        f'IGG job configuration: {json.dumps(job_config_dict, indent=2)}')

    if 'step_name' not in job_config_dict:
        raise Exception(
            f'missing key "step_name" in job definition dict: {job_config_dict}')

    if job_config_dict['step_name'] == 'aggregate-gvcf':
        runner = AggregateGvcfRunner(
            project_config_dict=project_config_dict,
            job_config_dict=job_config_dict)
        ecode = runner.run(
            batch_id=job_config_dict['batch_id'],
            shard_id=job_config_dict['shard_id'],
            min_qual=job_config_dict['min_qual'],
            track_variants=job_config_dict['track_variants'])

    elif job_config_dict['step_name'] == 'aggregate-census':
        runner = AggregateCensusRunner(
            project_config_dict=project_config_dict,
            job_config_dict=job_config_dict)
        ecode = runner.run(
            version_id=job_config_dict['version_id'],
            shard_id=job_config_dict['shard_id'],
            run_anno=job_config_dict['enable_annotation'],
            nsite_subshard=job_config_dict['nsite_subshard'],
            mark_low_conf=job_config_dict['mark_low_conf'])

    elif job_config_dict['step_name'] == 'generate-msvcf':
        runner = GenerateMsvcfRunner(
            project_config_dict=project_config_dict,
            job_config_dict=job_config_dict)
        ecode = runner.run(
            version_id=job_config_dict['version_id'],
            shard_id=job_config_dict['shard_id'],
            subshard_id=job_config_dict['subshard_id'],
            mark_low_conf=job_config_dict['mark_low_conf'])

    elif job_config_dict['step_name'] == 'concat-msvcf':
        runner = ConcatMsvcfRunner(
            project_config_dict=project_config_dict,
            job_config_dict=job_config_dict)
        ecode = runner.run(
            version_id=job_config_dict['version_id'],
            chrom_id=job_config_dict['chrom_id'],
            concat_options=job_config_dict['concat_options'],
            index_msvcf=job_config_dict['index_msvcf'])

    else:
        raise Exception(
            f'step name "{job_config_dict["step_name"]}" is not supported. ')

    time_end = time.time()
    time_delta = '{0:.3f}'.format(time_end - time_start)

    if ecode == 0:
        logging.info(f'::::::: ALL DONE (in {time_delta} seconds) :::::::')
    else:
        raise Exception(
            f'*ERROR* Program failed with exit code {ecode} (see details in logs above)')


if __name__ == '__main__':

    main()
