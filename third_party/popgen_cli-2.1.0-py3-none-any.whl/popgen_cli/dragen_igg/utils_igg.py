import os
import gzip
import logging
import popgen_cli.utils.utils as utils
from typing import List
import subprocess
import json
import math
from collections import defaultdict


def census_to_region(cns_path, reg_path, message):
    """used in step1 and step2 (per batch and glboal)"""

    logging.info(
        f'Reading census file "{cns_path}" and writing region file "{reg_path}"')
    utils.prep_output_file(reg_path)
    nregion = 0
    with gzip.open(reg_path, 'wt', encoding='utf-8') as fout:
        with gzip.open(cns_path, 'rt') as fin:
            for line in fin:
                if line[:2] == '##':
                    continue
                _data = line.strip().split('\t')
                # chrom pos end (1-based inclusive)
                print('\t'.join(_data[:3]), file=fout)
                nregion += 1
    logging.info(f'STATS: {message} #region={nregion}')
    return nregion


def census_to_sites_vcf(cns_path, sites_vcf_path, message):
    """used in step2, partially for Nirvana
    if emtpy, then output file only contains header
    """

    logging.info(
        f'Reading census file "{cns_path}" and writing sites vcf file "{sites_vcf_path}"')
    utils.prep_output_file(sites_vcf_path)
    if sites_vcf_path.endswith('.vcf.gz'):
        sites_vcf_path = sites_vcf_path[:-3]

    headers = [
        '##fileformat=VCFv4.2',
        '##INFO=<ID=AC,Number=A,Type=Integer,Description="Allele count in genotypes">',
        '##INFO=<ID=AN,Number=1,Type=Integer,Description="Total number of alleles in called genotypes">',
        '##INFO=<ID=NS,Number=1,Type=Integer,Description="Total number of samples">',
        '##INFO=<ID=NS_GT,Number=1,Type=Integer,Description="Total number of samples with called genotypes">',
        '##INFO=<ID=NS_NOGT,Number=1,Type=Integer,Description="Total number of samples with unknown genotypes ./.">',
        '##INFO=<ID=NS_NODATA,Number=1,Type=Integer,Description="Total number of samples with no coverage">',
        '#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO',
    ]
    npos = 0
    nvar = 0
    with open(sites_vcf_path, 'w') as fout:
        for line in headers:
            print(line, file=fout)

        with gzip.open(cns_path, 'rt') as fin:
            for line in fin:
                if line[0] == '#':
                    continue
                _data = line.strip().split('\t')
                if not _data[3].startswith('1;'):
                    # skip region without var
                    continue
                # data[3] looks like this
                # 1;AACCCT;A;2;4;0;.:0,A:2,AACCCT:2;AACCCT:A:0/1?1&R:.:./.?.;12.11;AACCCT:A:0/1?9,7
                # 0: 1 (has var)
                # 1: AACCCT (ref)
                # 2: A (alt)
                # 3: 2 (ns gt)
                # 4: 4 (ns nogt)
                # 5: 0 (ns nodata)
                # 6: .:0,A:2,AACCCT:2 (ac, first is for NON_REF not missing GT)
                # 7: AACCCT:A:0/1?1&R:.:./.?. (RAGT counts, there seems a bug in count)
                # 8: 12.11 (max of per sample QL)
                # 9: AACCCT:A:0/1?9,7 (RAGT AD sums)

                _fields = _data[3].split(';')
                chrom = _data[0]
                pos = _data[1]
                ref = _fields[1]
                alts = _fields[2]
                ns_gt = int(_fields[3])
                ns_nogt = int(_fields[4])
                ns_nodata = int(_fields[5])
                ns = ns_gt + ns_nogt + ns_nodata

                # the position in census file is unique
                npos += 1
                nvar += len(alts.split(','))

                # calculate AC, AN
                allele_index = {ref: 0}
                for i, alt in enumerate(alts.split(',')):
                    allele_index[alt] = i+1
                ac_list = [0 for i in range(len(allele_index))]
                for x in _fields[6].split(','):
                    allele, count = x.split(':')
                    if allele in allele_index:
                        ac_list[allele_index[allele]] += int(count)
                an = sum(ac_list)
                ac = ','.join([str(i) for i in ac_list[1:]])
                info = f'AC={ac};AN={an};NS={ns};NS_GT={ns_gt};NS_NOGT={ns_nogt};NS_NODATA={ns_nodata}'
                qual = _fields[8]
                filt = 'PASS'
                out = [chrom, pos, '.', ref, alts, qual, filt, info]
                # chrom pos end (1-based inclusive)
                print('\t'.join(out), file=fout)

    utils.run_command(
        f'bgzip -f {sites_vcf_path} && tabix -f {sites_vcf_path}.gz')
    logging.info(
        f'STATS: [census_to_sites_vcf] {message} #pos={npos}, #var={nvar}')

    return npos, nvar


def region_file_count_record(region_file_path, region_str):

    num_records = 0
    region_obj = Region(region_str=region_str)
    contig = region_obj.contig
    pstart = region_obj.pstart
    pend = region_obj.pend
    logging.info(
        f'Counting #records overlapping with region "{region_str}" in "{region_file_path}"')
    with gzip.open(region_file_path, 'rt') as fin:
        for line in fin:
            # #CHROM	POS	END
            # chr1	9999	10000
            # chr1	10001	10002
            if line[0] == '#':
                continue
            _contig, _pstart, _pend = line.strip().split('\t')
            _pstart = int(_pstart)
            _pend = int(_pend)
            if contig != _contig:
                continue
            if _pend < pstart:
                continue
            if _pstart > pend:
                break
            num_records += 1

    return num_records


def region_file_count_record_concurrent(region_file_path_list, region_str):

    concurr_runner = utils.ConcurrencyRunner(
        retry_runner=utils.RetryRunner(max_retries=0))

    result_list = concurr_runner.run(
        region_file_count_record,
        kwargs_list=[
            {'region_file_path': x, 'region_str': region_str}
            for x in region_file_path_list])
    concurr_runner.shutdown()

    return result_list


def census_count_sample(cns_path, message):

    num_samples = 0
    with gzip.open(cns_path, 'rt') as fin:
        for line in fin:
            if line.startswith('##SampleSize='):
                num_samples = int(line.split('=')[1])
                break
    if num_samples == 0:
        raise Exception(
            f'Failed to find sample size from census file "{cns_path}"')

    logging.info(f'STATS: {message} #sample={num_samples}')
    return num_samples


def type_normalize_ref_alt(ref, alt):

    if ref in {'', None} or alt in {'', None}:
        raise Exception(f'Can not normalize ref:alt pair "{ref}":"{alt}"')

    if len(ref) == len(alt) == 1:
        if ref not in 'ACGT' or alt not in 'ACGT':
            raise Exception(
                f'Can not normalize ref:alt pair "{ref}":"{alt}", non ACGT allele found.')
        if ref + alt in {'AG', 'GA', 'CT', 'TC'}:
            # transition
            return 'S', ref, alt
        else:
            # transversion
            return 'V', ref, alt

    if len(ref) == 1 and len(alt) > 1 and alt[0] == ref:
        # insertion
        return 'I', ref, alt

    if len(alt) == 1 and len(ref) > 1 and ref[0] == alt:
        # deletion
        return 'D', ref, alt

    if ref[-1] != alt[-1]:
        # mnv
        return 'M', ref, alt

    return type_normalize_ref_alt(ref[:-1], alt[:-1])


def hash_af(ac: int, an: int):
    # singleton is not marked in this function
    if an == 0:
        raise Exception(f'Can not calculate AF from AC={ac} and AN={an}')
    if ac == 0:
        return 0
    af = ac/an
    # 0 => 0, 1 => 1, 0.1-0.9 => 2, 0.01-0.09 => 3 ...
    return abs(math.floor(math.log10(af)))+1


def hash_gtr(ns_gt, ns):
    bin_list = [1.0, 0.9999, 0.999, 0.99, 0.9, 0.5, 0.1, 0.0]
    for i, b in enumerate(bin_list):
        if ns_gt >= ns*b:
            return i
    # 100 => 0, >99.99% => 1, >99.9% => 2, ...
    return len(bin_list) - 1


def hash_filter(filt):
    # to reduce key length, this hashing is IGG specific
    if filt == 'PASS':
        return '0'
    if filt == 'LowGTR':
        return '1'
    if filt == 'LowMLSQ':
        return '2'
    return filt


def hash_sites_vcf_record(sites_vcf_line):
    """get stats from sites_vcf
    take a record from sites_vcf and hash it into 4 fields: filter, gtr bin, vtype, af bin
    NOTE: do not use this for per batch sites vcf
    """

    # example line
    # chr1	54710	.	A	AT,ATTTTT	44.59	PASS  AC=1,3;AN=12;NS=6;NS_GT=6;NS_NOGT=0;NS_NODATA=0
    chrom, pos, vid, ref, _alts, qual, filt, _info = sites_vcf_line.strip().split('\t')
    alts = _alts.split(',')
    info = dict()
    try:
        for x in _info.split(';'):
            if '=' not in x:
                # this is a flag, e.g. LOW_CONF
                info[x] = True
                continue
            k, v = x.split('=')
            if k == 'AF':
                continue
            if k == 'AC':
                info[k] = [int(i) for i in v.split(',')]
            else:
                info[k] = int(v)
    except Exception as e:
        raise Exception(
            f'Can not parse sites vcf info field "{_info}", error = {e}')

    for k in ['AC', 'AN', 'NS', 'NS_GT', 'NS_NOGT', 'NS_NODATA']:
        if k not in info:
            raise Exception(
                f'Metrics "{k}" is not found in INFO field "{_info}"')

    for k in info:
        if k in ['GAC', 'GAN', 'GNS', 'GNS_GT', 'GNS_NOGT', 'GNS_NODATA']:
            raise Exception(
                f'Found global metrics in INFO field "{_info}", do not use this method for batch VCF.')

    if len(info['AC']) != len(alts):
        raise Exception(
            f'Number of fields mismatch: #alt={len(alts)} #ac={len(info["AC"])}, line: {sites_vcf_line}')

    # key = FILTER : GTR : VTYPE : AF : LOW_CONF
    filt = hash_filter(filt)
    gtr = hash_gtr(info['NS_GT'], info['NS'])
    pos_key = f'{filt}:{gtr}'
    low_conf = 1 if 'LOW_CONF' in info else 0

    allele_key_list = []
    for alt, ac in zip(alts, info['AC']):
        af = hash_af(ac, info['AN'])
        vtype, _ref, _alt = type_normalize_ref_alt(ref, alt)
        key = f'{filt}:{gtr}:{vtype}:{af}:{low_conf}'
        allele_key_list.append(key)
    return pos_key, allele_key_list


def split_sites_vcf_by_contig(sites_vcf_path, output_prefix, max_lines_per_file):

    file_counters = defaultdict(int)
    file_handles = defaultdict(lambda: None)
    output_filename_list = []

    logging.info(f'Splitting sites VCF "{sites_vcf_path}" into subshards with max '
                 f'"{max_lines_per_file}" records per subshard')

    def get_file_handle(contig):
        """Get the file handle for the current contig, and open a new file if needed."""
        file_counter = file_counters[contig] // max_lines_per_file
        output_filename = f"{output_prefix}_{contig}_{file_counter}.vcf"

        if file_handles[contig] is None or file_handles[contig].name != output_filename:
            # Close the previous file handle if it exists
            if file_handles[contig]:
                file_handles[contig].close()

            # Open a new file for the current contig
            utils.prep_output_file(output_filename)
            file_handles[contig] = open(output_filename, 'wt')
            output_filename_list.append(output_filename)

        return file_handles[contig]

    # Read the input file line by line
    contig_set = set()
    npos = 0
    with gzip.open(sites_vcf_path, 'rt') as fin:
        for line in fin:
            if line[0] == '#':
                continue
            data = line.strip().split('\t')
            contig = data[0]
            # map contig to contig index
            contig_set.add(contig)
            contig = f'contig_{len(contig_set)}'

            # Get the correct file handle and write the line
            file_handle = get_file_handle(contig)
            file_handle.write(line)

            # Increment the line count for the key
            file_counters[contig] += 1
            npos += 1

    # Close all open file handles
    for handle in file_handles.values():
        if handle:
            handle.close()

    logging.info(f'Split into {len(output_filename_list)} subshard sites vcfs with '
                 f'output prefix "{output_prefix}", written {npos} sites on '
                 f'{len(contig_set)} contigs')

    return output_filename_list


def make_sites_vcf_stats(sites_vcf_path):
    # NOTE: npos is unique number of positions, not number of records,
    # when there are duplicate of position each with different
    # pos key, npos can be smaller than sum(stats_dict['pos_stats'].values())

    stats_dict = {
        'range': [None, None],
        'npos': 0,
        'nvar': 0,
        'npos_pass': 0,
        'pos_stats': defaultdict(int),
        'allele_stats': defaultdict(int),
    }
    fin = gzip.open(sites_vcf_path, 'rt') if sites_vcf_path.endswith(
        '.gz') else open(sites_vcf_path, 'rt')
    chrom_pos_pass = None
    for line in fin:
        line = line.strip()
        if line[0] == '#':
            continue
        _data = line.split('\t')
        chrom, pos = _data[:2]
        if stats_dict['range'][0] == None:
            stats_dict['range'][0] = [chrom, pos]
        if stats_dict['range'][1] != [chrom, pos]:
            stats_dict['range'][1] = [chrom, pos]
            # update number of unique positions
            stats_dict['npos'] += 1

        filt = _data[6]
        if filt == 'PASS':
            if chrom_pos_pass != [chrom, pos]:
                chrom_pos_pass = [chrom, pos]
                # update number of unique PASS positions, this is the same as npos when the site
                # VCF contains unique positions, but not when sites vcf is from split of multiallelic
                # sites vcf, in this case pos_key (Filter:GTR) from has_sites_vcf_record() may double
                # count positions since one position can have PASS and nonPASS filter depending on
                # the ALT allele
                stats_dict['npos_pass'] += 1

        pos_key, allele_keys = hash_sites_vcf_record(line)
        stats_dict['pos_stats'][pos_key] += 1
        for allele_key in allele_keys:
            stats_dict['allele_stats'][allele_key] += 1
    fin.close()

    # update number of unique variants
    stats_dict['nvar'] = sum(
        [v for k, v in stats_dict['allele_stats'].items()])

    return stats_dict


def make_subshards_stats(
        shard_id, in_sites_vcf_path, out_subshards_stats_path, out_subshards_count_path,
        nsite_subshard):

    tmp_dir = os.path.dirname(os.path.realpath(
        out_subshards_stats_path)) + '/subshards_sites'
    utils.run_command(f'rm -fr {tmp_dir}')
    utils.prep_output_folder(tmp_dir)

    # Split sites vcf into subshard sites vcf based on number of variants
    # NOTE: empty shard will have no subshard sites vcf generated
    subshard_sites_vcf_path_list = split_sites_vcf_by_contig(
        sites_vcf_path=in_sites_vcf_path,
        output_prefix=f'{tmp_dir}/sites_vcf',
        max_lines_per_file=nsite_subshard)

    npos = nvar = 0
    utils.prep_output_file(out_subshards_stats_path)
    utils.prep_output_file(out_subshards_count_path)

    if len(subshard_sites_vcf_path_list) == 0:
        subshard_id = region = stats = '.'
        with open(out_subshards_stats_path, 'wt') as fout:
            print(shard_id, subshard_id, region, npos,
                  nvar, stats, sep='\t', file=fout)
        logging.info(
            f'STATS: [subshards_stats] shard={shard_id}, subshard={subshard_id}, '
            f'#pos=0, #var=0, region={region}')

        with open(out_subshards_count_path, 'wt') as fout:
            print(shard_id, 0, sep=',', file=fout)
        logging.info(
            f'STATS: [subshards_count] shard={shard_id}, #subshard=0')

        logging.info(
            f'STATS: [shard_stats] shard={shard_id}, #pos=0, #var=0')

        utils.run_command(f'rm -fr {tmp_dir}')
        return npos, nvar

    nsubshard = 0
    with open(out_subshards_stats_path, 'wt') as fout:
        for index, subshard_sites_vcf_path in enumerate(subshard_sites_vcf_path_list):
            stats_dict = make_sites_vcf_stats(subshard_sites_vcf_path)
            if stats_dict['npos'] == 0:
                raise Exception(
                    f'subshard VCF is empty, error in splitting subshard VCFs')
            if stats_dict['range'][0][0] != stats_dict['range'][1][0]:
                raise Exception(f'one subshard should not cover two contigs, found '
                                f'{stats_dict["range"][0]} and {stats_dict["range"][1]}')
            _npos = sum([v for k, v in stats_dict['pos_stats'].items()])
            if stats_dict['npos'] != _npos:
                raise Exception(
                    f'subshard sites vcf {subshard_sites_vcf_path} contains records with '
                    f'duplicated positions, this is not expected in sites vcf generated from census.')

            # subshard id is 1-based
            subshard_id = index + 1
            region = f'{stats_dict["range"][0][0]}:{stats_dict["range"][0][1]}-{stats_dict["range"][1][1]}'
            logging.info(f'STATS: [subshards_stats] shard={shard_id}, subshard={subshard_id}, '
                         f'#pos={stats_dict["npos"]}, #var={stats_dict["nvar"]}, region={region}')
            print(shard_id, subshard_id, region, stats_dict["npos"], stats_dict["nvar"],
                  json.dumps(stats_dict), sep='\t', file=fout)
            npos += stats_dict["npos"]
            nvar += stats_dict["nvar"]
            nsubshard += 1

    with open(out_subshards_count_path, 'wt') as fout:
        print(shard_id, nsubshard, sep=',', file=fout)
    logging.info(
        f'STATS: [subshards_count] shard={shard_id}, #subshard={nsubshard}')

    # clean up tmp sites vcfs
    logging.info(
        f'STATS: [shard_stats] shard={shard_id}, #pos={npos}, #var={nvar}')

    utils.run_command(f'rm -fr {tmp_dir}')
    return npos, nvar


def get_subshard_details(subshards_stats_path, shard_id, subshard_id):

    subshard_region = None
    npos = 0
    nvar = 0
    with open(subshards_stats_path, 'rt') as fin:
        for line in fin:
            # shard_id, subshard_id, region, npos, nvar, stats
            data = line.strip().split('\t')
            if data[1] == '.':
                continue
            if int(data[0]) == shard_id and int(data[1]) == subshard_id:
                subshard_region = data[2]
                npos = int(data[3])
                nvar = int(data[4])
                break

    if subshard_region == None:
        raise Exception(f'Shard "{shard_id}" subshard "{subshard_id}" is not found in '
                        f'subshard stats list "{subshards_stats_path}"')

    logging.info(f'STATS: [expectation_stats] shard={shard_id}, subshard={subshard_id}, '
                 f'#pos={npos}, #var={nvar}, region={subshard_region}')
    return subshard_region, npos, nvar


class Region:

    def __init__(self, region_str=None, contig=None, pstart=None, pend=None) -> None:
        if region_str == None:
            self.contig = contig
            self.pstart = pstart
            self.pend = pend
        else:
            self.contig, prange = region_str.rsplit(':', 1)
            pstart, pend = prange.split('-')
            self.pstart, self.pend = int(pstart), int(pend)

    def get_size(self):
        return self.pend - self.pstart + 1

    def get_str(self):
        return f'{self.contig}:{self.pstart}-{self.pend}'

    def split_subregions(self, subregion_size) -> List['Region']:
        subregion_list = []
        for _pstart in range(self.pstart, self.pend + 1, subregion_size):
            _pend = min(_pstart + subregion_size - 1, self.pend)
            subregion = Region(contig=self.contig, pstart=_pstart, pend=_pend)
            subregion_list.append(subregion)
        return subregion_list


def get_concurrency_regions(input_region, num_threads):

    subshard_region_obj = Region(region_str=input_region)
    concurrency_region_size = max(
        1, int(subshard_region_obj.get_size()/num_threads))
    concurrency_region_list = subshard_region_obj.split_subregions(
        concurrency_region_size)
    return ','.join([x.get_str() for x in concurrency_region_list])


def anno_json_count_var(anno_json_path, message):

    npos = 0
    with gzip.open(anno_json_path, 'rt') as fin:
        for line in fin:
            if line.startswith('{"chromosome":'):
                npos += 1
    logging.info(
        f'STATS: [annotation_stats] {message} #pos={npos}')
    return npos


# def sites_vcf_count_var(sites_vcf_path):

#     num_vars = 0
#     contig_list = []
#     contig_set = set()
#     with gzip.open(sites_vcf_path, 'rt') as fin:
#         for line in fin:
#             if line[0] == '#':
#                 continue
#             num_vars += 1
#             contig = line.split('\t')[0]
#             if contig not in contig_set:
#                 contig_set.add(contig)
#                 contig_list.append(contig)
#     logging.info(
#         f'Found "{num_vars}" sites on {len(contig_set)} contigs in "{sites_vcf_path}')
#     return contig_list, num_vars


def vcf_index_count_var(bcftools_path, vcf_path, message):
    # call this after vcf index is generated

    if not os.path.isfile(vcf_path+'.tbi') and \
            not os.path.isfile(vcf_path+'.csi'):
        raise Exception(
            f'Can not generate stats of VCF "{vcf_path}", index not found.')

    cmd = [
        f'{bcftools_path}',
        f'index',
        f'--nrecords',
        f'{vcf_path}',
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, text=True)
    nline = result.stdout.strip()
    if nline == '':
        nline = 0
    else:
        nline = int(nline)
    logging.info(f'STATS: {message} #line={nline}')

    return nline


def pvar_count_var(pvar_path, message):

    nline = 0
    loc = None
    npos = 0
    filt_stats = dict()
    for line in open(pvar_path):
        if line[0] == '#':
            continue
        nline += 1
        data = line.strip().split()
        if loc != data[:2]:
            loc = data[:2]
            npos += 1
        filt = data[6]
        if filt not in filt_stats:
            filt_stats[filt] = 0
        filt_stats[filt] += 1

    logging.info(
        f'STATS: {message} #line={nline} #pos={npos} filt_stats={json.dumps(filt_stats)}')

    return nline, npos, filt_stats


def psam_count_sample(psam_path, message):

    nsample = 0
    gender_stats = dict()
    with open(psam_path, 'rt') as fin:
        for line in fin:
            if line[0] == '#':
                continue
            nsample += 1
            gender = line.strip().split()[2]
            if gender not in gender_stats:
                gender_stats[gender] = 0
            gender_stats[gender] += 1

    logging.info(
        f'STATS: {message} #sample={nsample} gender_stats={json.dumps(gender_stats)}')
    return nsample, gender_stats


def vcf_get_samples(vcf_path, message):

    sample_list = []
    with gzip.open(vcf_path, 'rt') as fin:
        for line in fin:
            if line[:2] == '##':
                continue
            if line[0] != '#':
                break
            data = line.strip().split('\t')
            sample_list = data[9:]

    logging.info(f'STATS: {message} #sample={len(sample_list)}')
    return sample_list


def write_sample_gender(sample_list, out_path):

    utils.prep_output_file(out_path)
    with open(out_path, 'w') as f:
        print(f'#FID\tIID\tSEX', file=f)
        for s in sample_list:
            print(s, s, '0', sep='\t', file=f)

    logging.info(
        f'Written "{len(sample_list)}" sample gender info to list "{out_path}"')


def write_region_tsv(in_region_csv_str, out_region_tsv):

    utils.prep_output_file(out_region_tsv)
    nregion = 0
    with open(out_region_tsv, 'wt') as fout:
        for region in in_region_csv_str.split(','):
            region_obj = Region(region_str=region)
            print(region_obj.contig, region_obj.pstart,
                  region_obj.pend, sep='\t', file=fout)
            nregion += 1
    logging.info(f'Written {nregion} regions to {out_region_tsv}')


def download_using_bcftools(
        bcftools_path, remote_file_url, remote_index_url, local_file_path,
        region_csv, num_threads=16):
    # this function works with VCF or gVCF, not cohort/census
    # TODO: sample renaming

    # NOTE: bcftools view supports csv like region string, but without *: in contig name
    # more generically, multi-region can be handled always using a TSV file
    # with (3 tab-delimited cols: chrom, start 1-based inclusive, end 1-based inclusive)

    # make region tsv file
    region_tsv_file = local_file_path + '.regions.tsv'
    write_region_tsv(region_csv, region_tsv_file)

    def _download_using_bcftools():

        _local_index_file = os.path.basename(remote_index_url.split('?')[0])
        if not _local_index_file.endswith('.tbi') and not _local_index_file.endswith('.csi'):
            raise Exception(
                f'remote index url does not end with tbi or csi, "{remote_index_url}"')

        utils.run_command(f'rm -fr {local_file_path} {_local_index_file}')
        utils.prep_output_file(local_file_path)

        bcftools_cmd_root = [
            f'{bcftools_path}',
            f'view',
            f'--no-version',
            f'--compression-level 1',
            f'--output-type z',
            f'--output "{local_file_path}"',
            f'--threads {num_threads}',
            f'--regions-file {region_tsv_file}',
            f'--regions-overlap 0',
        ]
        bcftools_cmd = bcftools_cmd_root + \
            [f'"{remote_file_url}##idx##{remote_index_url}"']
        bcftools_cmd_log = bcftools_cmd_root + [f"<presign_url>"]

        # NOTE: do not use run_command() as we want to capture stdout/stderr
        bcftools_cmd = ' '.join(bcftools_cmd)
        bcftools_cmd_log = ' '.join(bcftools_cmd_log)
        logging.info(f'Running Bcftools partial download: {bcftools_cmd_log}')
        result = subprocess.run(
            bcftools_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True)
        bcftools_log = {
            'ecode': result.returncode,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'cmd': bcftools_cmd_log,
        }
        logging.info(f'Bcftools partial download log: {bcftools_log}')

        def known_bcftools_warnning(stderr_str):
            # do not fail download if the warning is known
            # depending on bcftools version, the warning may have different headers
            # bcftools 1.17: [W::vcf_parse_format]
            # bcftools 1.21: [W::vcf_parse_format_fill5]
            description = 'Extreme FORMAT/PL value encountered and set to missing at'
            if description in stderr_str.strip():
                return True
            return False

        if result.returncode or result.stdout != '':
            raise Exception(
                f'bcftools view exits with ecode {result.returncode}, log: {bcftools_log}')
        if result.stderr != '' and not known_bcftools_warnning(result.stderr):
            raise Exception(
                f'bcftools view exits with unknown warning, log: {bcftools_log}')

        utils.run_command(f'rm -fr {_local_index_file}')

        index_option = '--tbi'
        if _local_index_file.endswith('.csi'):
            index_option = '--csi'
        ecode = utils.run_command(
            f'{bcftools_path} index --threads {num_threads} --force {index_option} '
            f'{local_file_path}')
        if ecode:
            raise Exception(f'bcftools index exits with ecode: {ecode}')

    # massive retry on all kinds of exceptions including low level connection errors
    result = utils.RetryRunner(max_retries=1000).run(
        func=_download_using_bcftools)

    utils.run_command(f'rm -fr {region_tsv_file}')

    logging.info(
        f'Successfully partial-downloaded file "{local_file_path}" '
        f'in region "{region_csv}"')

    return result


def download_using_bcftools_concurrent(
        bcftools_path, remote_file_url_list, remote_index_url_list, local_file_path_list,
        region_csv):

    concurr_runner = utils.ConcurrencyRunner(
        retry_runner=utils.RetryRunner(max_retries=0))

    kwargs_list = []
    for remote_file_url, remote_index_url, local_file_path in zip(
            remote_file_url_list, remote_index_url_list, local_file_path_list):
        kwargs_list.append({
            'bcftools_path': bcftools_path,
            'remote_file_url': remote_file_url,
            'remote_index_url': remote_index_url,
            'local_file_path': local_file_path,
            'region_csv': region_csv,
        })

    result_list = concurr_runner.run(
        download_using_bcftools, kwargs_list=kwargs_list)
    concurr_runner.shutdown()

    return result_list


def download_using_tabix(
        tabix_path, bgzip_path, remote_file_url, remote_index_url, local_file_path,
        region_csv, num_records=-1, num_threads=16):
    # this function works with cohort/census

    # make region tsv file
    region_tsv_file = local_file_path + '.regions.tsv'
    write_region_tsv(region_csv, region_tsv_file)

    tmp_dir = local_file_path + '.tmp'
    utils.prep_output_folder(tmp_dir)

    def _download_using_tabix():

        _local_index_file = os.path.basename(remote_index_url.split('?')[0])
        if not _local_index_file.endswith('.tbi') and not _local_index_file.endswith('.csi'):
            raise Exception(
                f'remote index url does not end with tbi or csi, "{remote_index_url}"')

        # retry on record mismatch
        max_retry = 1000
        records_match = False
        _num_records = 0
        for retry in range(max_retry):
            utils.run_command(f'rm -fr {local_file_path}')
            utils.prep_output_file(local_file_path)

            # NOTE: tabix v1.15.1 still does not support --threads
            tabix_cmd = [
                f'cd {tmp_dir} &&'
                f'{tabix_path}',
                f'--print-header',
                f'--regions {region_tsv_file}',
                f'"{remote_file_url}##idx##{remote_index_url}"',
                f'| {bgzip_path} >',
                f'{local_file_path}',
            ]
            tabix_cmd_log = [
                f'cd {tmp_dir} &&'
                f'{tabix_path}',
                f'--print-header',
                f'--regions {region_tsv_file}',
                f'<presign_url>',
                f'| {bgzip_path} >',
                f'{local_file_path}',
            ]
            ecode = utils.run_command(tabix_cmd, command_log=tabix_cmd_log)
            if ecode:
                raise Exception(f'tabix exits with ecode: {ecode}')

            # if num_records < 0:
            #     # do not check number of records
            #     break

            _num_records = 0
            with gzip.open(local_file_path, 'rt') as fin:
                for line in fin:
                    if line[0] == '#':
                        continue
                    _num_records += 1

            if num_records == _num_records:
                records_match = True
                break

            logging.warning(
                f'Tabix partial download output file records mismatch, expected {num_records}, '
                f'found {_num_records}, retry downloading now, '
                f'region: "{region_csv}", '
                f'local file: {local_file_path}, '
                f'remote url: <presign_url> '
                f'(retry: {retry}/{max_retry})')

        if not records_match:
            raise Exception(
                f'Tabix partial download output file records mismatch, expected {num_records}, '
                f'found {_num_records}, retry exhausted, '
                f'region: "{region_csv}", '
                f'local file: {local_file_path}, '
                f'remote url: <presign_url> ')

        index_option = ''
        if _local_index_file.endswith('.csi'):
            index_option = '--csi'
        cols_option = ''
        if local_file_path.endswith('.cht.gz') or local_file_path.endswith('.cns.gz'):
            cols_option = '--sequence 1 --begin 2 --end 3'
        ecode = utils.run_command(
            f'{tabix_path} --force {index_option} '
            f'{cols_option} '
            f'{local_file_path}')
        if ecode:
            raise Exception(f'tabix index exits with ecode: {ecode}')

    result = utils.RetryRunner(max_retries=1000).run(
        func=_download_using_tabix)

    utils.run_command(f'rm -fr {region_tsv_file}')
    utils.run_command(f'rm -fr {tmp_dir}')

    logging.info(
        f'Successfully partial-downloaded file "{local_file_path}" with {num_records} records '
        f'in region "{region_csv}"')

    return result


def download_using_tabix_concurrent(
        tabix_path, bgzip_path, remote_file_url_list, remote_index_url_list, local_file_path_list,
        region_csv, num_records_list):

    concurr_runner = utils.ConcurrencyRunner(
        retry_runner=utils.RetryRunner(max_retries=0))

    kwargs_list = []
    for remote_file_url, remote_index_url, local_file_path, num_records in zip(
            remote_file_url_list, remote_index_url_list, local_file_path_list, num_records_list):
        kwargs_list.append({
            'tabix_path': tabix_path,
            'bgzip_path': bgzip_path,
            'remote_file_url': remote_file_url,
            'remote_index_url': remote_index_url,
            'local_file_path': local_file_path,
            'region_csv': region_csv,
            'num_records': num_records,
        })

    result_list = concurr_runner.run(
        download_using_tabix, kwargs_list=kwargs_list)
    concurr_runner.shutdown()

    return result_list


def concat_vcf(bcftools_path, mimalloc_path, time_log, num_threads,
               in_vcf_list_path, out_vcf_path, index_vcf):

    utils.prep_output_file(out_vcf_path)

    nvcf = 0
    _vcf_path = None
    for line in open(in_vcf_list_path):
        nvcf += 1
        _vcf_path = line.strip()

    if nvcf == 1:

        logging.info(f'Only 1 VCF to concat, will just copy')

        ecode = utils.run_command(
            f'cp -v {_vcf_path} {out_vcf_path}')
        if ecode:
            return ecode

        ecode = utils.run_command(
            f'cp -v {_vcf_path}.tbi {out_vcf_path}.tbi')
        if ecode:
            return ecode

        return 0

    logging.info(f'Concat {nvcf} VCFs')

    concat_vcf_cmd = [
        f'LD_PRELOAD={mimalloc_path}',
        f'/usr/bin/time -v -a -o {time_log}',
        f'{bcftools_path}',
        f'concat',
        f'--naive-force',
        f'--no-version',
        f'--threads {num_threads}',
        f'--file-list {in_vcf_list_path}',
        f'-Oz',
        f'--output {out_vcf_path}',
    ]

    ecode = utils.run_command(concat_vcf_cmd)
    if ecode:
        return ecode

    if index_vcf:

        tabix_vcf_cmd = [
            f'LD_PRELOAD={mimalloc_path}',
            f'/usr/bin/time -v -a -o {time_log}',
            f'{bcftools_path}',
            f'index',
            f'--threads {num_threads}',
            f'--force',
            f'--tbi',
            f'{out_vcf_path}',
        ]

        ecode = utils.run_command(tabix_vcf_cmd)
        if ecode:
            return ecode

    return 0


def concat_anno_json(dotnet_path, jist_path, jasix_path, mimalloc_path, time_log, num_threads,
                     in_json_folder_path, in_json_prefix, out_json_gz_path):

    utils.prep_output_file(out_json_gz_path)

    njson = 0
    _json_path = None
    for line in os.listdir(in_json_folder_path):
        if line.endswith('.json.gz') and line.startswith(in_json_prefix):
            _json_path = f'{in_json_folder_path}/{line}'
            njson += 1

    if njson == 1:

        logging.info(f'Only 1 JSON to concat, will just copy')

        ecode = utils.run_command(
            f'cp -v {_json_path} {out_json_gz_path}')
        if ecode:
            return ecode

        ecode = utils.run_command(
            f'cp -v {_json_path}.jsi {out_json_gz_path}.jsi')
        if ecode:
            return ecode

        return 0

    logging.info(f'Concat {njson} JSON files')

    concat_json_cmd = [
        f'LD_PRELOAD={mimalloc_path}',
        f'/usr/bin/time -v -a -o {time_log}',
        f'{dotnet_path}',
        f'{jist_path}',
        f'--in {in_json_folder_path}/{in_json_prefix}',
        f'--out {out_json_gz_path}',
    ]

    index_json_cmd = [
        f'LD_PRELOAD={mimalloc_path}',
        f'/usr/bin/time -v -a -o {time_log}',
        f'{dotnet_path}',
        f'{jasix_path}',
        f'--in {out_json_gz_path}',
        f'--index',
    ]

    for cmd in [concat_json_cmd, index_json_cmd]:
        ecode = utils.run_command(cmd)
        if ecode:
            return ecode

    return 0


def concat_pgen(plink2_path, mimalloc_path, time_log, num_threads, max_ram,
                in_pgen_prefix_list_path, out_pgen_prefix):

    utils.prep_output_file(out_pgen_prefix)

    npgen = 0
    _pgen_prefix = None
    for line in open(in_pgen_prefix_list_path):
        npgen += 1
        _pgen_prefix = line.strip()

    if npgen == 1:

        logging.info(f'Only 1 PGEN to concat, will just copy')

        for x in ['.pgen', '.psam', '.pvar']:
            ecode = utils.run_command(
                f'cp -v {_pgen_prefix}{x} {out_pgen_prefix}{x}')
            if ecode:
                return ecode
        return 0

    # get _gender_list_path from one of the psam
    _gender_list_path = _pgen_prefix + '.psam'

    # when concat chrX, do not use --update-sex or --split-par as
    # --split-par errors out if the dataset already contains a PAR1 or PAR2 region.
    concat_pgen_cmd = [
        f'LD_PRELOAD={mimalloc_path}',
        f'/usr/bin/time -v -a -o {time_log}',
        f'{plink2_path}',
        f'--pmerge-list {in_pgen_prefix_list_path}',
        f'--make-pgen',
        f'--double-id',
        f'--threads {num_threads}',
        f'--memory {max_ram}',
        f'--out {out_pgen_prefix}',
        # f'--update-sex {_gender_list_path}',
        # f'--split-par hg38',
    ]
    ecode = utils.run_command(concat_pgen_cmd)
    if ecode:
        return ecode

    # clean up merge file (dragen-merge.pgen  dragen-merge.psam  dragen-merge.pvar)
    utils.run_command(f'rm -fr {out_pgen_prefix}-merge.*')

    return 0


def get_gvcf_dragen_version(gvcf_path):

    # giab-v378-orig/HG001_PrecFDA.hard-filtered.gvcf.gz
    # ##DRAGENCommandLine=<ID=dragen,Version="SW: 07.021.604.3.7.8, HW: 07.021.604",Date="Mon Aug 15 12:25

    # giab-v403/HG001_PrecFDA.hard-filtered.gvcf.gz
    # ##DRAGENCommandLine=<ID=dragen,Version="SW: 07.021.645.4.0.3, HW: 07.021.645",Date="Wed Jul 27 16:50

    # giab-v378-recal/HG001_PrecFDA.hard-filtered.recal.gvcf.gz
    # ##DRAGENCommandLine=<ID=dragen,Version="SW: 01.003.044.4.2.4u-1-g4ad24553, HW: 01.003.044",Date="Tue

    # giab-v427/HG001_PrecFDA.hard-filtered.gvcf.gz
    # ##DRAGENCommandLine=<ID=dragen,Version="SW: 07.031.677.4.2.7, HW: 07.031.677",Date="Fri Oct 18 22:03

    # giab-v436/HG001_PrecFDA.hard-filtered.gvcf.gz
    # ##DRAGENCommandLine=<ID=dragen,Version="SW: 05.121.732.4.3.6, HW: 05.121.732",Date="Sat Aug 24 07:11

    gvcf_version = []
    with gzip.open(gvcf_path, 'rt') as fin:
        for line in fin:
            if line.startswith('##DRAGENCommandLine=<ID=dragen,Version='):
                try:
                    gvcf_version = line.split('"')[1].split()[
                        1].rstrip(',').split('.')[3:]
                except:
                    raise Exception(
                        f'Failed to parse DRAGEN version from gVCF "{gvcf_path}" '
                        f'header line: {line}')
                break

    if len(gvcf_version) != 3:
        raise Exception(
            f'Expected 3 fields from gVCF version, found {gvcf_version}, '
            f'please check gvcf file "{gvcf_path}"')

    return gvcf_version


def annotate_sites_vcf(sites_vcf_path, low_conf_bed_path, message,
                       bcftools_path='/usr/local/bin/bcftools'):

    if not sites_vcf_path.endswith('.vcf.gz'):
        raise Exception(
            f'*ERROR* sites_vcf_path must be a gzipped vcf file, '
            f'please check sites_vcf_path: {sites_vcf_path}')

    tmp_sites_vcf_path = sites_vcf_path[:-3]
    annotate_cmd = [
        f'{bcftools_path}',
        f'annotate',
        f'--no-version',
        f'-a {low_conf_bed_path}',
        f'-c CHROM,FROM,TO',
        f'-m LOW_CONF',
        f'-H \'##INFO=<ID=LOW_CONF,Number=0,Type=Flag,Description="Variant overlaps with low confidence region">\'',
        f'-Ov -o {tmp_sites_vcf_path}',
        f'{sites_vcf_path}',
    ]
    utils.run_command(annotate_cmd)
    utils.run_command(
        f'rm -fr {sites_vcf_path} {sites_vcf_path}.tbi')
    utils.run_command(
        f'bgzip -f {tmp_sites_vcf_path} && tabix -f {tmp_sites_vcf_path}.gz')

    logging.info(
        f'STATS: [annotate_sites_vcf] {message} annotated with low confidence bed {low_conf_bed_path}')
