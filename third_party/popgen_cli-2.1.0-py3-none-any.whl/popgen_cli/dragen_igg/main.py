from __future__ import annotations
import popgen_cli.utils.utils as utils
import popgen_cli.dragen_igg.config as config
import popgen_cli.dragen_igg.submit as submit
import argparse


def parse_args(sys_args):

    usage = f"""
  {utils.get_package_name()} dragen-igg [action] [args]

description:
  manage Iterative Gvcf Genotyper workflow

available actions:
  config      config Iterative Gvcf Genotyper project and pipeline
  submit      submit Iterative Gvcf Genotyper analysis

"""

    parser = argparse.ArgumentParser(usage=usage)
    parser.add_argument(
        'action', metavar='action',
        help='actions to manage Iterative Gvcf Genotyper workflow, see actions above')

    return parser.parse_args(sys_args[1:2])


def main(sys_args):

    args = parse_args(sys_args)

    if args.action == 'config':
        config.main(sys_args[2:])

    elif args.action == 'submit':
        submit.main(sys_args[2:])

    else:
        print(f'*ERROR* dragen-igg workflow action "{args.action}" is not supported.')
