import logging
import subprocess
import hashlib
import time
import os
import select
import threading
import queue
import json
import re
from typing import Callable, Any, Tuple, Dict, Optional, List, Union
from concurrent.futures import ThreadPoolExecutor, as_completed
import boto3
import requests
from pprint import pprint
import base64
import datetime
import uuid
import getpass
import string
import traceback
import sys
from popgen_cli import __version__


def enqueue_output(out, queue):
    for line in iter(out.readline, ''):
        queue.put(line)
    out.close()


def run_command(command, command_log=None):
    # if command contains sensitive info (e.g. credentials, presign URLs),
    # provide what can be visible to logger in command_log
    if command_log == None:
        command_log = command

    if isinstance(command, list):
        command = ' '.join(command)
    if isinstance(command_log, list):
        command_log = ' '.join(command_log)

    logging.info(f'Running command: {command_log}')
    process = subprocess.Popen(
        command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, executable="/bin/bash",
    )

    stdout_queue = queue.Queue()
    stderr_queue = queue.Queue()

    stdout_thread = threading.Thread(
        target=enqueue_output, args=(process.stdout, stdout_queue))
    stderr_thread = threading.Thread(
        target=enqueue_output, args=(process.stderr, stderr_queue))
    stdout_thread.start()
    stderr_thread.start()

    while True:
        try:
            stdout_line = stdout_queue.get_nowait()
        except queue.Empty:
            stdout_line = None

        try:
            stderr_line = stderr_queue.get_nowait()
        except queue.Empty:
            stderr_line = None

        if stdout_line:
            logging.info('[STDOUT] ' + stdout_line.strip())
        if stderr_line:
            logging.info('[STDERR] ' + stderr_line.strip())

        if process.poll() is not None:
            break

    stdout_thread.join()
    stderr_thread.join()

    # Capture remaining output after process completes
    while not stdout_queue.empty():
        logging.info('[STDOUT] ' + stdout_queue.get().strip())

    while not stderr_queue.empty():
        logging.info('[STDERR] ' + stderr_queue.get().strip())

    exit_code = process.returncode

    # Check for pipe fail error
    if exit_code != 0:
        logging.error(f'Command "{command_log}" exited with code {exit_code}')

    return exit_code


def create_md5(file_path):
    """
    Calculate the MD5 hash of a given file.

    :param file_path: The path to the file to hash.
    :return: The MD5 hash of the file.
    """
    md5_hash = hashlib.md5()
    buffer = 4096
    try:
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(buffer), b""):
                md5_hash.update(chunk)
        md5 = md5_hash.hexdigest()
        with open(file_path + '.md5', 'w') as f:
            print(md5 + "  " + os.path.basename(file_path), file=f)
        return md5
    except Exception as e:
        logging.error(
            f'Failed to calculate md5sum of file "{file_path}", error: {e}')
        raise e


def check_md5(md5_file_path):
    """return True if md5sum check is OK, False otherwise"""

    if not os.path.isfile(md5_file_path):
        raise Exception(f'Can not open md5 file "{md5_file_path}"')

    file_path = md5_file_path[:-len('.md5')]
    if not os.path.isfile(file_path):
        raise Exception(f'Can not open file "{file_path}" to check md5')

    md5_expected = None
    for line in open(md5_file_path):
        _data = line.strip().split()
        if len(_data):
            md5_expected = _data[0]
    if md5_expected == None:
        raise Exception(f'Failed to read md5 from "{md5_file_path}"')

    md5_hash = hashlib.md5()
    buffer = 4096
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(buffer), b""):
            md5_hash.update(chunk)
    md5 = md5_hash.hexdigest()

    if md5 != md5_expected:
        logging.warning(f'File "{file_path}" md5 mismatch: expected "{md5_expected}" '
                        f'found "{md5}"')
        return False
    return True


def config_logging(level: int = logging.INFO):

    class CustomFormatter(logging.Formatter):
        def formatTime(self, record, datefmt=None):
            if datefmt:
                return super().formatTime(record, datefmt)
            else:
                ct = self.converter(record.created)
                t = time.strftime("%Y-%m-%d %H:%M:%S", ct)
                s = "%s,%03d" % (t, record.msecs)
                return s

    # Remove any existing handlers to avoid duplicate logs
    for handler in logging.getLogger().handlers:
        logging.getLogger().removeHandler(handler)

    # Create a StreamHandler to write logs to stdout
    handler = logging.StreamHandler(sys.stdout)
    format_str = '%(asctime)s - %(levelname)s - %(message)s'
    handler.setFormatter(CustomFormatter(format_str))

    # Configure the root logger
    logging.getLogger().setLevel(level)
    logging.getLogger().addHandler(handler)


def prep_output_file(filename):
    os.makedirs(os.path.dirname(os.path.realpath(filename)), exist_ok=True)


def prep_output_folder(foldername):
    os.makedirs(os.path.realpath(foldername), exist_ok=True)


def early_exit(ecode, name, cmd):

    logging.error(
        f'{name} failed with exit code {ecode}, cmd = "{cmd}", early exit now.')
    return ecode


def success_exit(message):

    bar_length = len(message) + 14
    logging.info('='*bar_length)
    logging.info(f'       {message}       ')
    logging.info('='*bar_length)
    return 0


def parse_url(url: str):

    if '://' not in url:
        raise Exception(f'Failed to parse URL without "://" "{url}"')

    # Split the URL at '://'
    scheme, remainder = url.split('://', 1)
    if remainder == '' or remainder.startswith('/'):
        raise Exception(
            f'Failed to parse URL without domain part after :// "{url}"')

    # remainder can be a, a/, a/b, a/b/, a/b/c, a/b/c/
    # Split the remainder at the first '/'
    if '/' not in remainder or (remainder[-1] == '/' and '/' not in remainder[:-1]):
        # a, a/ => a
        domain = remainder.strip('/')
        return [scheme, domain, '']

    else:
        # trailing / is preserved if present
        # a/b => a, /b
        # a/b/ => a, /b/
        # a/b/c => a, /b/c
        # a/b/c/ => a, /b/c/
        domain, path = remainder.split('/', 1)
        return [scheme, domain, '/' + path]


def get_remote_file_size(url: str):

    def _get_size_from_url(url):
        try:
            response = requests.get(
                url=url, headers={"Range": "bytes=0-0"}, stream=True)
            # raise issue when status code is not 2xx or 3xx
            response.raise_for_status()
            # example of header field with size info: Content-Range: bytes 0-0/7
            return int(response.headers['Content-Range'].split('/')[-1])
        except Exception as e:
            logging.error(
                f'Failed to get file size from URL, error = {e.__dict__}, URL = "{url}"')
            raise

    return RetryRunner().run(func=_get_size_from_url, url=url)


def get_local_file_size(file_path: str):
    return os.path.getsize(file_path)


def read_json(filename):
    try:
        return json.loads(open(filename).read())
    except Exception as e:
        logging.error(f'Failed to read json file "{filename}", error: {e}')
        raise e


def write_json(data, filename, indent=None):
    try:
        prep_output_file(filename)
        with open(filename, 'w') as fout:
            print(json.dumps(data, indent=indent), file=fout)
    except Exception as e:
        logging.error(f'Failed to write json file "{filename}", error: {e}')
        raise e


def get_all_local_files(local_folder):
    # return realpath local folder and relative path of files and size
    # '/local/path/folder/test', {'foo/bar/hello.txt': 6}

    local_folder = os.path.realpath(local_folder)
    if not os.path.isdir(local_folder):
        raise Exception(f'Local folder "{local_folder}" does not exist.')

    file_size_dict = {}
    # Iterate over all the directories and files
    for root, dirs, files in os.walk(local_folder):
        for file in files:
            file_path = os.path.join(root, file)
            file_size = os.path.getsize(file_path)
            file_relpath = file_path[len(local_folder)+1:]
            file_size_dict[file_relpath] = file_size

    return local_folder, file_size_dict

# ======= generic runners =======


class RetryRunner:
    def __init__(
            self, max_retries: int = 7, backoff_factor: float = 0.5, max_backoff: int = 60,
            exceptions_to_retry: Optional[Tuple[type, ...]] = None):
        """
        Initialize the RetryRunner.

        :param max_retries: Maximum number of retries before giving up.
        :param backoff_factor: Backoff factor for exponential backoff.
        :param exceptions_to_retry: Tuple of exception types to trigger a retry.
        :param max_backoff: max sleep time between each retry

        to turn off retry, set max_retries = 0
        """
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.exceptions_to_retry = exceptions_to_retry or (Exception,)
        self.max_backoff = max_backoff

    def run(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """
        Execute the given function with retries on failure.

        :param func: The function to execute.
        :param args: Positional arguments for the function.
        :param kwargs: Keyword arguments for the function.
        :return: The result of the function execution.
        """
        attempt = 0
        while attempt <= self.max_retries:
            try:
                result = func(*args, **kwargs)
                return result
            except self.exceptions_to_retry as e:
                attempt += 1
                if attempt > self.max_retries:
                    logging.error(
                        f"Function {func.__name__} failed after {self.max_retries} retries.")
                    raise
                else:
                    wait_time = min(
                        self.max_backoff, self.backoff_factor * (2 ** (attempt - 1)))
                    logging.warning(
                        f"Function {func.__name__} failed with {e}. Retrying in {wait_time} seconds... "
                        f"(Attempt {attempt}/{self.max_retries})")
                    time.sleep(wait_time)


class ConcurrencyRunner:
    def __init__(self, retry_runner: Optional[RetryRunner] = None, max_workers: Optional[int] = None):
        """
        Initialize the ConcurrencyRunner.

        :param max_workers: The maximum number of threads that can be used to execute the given calls.
        If None, it will default to the number of processors on the machine, multiplied by 5.
        """
        self.max_workers = max_workers or os.cpu_count()
        self.retry_runner = retry_runner or RetryRunner()
        self.executor = ThreadPoolExecutor(max_workers=self.max_workers)

    def run(
            self, funcs: Union[Callable, List[Callable]],
            args_list: Optional[List[Tuple]] = None,
            kwargs_list: Optional[List[Dict[str, Any]]] = None) -> List[Any]:
        """
        Execute the given function concurrently with the provided arguments.

        :param func: The function to execute.
        :param args_list: A list of tuples, each containing positional arguments for the function.
        :param kwargs_list: A list of dictionaries, each containing keyword arguments for the function.
        :return: A list of results from the function executions.
        """

        num_jobs = 0
        if args_list == None and kwargs_list == None:
            if not isinstance(funcs, list):
                funcs = [funcs]
                args_list = [()]
                kwargs_list = [{}]
            else:
                args_list = [()] * len(funcs)
                kwargs_list = [{}] * len(funcs)

        elif args_list == None and kwargs_list != None:
            if not isinstance(funcs, list):
                funcs = [funcs] * len(kwargs_list)
            else:
                if len(funcs) != len(kwargs_list):
                    raise Exception(f'Mismatch between #funcs ({len(funcs)}) and #kwargs '
                                    f'({len(kwargs_list)}) to run concurrently')
            args_list = [()] * len(kwargs_list)

        elif kwargs_list == None and args_list != None:
            if not isinstance(funcs, list):
                funcs = [funcs] * len(args_list)
            else:
                if len(funcs) != len(args_list):
                    raise Exception(f'Mismatch between #funcs ({len(funcs)}) and #args '
                                    f'({len(args_list)}) to run concurrently')
            kwargs_list = [{}] * len(args_list)

        else:
            if len(args_list) != len(kwargs_list):
                raise Exception(f'Mismatch between #args ({len(args_list)}) and #kwargs '
                                f'({len(kwargs_list)}) to run concurrently')
            if not isinstance(funcs, list):
                funcs = [funcs] * len(kwargs_list)
            else:
                if len(funcs) != len(kwargs_list):
                    raise Exception(f'Mismatch between #funcs ({len(funcs)}) and #kwargs '
                                    f'({len(kwargs_list)}) to run concurrently')

        futures = []
        results = []

        for func, args, kwargs in zip(funcs, args_list, kwargs_list):
            future = self.executor.submit(
                self.retry_runner.run, func, *args, **kwargs)
            futures.append(future)

        for future in futures:
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                logging.error(f"Function execution failed: {e}")
                results.append(e)
                raise

        return results

    def shutdown(self):
        """
        Shutdown the executor and free resources.
        """
        self.executor.shutdown(wait=True)


# ======= low level ICA utils =======

class ICAClient:
    def __init__(self, api_key: str, base_url: str = None, retry_runner: Optional[RetryRunner] = None):
        """
        Initialize the APICaller.

        :param base_url: The base URL for the API endpoints.
        """

        self.api_key = api_key
        self.base_url = base_url or 'https://ica.illumina.com/ica/rest/api'
        self.retry_runner = retry_runner or RetryRunner()
        self.cache = dict()

    def _get_cache(self, name, key):
        if name in self.cache and key in self.cache[name]:
            return self.cache[name][key]
        return None

    def _drop_cache(self, name, key):
        if name in self.cache and key in self.cache[name]:
            self.cache[name].pop(key)

    def _set_cache(self, name, key, value):
        if name not in self.cache:
            self.cache[name] = dict()
        self.cache[name][key] = value

    def _dump_cache(self, fname=None):
        if fname:
            write_json(self.cache, fname)
        else:
            print(json.dumps(self.cache, indent=4))

    def _set_cache_using_project_config(self, project_config_dict):
        # see members in ICAConfig class

        project_name = project_config_dict['ica_job_project']['name']
        project_meta_folder_path = project_config_dict[
            'ica_job_project_meta_folder']['data']['details']['path']
        project_jobs_folder_path = project_config_dict[
            'ica_job_project_jobs_folder']['data']['details']['path']
        project_config_file_path = project_config_dict[
            'ica_job_project_config_file']['data']['details']['path']
        analysis_storage_name = project_config_dict['ica_analysis_storage']['name']
        pipeline_name = project_config_dict['ica_analysis_pipeline']['pipeline']['code']
        activation_code_name = project_config_dict['ica_analysis_activation_code']['pipelineBundle']['name']

        self._set_cache(
            'region',
            project_config_dict['ica_region']['code'],
            project_config_dict['ica_region'])

        self._set_cache(
            'storage_bundle',
            project_config_dict['ica_storage_bundle']['bundleName'],
            project_config_dict['ica_storage_bundle'])

        if project_config_dict['ica_storage_configuration']:
            self._set_cache(
                'storage_configuration',
                project_config_dict['ica_storage_configuration']['name'],
                project_config_dict['ica_storage_configuration'])

        self._set_cache(
            'project',
            project_config_dict['ica_job_project']['name'],
            project_config_dict['ica_job_project'])

        self._set_cache(
            'project_data',
            f'{project_name}:{project_meta_folder_path}:FOLDER',
            project_config_dict['ica_job_project_meta_folder'])

        self._set_cache(
            'project_data',
            f'{project_name}:{project_jobs_folder_path}:FOLDER',
            project_config_dict['ica_job_project_jobs_folder'])

        self._set_cache(
            'project_data',
            f'{project_name}:{project_config_file_path}:FILE',
            project_config_dict['ica_job_project_config_file'])

        self._set_cache(
            'project_analysis_storage',
            f'{project_name}:{analysis_storage_name}',
            project_config_dict['ica_analysis_storage'])

        self._set_cache(
            'project_pipeline',
            f'{project_name}:{pipeline_name}',
            project_config_dict['ica_analysis_pipeline'])

        self._set_cache(
            'activation_code',
            f'{project_name}:{pipeline_name}:{activation_code_name}',
            project_config_dict['ica_analysis_activation_code'])

    def _set_cache_using_project_data(self, project_details, project_data_details):

        project_name = project_details['name']
        project_data_path = project_data_details['data']['details']['path']
        project_data_type = project_data_details['data']['details']['dataType']
        self._set_cache(
            'project',
            project_details['name'],
            project_details)

        self._set_cache(
            'project_data',
            f'{project_name}:{project_data_path}:{project_data_type}',
            project_data_details)

    def _request_base(self, method: str, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs: Any):
        """
        Make an API request.

        :param method: HTTP method (GET, POST, PUT, DELETE).
        :param endpoint: API endpoint (appended to the base URL).
        :param kwargs: Additional arguments passed to requests method (e.g., params, data, json, headers).
        :return: Response JSON if the request is successful.
        :raises APIException: If the response status code is greater than or equal to 400.
        """
        url = f"{self.base_url}{endpoint}"

        logging.debug(f"Making {method} request to {url} with {kwargs}")

        # if headers is not in kwargs and X-API-Key is not present, add the api key to headers in kwargs
        headers = kwargs.setdefault('headers', {})
        headers.setdefault('X-API-Key', self.api_key)

        # remove accept and content-type as there are endpoint variations, and they are
        # better handled by requests, e.g. analysis storage needs content type v4+json
        # headers.setdefault('accept', 'application/vnd.illumina.v3+json')
        # headers.setdefault('Content-Type', 'application/vnd.illumina.v3+json')

        if no_retry_status_code_list == None:
            no_retry_status_code_list = []

        response = requests.request(method, url, **kwargs)
        logging.debug(
            f"Received response: {response.status_code} - {response.text}")

        if response.status_code >= 400 and response.status_code not in no_retry_status_code_list:
            # raise exception that triggers retry
            logging.warning(
                f"API request failed: {response.status_code} - {response.text}")
            response.raise_for_status()

        # either success or I want to manage response with no retry
        # (e.g. resource not found or 429, or 500 text server error when pipeline exists)
        if response.status_code >= 400:
            logging.warning(
                f"Received response: {response.status_code} - {response.text}")

        try:
            return response.json()  # Assumes the response content is JSON
        except:
            return response.text

    def _request(self, method: str, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs):
        return self.retry_runner.run(
            self._request_base, method, endpoint, no_retry_status_code_list, **kwargs)

    def _get(self, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs):
        """Make a GET request."""
        return self._request('GET', endpoint, no_retry_status_code_list, **kwargs)

    def _post(self, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs):
        """Make a POST request."""
        return self._request('POST', endpoint, no_retry_status_code_list, **kwargs)

    def _put(self, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs):
        """Make a PUT request."""
        return self._request('PUT', endpoint, no_retry_status_code_list, **kwargs)

    def _delete(self, endpoint: str, no_retry_status_code_list: List[int] = None, **kwargs):
        """Make a DELETE request."""
        return self._request('DELETE', endpoint, no_retry_status_code_list, **kwargs)

    def _check_project_name(self, project_name):
        if project_name.startswith('ica://'):
            project_name = project_name[6:]
        if '/' in project_name:
            raise Exception(
                f'project name should not contain "/", found "{project_name}"')

        pattern = r'^[A-Za-z][A-Za-z0-9_\-\s]*$'
        if not re.match(pattern, project_name):
            raise Exception(
                f'Unvalid project name "{project_name}". The first character must be a letter'
                f'followed by letters, numbers, underscores, dashes or spaces.')

        return project_name

    def get_projects(self, include_hidden_projects=False):
        """
        NOTE: this call can be expensive, if you know the name, use get_project()
        This call does not use cache, update cache instead
        """

        logging.info(f'Getting ICA projects')
        include_hidden_projects = 'true' if include_hidden_projects else 'false'
        page_size = 1000
        page_token = None
        base_endpoint = f'/projects?includeHiddenProjects={include_hidden_projects}&pageSize={page_size}'
        project_details_list = []

        while True:
            if page_token:
                endpoint = base_endpoint + f'&pageToken={page_token}'
            else:
                endpoint = base_endpoint
            response = self._get(endpoint=base_endpoint)
            for x in response['items']:
                self._set_cache('project', x['name'], x)
                project_details_list.append(x)
            if 'remainingRecords' in response and response['remainingRecords'] == 0:
                break
            page_token = response['nextPageToken']
        return project_details_list

    def get_project(self, project_name: str):
        """
        This call tries to load cache
        If not found, return None
        """

        project_name = self._check_project_name(project_name=project_name)
        project_details = self._get_cache('project', project_name)
        if project_details != None:
            return project_details

        logging.info(f'Getting ICA project "{project_name}"')
        endpoint = f'/projects?search={project_name}&includeHiddenProjects=false'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            return None
        elif len(response['items']) == 1 and response['items'][0]['name'] == project_name:
            self._set_cache('project', project_name, response['items'][0])
            return response['items'][0]
        else:
            raise Exception(
                f'Found multiple projects with name "{project_name}", please use unique name.')

    def _create_project(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            storage_configuration_name: str = None, data_sharing_enabled: bool = False,
            billing_mode: str = 'PROJECT'):
        """
        This call does NOT load cache
        If project already exists, return None, up to the caller to handle the logic of
        looping between get and create, see get_or_create_project()
        """

        logging.info(f'Creating ICA project "{project_name}"')
        project_name = self._check_project_name(project_name=project_name)

        region_details = self.get_region(region_name)
        if region_details == None:
            raise Exception(f'Region "{region_name}" is not found')

        storage_bundle_details = self.get_storage_bundle(storage_bundle_name)
        if storage_bundle_details == None:
            raise Exception(
                f'Storage Bundle "{storage_bundle_name}" is not found')

        if storage_configuration_name:
            storage_configuration_details = self.get_storage_configuration(
                storage_configuration_name)
            if storage_configuration_details == None:
                raise Exception(
                    f'Storage Configuration "{storage_configuration_name}" is not found')

        endpoint = f'/projects'
        request_body = {
            'name': project_name,
            'regionId': region_details['id'],
            'storageBundleId': storage_bundle_details['id'],
            'billingMode': billing_mode,
            'dataSharingEnabled': data_sharing_enabled,
        }
        if storage_configuration_name:
            request_body['storageConfigurationId'] = storage_configuration_details['id']
            request_body['storageConfigurationSubfolder'] = project_name
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}

        response = self._post(
            endpoint=endpoint, no_retry_status_code_list=[400], data=request_body, headers=headers)

        # handle 400 error
        if 'status' in response and response['status'] == 400:
            if 'detail' in response and response['detail'] == 'A project with this name already exists in the same region.':
                # ICA inconsistent error to retry get call
                logging.warning(f'Project with name "{project_name}" already exists, '
                                f'either create one with different name or get the details of existing one')
                return None
            else:
                # user error to resolve to not retry
                raise Exception(
                    f'Failed to create project "{project_name}", response = {response}')

        self._set_cache('project', project_name, response)
        return response

    def get_or_create_project(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            storage_configuration_name: str = None,
            data_sharing_enabled: bool = False, billing_mode: str = 'PROJECT',
            max_retry: int = 8640, retry_sleep: int = 10):
        """
        only get_project tries to load the cache
        If not found will try to create/get until success
        """

        for retry_index in range(max_retry):
            project_details = self.get_project(project_name=project_name)
            if project_details != None:
                return project_details

            project_details = self._create_project(
                project_name=project_name, region_name=region_name,
                storage_bundle_name=storage_bundle_name,
                storage_configuration_name=storage_configuration_name,
                data_sharing_enabled=data_sharing_enabled, billing_mode=billing_mode)
            if project_details != None:
                return project_details

            logging.warning(
                f'Stuck in project create/get loop, ICA is inconsistent at this moment, '
                f'retrying in {retry_sleep} seconds ... (retry {retry_index} out of {max_retry})')
            time.sleep(retry_sleep)

        raise Exception(
            f'Failed to create or get project (after retrying for {retry_sleep*max_retry} seconds)')

    def _check_project_data_path_type(self, project_data_path, project_data_type):
        if project_data_type not in {'FILE', 'FOLDER'}:
            raise Exception(
                f'project data type must be either FILE/FOLDER, found "{project_data_type}"')
        if project_data_path[0] != '/':
            raise Exception(
                f'project data path must starts with "/" found "{project_data_path}"')
        if project_data_path == '/':
            raise Exception(
                f'Can not get project root folder (please send request to ICA team)')
        if '//' in project_data_path:
            raise Exception(
                f'project data path must not contain "//" found "{project_data_path}"')
        if project_data_type == 'FOLDER' and not project_data_path.endswith('/'):
            raise Exception(
                f'FOLDER type project data path must end with "/", found "{project_data_path}"')
        if project_data_type == 'FILE' and project_data_path.endswith('/'):
            raise Exception(
                f'FILE type project data path must not end with "/", found "{project_data_path}"')
        if project_data_type == 'FILE' and '/' not in project_data_path[1:]:
            raise Exception(
                f'Root level FILE type project data path is not supported due to inefficiency in '
                f'ICA design, found "{project_data_path}", please move files under folders and '
                f'try again.')

        return project_data_path, project_data_type

    def get_ica_root_folder(self, project_data_path):
        """
        possible project_data_path:
        - / => /
        - /abc (file) => /
        - /abc/ (folder) => /abc/
        - /abc/efg (file) => /abc/
        - /abc/efg/ (folder) => /abc/
        """
        if project_data_path[0] != '/':
            raise Exception(
                f'project data path must starts with "/" found "{project_data_path}"')
        if '//' in project_data_path:
            raise Exception(
                f'project data path must not contain "//" found "{project_data_path}"')

        if project_data_path == '/':
            return '/'

        if '/' not in project_data_path[1:]:
            # /abc case
            return '/'

        if project_data_path.endswith('/') and '/' not in project_data_path[1:-1]:
            # /abc/ case
            return project_data_path

        # /abc/efg or /abc/efg/ case
        return '/' + project_data_path[1:].split('/', 1)[0] + '/'

    def get_project_data(
            self, project_name: str, project_data_path: str, project_data_type: str):
        """
        This call tries to load cache
        If project is not found return None, use get_or_create_project_data() to create project

        folder must end with /, or will not be found
        """

        project_name = self._check_project_name(project_name=project_name)
        project_data_path, project_data_type = self._check_project_data_path_type(
            project_data_path=project_data_path, project_data_type=project_data_type)

        key = f'{project_name}:{project_data_path}:{project_data_type}'
        project_data_details = self._get_cache('project_data', key)
        if project_data_details != None:
            return project_data_details

        logging.info(f'Getting ICA project data, project: "{project_name}", '
                     f'data path: "{project_data_path}", type: "{project_data_type}"')

        project_details = self.get_project(project_name=project_name)
        if project_details == None:
            logging.warning(
                f'Can not get project data "{project_data_path}" (type: "{project_data_type}"), '
                f'because project "{project_name}" is not found')
            return None

        project_id = project_details['id']
        endpoint = f'/projects/{project_id}/data?filePath={project_data_path}'
        endpoint += f'&filePathMatchMode=FULL_CASE_INSENSITIVE'
        endpoint += f'&type={project_data_type}'

        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.warning(
                f'Project data "{project_data_path}" (type: "{project_data_type}") is not found '
                f'in project "{project_name}"')
            return None
        elif len(response['items']) == 1:
            self._set_cache('project_data', key, response['items'][0])
            return response['items'][0]
        else:
            raise Exception(
                f'Found multiple project data with name "{project_data_path}" or type "{project_data_type}", '
                f'in project "{project_name}", please use unique name.')

    def _create_project_data(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            project_data_path: str, project_data_type: str,
            storage_configuration_name: str = None, data_sharing_enabled: bool = False,
            billing_mode: str = 'PROJECT', max_retry: int = 8640, retry_sleep: int = 10):
        """
        This call does NOT load cache
        If project data already exists, return None, up to the caller to handle the logic of
        looping between get and create, see get_or_create_project_data()

        folder must end with /
        """

        # NOTE1: file and folder with the same name can exist, so type is required
        # NOTE2: folder exist if fine, file exists cause 409 conflict

        # /data/ <= root level folder
        # {
        #   "name": "data",
        #   "folderPath": "/",
        #   "dataType": "FOLDER"
        # }

        # /data/test1/test2/ <== subfolder under subfolder
        # {
        #   "name": "test2",
        #   "folderPath": "/data/test1/",
        #   "dataType": "FOLDER"
        # }

        # /data <== root level file, bad will forbidden create
        # {
        #   "name": "data",
        #   "folderPath": "/",
        #   "dataType": "FILE"
        # }

        # /data/data1 <== file under subfolder
        # {
        #   "name": "data1",
        #   "folderPath": "/data/",
        #   "dataType": "FILE"
        # }

        logging.info(f'Creating ICA project data, project: "{project_name}", '
                     f'data path: "{project_data_path}", type: "{project_data_type}"')

        project_name = self._check_project_name(project_name=project_name)
        project_data_path, project_data_type = self._check_project_data_path_type(
            project_data_path=project_data_path, project_data_type=project_data_type)
        key = f'{project_name}:{project_data_path}:{project_data_type}'

        project_details = self.get_or_create_project(
            project_name=project_name,
            region_name=region_name,
            storage_bundle_name=storage_bundle_name,
            storage_configuration_name=storage_configuration_name,
            data_sharing_enabled=data_sharing_enabled,
            billing_mode=billing_mode,
            max_retry=max_retry,
            retry_sleep=retry_sleep)

        if project_details == None:
            raise Exception(
                f'Can not get project data "{project_data_path}" (type: "{project_data_type}"), '
                f'because failed to create project "{project_name}"')

        project_id = project_details['id']

        # remove trailing / for folder, create folder does not need basename with trailing /
        if project_data_path.endswith('/'):
            project_data_path = project_data_path[:-1]

        # at this point, project_data_path are /a (root level), /a/b, /a/b/c, ...
        # /a => '', 'a'
        # /a/b => '/a', 'b'
        # /a/b/c => '/a/b', 'c'
        if '/' not in project_data_path[1:]:
            # root level (FOLDER only)
            base_name = project_data_path[1:]
            folder_path = '/'
        else:
            # with subfolder (FOLDER or FILE)
            folder_path, base_name = project_data_path.rsplit('/', 1)
            folder_path += '/'

        request_body = {
            "name": base_name,  # base name can not contain /
            "folderPath": folder_path,  # must ends with /, good to also start with /
            "dataType": project_data_type,
        }
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        endpoint = f'/projects/{project_id}/data'

        if project_data_type == 'FILE':
            response = self._post(
                endpoint=endpoint, no_retry_status_code_list=[409], data=request_body, headers=headers)

            # handle 409 error when create existing file
            if 'status' in response and response['status'] == 409:
                if 'detail' in response and response['detail'] == 'Unable to create file: Existing file at requested path':
                    # ICA inconsistent error to retry get call
                    logging.warning(
                        f'Project data with name "{project_data_path}" and type "{project_data_type}" '
                        f'already exists in project "{project_name}", '
                        f'either create one with different name, or get the details of existing one')
                    return None
                else:
                    # user error to resolve to not retry
                    raise Exception(
                        f'Failed to create project data with name "{project_data_path}" and '
                        f'type "{project_data_type}" "{project_name}", response = {response}')

            self._set_cache('project_data', key, response)
            return response

        else:
            # create existing folder is ok
            response = self._post(
                endpoint=endpoint, data=request_body, headers=headers)
            self._set_cache('project_data', key, response)
            return response

    def get_or_create_project_data(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            project_data_path: str, project_data_type: str,
            storage_configuration_name: str = None, data_sharing_enabled: bool = False,
            billing_mode: str = 'PROJECT', max_retry: int = 8640, retry_sleep: int = 10):
        """
        only get_project_data tries to load the cache
        If not found will try to create/get until success
        """

        for retry_index in range(max_retry):

            project_data_details = self.get_project_data(
                project_name=project_name,
                project_data_path=project_data_path,
                project_data_type=project_data_type)

            if project_data_details != None:
                return project_data_details

            project_data_details = self._create_project_data(
                project_name=project_name,
                region_name=region_name,
                storage_bundle_name=storage_bundle_name,
                project_data_path=project_data_path,
                project_data_type=project_data_type,
                storage_configuration_name=storage_configuration_name,
                data_sharing_enabled=data_sharing_enabled,
                billing_mode=billing_mode,
                max_retry=max_retry,
                retry_sleep=retry_sleep)

            if project_data_details != None:
                return project_data_details

            logging.warning(
                f'Stuck in project data create/get loop, ICA is inconsistent at this moment, '
                f'retrying in {retry_sleep} seconds ... (retry {retry_index} out of {max_retry})')
            time.sleep(retry_sleep)

        raise Exception(
            f'Failed to create or get project data (after retrying for {retry_sleep*max_retry} seconds)')

    def batch_presign_project_data(self, project_name: str, project_data_path_list: list,
                                   max_retry: int = 180, retry_sleep: int = 10):
        """
        This call tries to load the cache
        downside of this method, no size in byte, and ICA presign url does not allow get size from header

        As user may make error in input path, we reduce the max retry to be 30min
        """

        logging.info(f'Batch presigning "{len(project_data_path_list)}" ICA project data '
                     f'in project "{project_name}"')
        project_details = self.get_project(project_name)
        if project_details == None:
            raise Exception(
                f'Can not batch presign project data, project name "{project_name}" is not found')
        project_id = project_details['id']

        presign_url_dict = {x: None for x in project_data_path_list}
        for x in presign_url_dict:
            key = f'{project_name}:{x}'
            url = self._get_cache('project_data_presign_url', key)
            if url != None:
                presign_url_dict[x] = url

        remaining_list = [
            x for x in project_data_path_list if presign_url_dict[x] == None]

        for retry_index in range(max_retry):

            # break list into sublist of 1000
            max_size = 1000
            remaining_list_list = [
                remaining_list[i:i + max_size] for i in range(0, len(remaining_list), max_size)]

            for sublist in remaining_list_list:
                endpoint = f'/projects/{project_id}/data:createDownloadUrls'
                request_body = {"dataPaths": sublist}
                request_body = json.dumps(request_body)
                headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
                response = self._post(
                    endpoint=endpoint, data=request_body, headers=headers)
                for x in response['items']:
                    key = f'{project_name}:{x["dataPath"]}'
                    self._set_cache('project_data_presign_url', key, x)
                    presign_url_dict[x['dataPath']] = x

            remaining_list = [
                x for x in project_data_path_list if presign_url_dict[x] == None]
            if len(remaining_list) == 0:
                break

            logging.warning(
                f'Not all presign URLs are generated, {len(remaining_list)} remaining, '
                f'retrying in {retry_sleep} seconds ... (retry {retry_index} out of {max_retry}) '
                f'list: {json.dumps(remaining_list)}')

            # check if project data actually exits
            for x in remaining_list:
                project_data_details = self.get_project_data(
                    project_name=project_name,
                    project_data_path=x,
                    project_data_type='FILE')
                if project_data_details == None:
                    raise Exception(
                        f'FILE project data "{x}" is not found in project "{project_name}"')

            time.sleep(retry_sleep)

        if len(remaining_list):
            raise Exception(
                f'Failed to get all presign URLs, {len(remaining_list)} remaining '
                f'(after retrying for {retry_sleep*max_retry} seconds)')

        return presign_url_dict

    def get_temp_credentials(
            self, project_name: str, project_data_path: str, project_data_type: str,
            read_only: bool = False):
        """
        This call tries to load the cache
        """
        # {'rcloneTempCredentials': {'config': {'access_key_id': 'xxx',
        #                                           'no_check_bucket': 'true',
        #                                           'provider': 'AWS',
        #                                           'region': 'us-east-1',
        #                                           'secret_access_key': 'yyy',
        #                                           'server_side_encryption': 'AES256',
        #                                           'session_token': 'zzz',
        #                                           'type': 's3'},
        #                                'expirationTime': '2024-07-29T12:14:38Z',
        #                                'filePathPrefix': 'stratus-gds-use1/114496c9-4376-4057-5cfd-08dcaafab170/data/temp/IlluminaAnnotator-3.22.0-0-g45c9185f-net6.0.zip',
        #                                'storageType': 's3'}}
        key = f'{project_name}:{project_data_path}:{project_data_type}'
        temp_creds_details = self._get_cache('project_data_temp_creds', key)
        if temp_creds_details != None:
            return temp_creds_details

        logging.info(f'Getting ICA project data temp creds, project name: "{project_name}", '
                     f'project data path: "{project_data_path}", type: "{project_data_type}"')

        project_data_details = self.get_project_data(
            project_name=project_name,
            project_data_path=project_data_path,
            project_data_type=project_data_type)

        if project_data_details == None:
            raise Exception(f'Can not get project data "{project_data_path}" '
                            f'of type "{project_data_type}" in project "{project_name}"')

        project_id = project_data_details['projectId']
        project_data_id = project_data_details['data']['id']

        endpoint = f'/projects/{project_id}/data/{project_data_id}:createTemporaryCredentials'
        request_body = {"credentialsFormat": "RCLONE",
                        'readOnlyCredentials': read_only}
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        response = self._post(
            endpoint=endpoint, data=request_body, headers=headers)
        self._set_cache('project_data_temp_creds', key, response)
        return response

    def get_or_create_temp_credentials(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            project_data_path: str, project_data_type: str,
            storage_configuration_name: str = None, data_sharing_enabled: bool = False,
            billing_mode: str = 'PROJECT', max_retry: int = 8640, retry_sleep: int = 10,
            read_only: bool = False):
        """
        This call tries to load the cache
        """
        # {'rcloneTempCredentials': {'config': {'access_key_id': 'xxx',
        #                                           'no_check_bucket': 'true',
        #                                           'provider': 'AWS',
        #                                           'region': 'us-east-1',
        #                                           'secret_access_key': 'yyy',
        #                                           'server_side_encryption': 'AES256',
        #                                           'session_token': 'zzz',
        #                                           'type': 's3'},
        #                                'expirationTime': '2024-07-29T12:14:38Z',
        #                                'filePathPrefix': 'stratus-gds-use1/114496c9-4376-4057-5cfd-08dcaafab170/data/temp/IlluminaAnnotator-3.22.0-0-g45c9185f-net6.0.zip',
        #                                'storageType': 's3'}}
        key = f'{project_name}:{project_data_path}:{project_data_type}'
        temp_creds_details = self._get_cache('project_data_temp_creds', key)
        if temp_creds_details != None:
            return temp_creds_details

        logging.info(f'Getting ICA project data temp creds, project name: "{project_name}", '
                     f'project data path: "{project_data_path}", type: "{project_data_type}"')

        project_data_details = self.get_or_create_project_data(
            project_name=project_name,
            region_name=region_name,
            storage_bundle_name=storage_bundle_name,
            project_data_path=project_data_path,
            project_data_type=project_data_type,
            storage_configuration_name=storage_configuration_name,
            data_sharing_enabled=data_sharing_enabled,
            billing_mode=billing_mode,
            max_retry=max_retry,
            retry_sleep=retry_sleep)
        project_id = project_data_details['projectId']
        project_data_id = project_data_details['data']['id']

        endpoint = f'/projects/{project_id}/data/{project_data_id}:createTemporaryCredentials'
        request_body = {"credentialsFormat": "RCLONE",
                        'readOnlyCredentials': read_only}
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        response = self._post(
            endpoint=endpoint, data=request_body, headers=headers)
        self._set_cache('project_data_temp_creds', key, response)
        return response

    def get_upload_sessions(
            self, project_name: str, project_data_path: str):
        """
        This call tries to load the cache
        """

        # {'id': 'ssn.530e4bbc4bb74570889aa77d95c84165',
        # 'status': 'OPEN',
        # 'tempCredentials': {'rcloneTempCredentials': {'config': {'access_key_id': 'xxx',
        #                                                         'no_check_bucket': 'true',
        #                                                         'provider': 'AWS',
        #                                                         'region': 'us-east-1',
        #                                                         'secret_access_key': 'yyy',
        #                                                         'server_side_encryption': 'AES256',
        #                                                         'session_token': 'zzz',
        #                                                         'type': 's3'},
        #                                             'expirationTime': '2024-07-29T12:24:07Z',
        #                                             'filePathPrefix': 'stratus-gds-use1/114496c9-4376-4057-5cfd-08dcaafab170/data/',
        #                                             'storageType': 's3',
        #                                             'uploadSessionId': 'ssn.530e4bbc4bb74570889aa77d95c84165'}},
        # 'timeCreated': '2024-07-28T00:24:07Z',
        # 'timeSessionExpires': '2024-07-29T12:24:07Z'}

        project_data_type = 'FOLDER'
        key = f'{project_name}:{project_data_path}:{project_data_type}'
        upload_session_details = self._get_cache(
            'project_data_upload_session', key)
        if upload_session_details != None:
            return upload_session_details

        logging.info(f'Getting ICA project data upload session, project name: "{project_name}", '
                     f'project data path: "{project_data_path}", type: "{project_data_type}"')

        project_data_details = self.get_or_create_project_data(
            project_name=project_name,
            project_data_path=project_data_path,
            project_data_type=project_data_type)

        if project_data_details == None:
            raise Exception(f'Can not get project data "{project_data_path}" '
                            f'of type "{project_data_type}" in project "{project_name}"')

        project_id = project_data_details['projectId']
        project_data_id = project_data_details['data']['id']

        endpoint = f'/projects/{project_id}/data/{project_data_id}/folderUploadSessions'
        request_body = {"credentialsFormat": "RCLONE"}
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        response = self._post(
            endpoint=endpoint, data=request_body, headers=headers)
        self._set_cache('project_data_upload_session', key, response)
        return response

    def get_or_create_upload_sessions(
            self, project_name: str, region_name: str, storage_bundle_name: str,
            project_data_path: str,
            storage_configuration_name: str = None, data_sharing_enabled: bool = False,
            billing_mode: str = 'PROJECT', max_retry: int = 8640, retry_sleep: int = 10):
        """
        This call tries to load the cache
        """

        # {'id': 'ssn.530e4bbc4bb74570889aa77d95c84165',
        # 'status': 'OPEN',
        # 'tempCredentials': {'rcloneTempCredentials': {'config': {'access_key_id': 'xxx',
        #                                                         'no_check_bucket': 'true',
        #                                                         'provider': 'AWS',
        #                                                         'region': 'us-east-1',
        #                                                         'secret_access_key': 'yyy',
        #                                                         'server_side_encryption': 'AES256',
        #                                                         'session_token': 'zzz',
        #                                                         'type': 's3'},
        #                                             'expirationTime': '2024-07-29T12:24:07Z',
        #                                             'filePathPrefix': 'stratus-gds-use1/114496c9-4376-4057-5cfd-08dcaafab170/data/',
        #                                             'storageType': 's3',
        #                                             'uploadSessionId': 'ssn.530e4bbc4bb74570889aa77d95c84165'}},
        # 'timeCreated': '2024-07-28T00:24:07Z',
        # 'timeSessionExpires': '2024-07-29T12:24:07Z'}

        project_data_type = 'FOLDER'
        key = f'{project_name}:{project_data_path}:{project_data_type}'
        upload_session_details = self._get_cache(
            'project_data_upload_session', key)
        if upload_session_details != None:
            return upload_session_details

        logging.info(f'Getting ICA project data upload session, project name: "{project_name}", '
                     f'project data path: "{project_data_path}", type: "{project_data_type}"')
        project_data_details = self.get_or_create_project_data(
            project_name=project_name,
            region_name=region_name,
            storage_bundle_name=storage_bundle_name,
            project_data_path=project_data_path,
            project_data_type=project_data_type,
            storage_configuration_name=storage_configuration_name,
            data_sharing_enabled=data_sharing_enabled,
            billing_mode=billing_mode,
            max_retry=max_retry,
            retry_sleep=retry_sleep)
        project_id = project_data_details['projectId']
        project_data_id = project_data_details['data']['id']

        endpoint = f'/projects/{project_id}/data/{project_data_id}/folderUploadSessions'
        request_body = {"credentialsFormat": "RCLONE"}
        request_body = json.dumps(request_body)
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        response = self._post(
            endpoint=endpoint, data=request_body, headers=headers)
        self._set_cache('project_data_upload_session', key, response)
        return response

    def _complete_folder_upload_sessions(
            self, project_name: str, project_data_path: str, folder_upload_session_id: str, num_files: int):
        """Not really useful as when error happens there is nothing user can do."""
        return

        # {'id': 'ssn.e0c9e19d20f04f38b007181c346f38aa',
        # 'status': 'CLOSED',
        # 'timeClosed': '2024-07-28T00:30:16Z',
        # 'timeCreated': '2024-07-28T00:25:25Z',
        # 'timeSessionExpires': '2024-07-29T12:25:25Z'}

        # project_details = self.get_project(project_name=project_name)

        # endpoint = f'/projects/{project_id}/data/{project_data_id}/folderUploadSessions/{folder_upload_session_id}:complete'
        # request_body = {"numberOfExpectedUploadedFiles": num_files}
        # request_body = json.dumps(request_body)
        # response = self._post(endpoint=endpoint, data=request_body)
        # return response

    def get_regions(self):

        logging.info(f'Getting ICA regions')
        endpoint = f'/regions'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.warning(f'No Regions found in your ICA subscription.')
        for x in response['items']:
            self._set_cache('region', x['code'], x)
        return response['items']

    def get_region(self, region_name):

        region_details = self._get_cache('region', region_name)
        if region_details != None:
            return region_details

        logging.info(f'Getting ICA region "{region_name}"')
        self.get_regions()
        region_details = self._get_cache('region', region_name)
        if region_details != None:
            return region_details
        error_msg = f'Region "{region_name}" is not found in your ICA subscription.'
        logging.warning(error_msg)
        raise Exception(error_msg)

    def get_storage_bundles(self):

        logging.info(f'Getting ICA storage bundles')
        endpoint = f'/storageBundles'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.warning(
                f'No Storage Bundles found in your ICA subscription.')
        for x in response['items']:
            self._set_cache('storage_bundle', x['bundleName'], x)
        return response['items']

    def get_storage_bundle(self, storage_bundle_name):

        storage_bundle_details = self._get_cache(
            'storage_bundle', storage_bundle_name)
        if storage_bundle_details != None:
            return storage_bundle_details

        logging.info(f'Getting ICA storage bundle "{storage_bundle_name}"')
        self.get_storage_bundles()
        storage_bundle_details = self._get_cache(
            'storage_bundle', storage_bundle_name)
        if storage_bundle_details != None:
            return storage_bundle_details
        error_msg = f'Storage Bundle "{storage_bundle_name}" is not found in your ICA subscription.'
        logging.warning(error_msg)
        raise Exception(error_msg)

    def get_storage_configurations(self):

        logging.info(f'Getting ICA storage configurations')
        endpoint = f'/storageConfigurations'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.warning(
                f'No Storage configurations found in your ICA subscription.')
        for x in response['items']:
            self._set_cache('storage_configuration', x['name'], x)
        return response['items']

    def get_storage_configuration(self, storage_configuration_name):
        """
        NOTE: for security reasons, we do not support creation of storage configuration
              from CLI, do it in WebUI
        """

        storage_configuration_details = self._get_cache(
            'storage_configuration', storage_configuration_name)
        if storage_configuration_details != None:
            return storage_configuration_details

        logging.info(
            f'Getting ICA storage configuration "{storage_configuration_name}"')
        self.get_storage_configurations()
        storage_configuration_details = self._get_cache(
            'storage_configuration', storage_configuration_name)
        if storage_configuration_details != None:
            return storage_configuration_details
        error_msg = f'Storage configuration "{storage_configuration_name}" is not found in your ICA subscription.'
        logging.warning(error_msg)
        raise Exception(error_msg)

    def get_analysis_storages(self, project_name: str):
        """
        This call tries to load the cache only to get project details
        If project is not found return None, use get_or_create_project_data() to create project
        """

        project_name = self._check_project_name(project_name=project_name)
        project_details = self.get_project(project_name=project_name)
        if project_details == None:
            logging.warning(
                f'Can not get project analysis storages, '
                f'because project "{project_name}" is not found. '
                f'Please create the project first, or use an existing project.')
            return None

        logging.info(f'Getting ICA analysis storages')

        project_id = project_details['id']
        endpoint = f'/projects/{project_id}/analysisStorages'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.warning(f'No analysis storage in project "{project_name}" is found '
                            f'in your ICA subscription.')
            return None

        for x in response['items']:
            key = f'{project_name}:{x["name"]}'
            self._set_cache('project_analysis_storage', key, x)

        return response['items']

    def get_analysis_storage(self, project_name: str, analysis_storage_name: str):
        """
        This call tries to load the cache
        if not found throw exception, need to check with ICA team
        """

        project_name = self._check_project_name(project_name=project_name)
        key = f'{project_name}:{analysis_storage_name}'
        analysis_storage_details = self._get_cache(
            'project_analysis_storage', key)
        if analysis_storage_details != None:
            return analysis_storage_details

        logging.info(f'Getting ICA analysis storage "{analysis_storage_name}"')
        self.get_analysis_storages(project_name)

        analysis_storage_details = self._get_cache(
            'project_analysis_storage', key)
        if analysis_storage_details != None:
            return analysis_storage_details

        error_msg = (
            f'Analysis storage "{analysis_storage_name}" is not found '
            f'in project "{project_name}", please make sure the analysis storage name is correct.')

        logging.warning(error_msg)
        raise Exception(error_msg)

    def get_pipelines(self, project_name: str):
        """
        This call tries to load the cache only to get project details
        If project is not found return None, use get_or_create_project_data() to create project
        """

        project_name = self._check_project_name(project_name=project_name)
        project_details = self.get_project(project_name=project_name)
        if project_details == None:
            # no need to retry if project is not found
            raise Exception(
                f'Can not get project pipline, '
                f'because project "{project_name}" is not found. '
                f'Please create the project first, or use an existing project.')

        logging.info(f'Getting ICA pipelines')

        project_id = project_details['id']
        endpoint = f'/projects/{project_id}/pipelines'
        response = self._get(endpoint=endpoint)
        if len(response['items']) == 0:
            logging.info(
                f'No pipeline is found in project "{project_name}"')
            return None

        for x in response['items']:
            key = f'{project_name}:{x["pipeline"]["code"]}'
            self._set_cache('project_pipeline', key, x)

        return response['items']

    def get_pipeline(self, project_name: str, pipeline_name: str):
        """
        This call tries to load the cache
        if pipeline is not found return None, suggest to create one
        """

        project_name = self._check_project_name(project_name=project_name)
        key = f'{project_name}:{pipeline_name}'
        pipeline_details = self._get_cache('project_pipeline', key)
        if pipeline_details != None:
            return pipeline_details

        logging.info(f'Getting ICA pipeline "{pipeline_name}"')
        self.get_pipelines(project_name)

        pipeline_details = self._get_cache('project_pipeline', key)
        if pipeline_details != None:
            return pipeline_details

        error_msg = f'Pipeline "{pipeline_name}" is not found in project "{project_name}"'
        logging.info(error_msg)
        return None

    def _create_cwl_pipeline(
            self, project_name: str, pipeline_name: str, analysis_storage_name: str,
            cwl_workflow_path: str, config_xml_path: str, cwl_tool_path_list: List[tuple]):
        """
        This call tries to load the cache only to get project details
        If project is not found return None, use get_or_create_project_data() to create project
        """

        project_name = self._check_project_name(project_name=project_name)
        project_details = self.get_project(project_name=project_name)
        if project_details == None:
            raise Exception(
                f'Can not create project pipline, '
                f'because project "{project_name}" is not found. '
                f'Please create the project first, or use an existing project.')

        analysis_storage_details = self.get_analysis_storage(
            project_name=project_name, analysis_storage_name=analysis_storage_name)

        logging.info(
            f'Creating ICA pipeline "{pipeline_name}" in project "{project_name}"')

        files = [
            ('description', (None, pipeline_name)),
            ('analysisStorageId', (None, analysis_storage_details['id'])),
            ('code', (None, pipeline_name)),
            ('parametersXmlFile', ('params.xml', open(
                config_xml_path, 'rb'), 'application/xml')),
            ('workflowCwlFile', ('workflow.cwl', open(
                cwl_workflow_path, 'rb'), 'application/xml')),
        ]
        for cwl_tool_path, cwl_tool_mapping in cwl_tool_path_list:
            # example:
            # - cwl_tool_path = cwl/cwl_tools/md5sum-checker.cwl
            # - cwl_tool_mapping = cwl_tools/md5sum-checker.cwl
            files.append(
                ('toolCwlFiles',
                 (cwl_tool_mapping, open(cwl_tool_path, 'rb'), 'application/xml'))
            )

        project_id = project_details['id']
        endpoint = f'/projects/{project_id}/pipelines:createCwlPipeline'
        response = self._post(
            endpoint=endpoint, files=files, no_retry_status_code_list=[500])
        # handle ICA bug, when pipeline exists, the respond code is 500 Internal Server Error and response
        # is plain html not json (as of 20240829)
        # <html><head><title>Error</title></head><body>Internal Server Error</body></html>
        if isinstance(response, str) and 'Internal Server Error' in response:
            # the pipeline with pipeline name already exists, call get_pipeline()
            return None

        key = f'{project_name}:{response["pipeline"]["code"]}'
        self._set_cache('project_pipeline', key, response)
        return response

    def get_or_create_cwl_pipeline(
            self, project_name: str, pipeline_name: str, analysis_storage_name: str,
            cwl_workflow_path: str, config_xml_path: str, cwl_tool_path_list: List[tuple],
            max_retry: int = 8640, retry_sleep: int = 10):
        """
        only get_pipeline tries to load the cache
        If not found will try to create/get until success
        """

        for retry_index in range(max_retry):
            pipeline_details = self.get_pipeline(
                project_name=project_name, pipeline_name=pipeline_name)
            if pipeline_details != None:
                return pipeline_details

            pipeline_details = self._create_cwl_pipeline(
                project_name=project_name, pipeline_name=pipeline_name,
                analysis_storage_name=analysis_storage_name,
                cwl_workflow_path=cwl_workflow_path,
                config_xml_path=config_xml_path,
                cwl_tool_path_list=cwl_tool_path_list)
            if pipeline_details != None:
                return pipeline_details

            logging.warning(
                f'Stuck in pipeline create/get loop, ICA is inconsistent at this moment, '
                f'retrying in {retry_sleep} seconds ... (retry {retry_index} out of {max_retry})')
            time.sleep(retry_sleep)

        raise Exception(
            f'Failed to create or get cwl pipeline (after retrying for {retry_sleep*max_retry} seconds)')

    def get_cwl_activation_codes(self, project_name: str, pipeline_name: str):

        project_name = self._check_project_name(project_name=project_name)
        pipeline_details = self.get_pipeline(
            project_name=project_name, pipeline_name=pipeline_name)

        if pipeline_details == None:
            raise Exception(
                f'Pipeline "{pipeline_name}" is not found in project "{project_name}"')

        project_id = pipeline_details['projectId']
        pipeline_id = pipeline_details['pipeline']['id']
        analysis_storage_id = pipeline_details['pipeline']['analysisStorage']['id']

        endpoint = f'/activationCodes:findAllMatchingForCwl'
        headers = {'Content-Type': 'application/vnd.illumina.v3+json'}
        request_body = {
            'projectId': project_id,
            'pipelineId': pipeline_id,
            'analysisInput': {
                # use JSON type for file based input (such as secret file)
                "objectType": "JSON",
                "inputJson": ""
            }
        }
        request_body = json.dumps(request_body)
        response = self._post(
            endpoint=endpoint, data=request_body, headers=headers)

        # filter by pipeline analysis storage id
        out = []
        for activation_code in response['items']:
            analysis_storage_id_set = {
                x['id'] for x in activation_code['pipelineBundle']['analysisStorages']}
            if analysis_storage_id in analysis_storage_id_set:
                out.append(activation_code)
                key = f'{project_name}:{pipeline_name}:{activation_code["pipelineBundle"]["name"]}'
                self._set_cache('activation_code', key, activation_code)

        return out

    def get_cwl_activation_code(self, project_name: str, pipeline_name: str, activation_code_name: str):
        """
        This call tries to load the cache
        if activation code is not found throw exception, need to check with ICA
        """

        project_name = self._check_project_name(project_name=project_name)
        key = f'{project_name}:{pipeline_name}:{activation_code_name}'
        activation_code_details = self._get_cache('activation_code', key)
        if activation_code_details != None:
            return activation_code_details

        self.get_cwl_activation_codes(
            project_name=project_name, pipeline_name=pipeline_name)
        activation_code_details = self._get_cache('activation_code', key)
        if activation_code_details != None:
            return activation_code_details

        error_msg = (
            f'Activation code "{activation_code_name}" for pipeline "{pipeline_name}" '
            f'is not found in project "{project_name}".')
        logging.warning(error_msg)
        raise Exception(error_msg)

    def submit_cwl_analysis(
            self, project_name: str, project_jobs_folder_path: str,
            pipeline_name: str, analysis_name: str,
            activation_code_name: str, analysis_storage_name: str,
            input_json: dict, mount_list: list,
            max_retry: int = 1000000, retry_sleep: int = 10):

        project_name = self._check_project_name(project_name)
        project_jobs_folder_path, data_type = self._check_project_data_path_type(
            project_jobs_folder_path, 'FOLDER')

        project_details = self.get_project(project_name=project_name)
        if project_details == None:
            raise Exception(
                f'job project "{project_name}" is not found, '
                f'please create the project first.')

        project_jobs_folder_details = self.get_project_data(
            project_name=project_name,
            project_data_path=project_jobs_folder_path,
            project_data_type=data_type)
        if project_jobs_folder_details == None:
            raise Exception(
                f'job project folder "{project_jobs_folder_path}" is not found, '
                f'please create the project folder first.')

        pipeline_details = self.get_pipeline(
            project_name=project_name,
            pipeline_name=pipeline_name)
        if pipeline_details == None:
            raise Exception(
                f'pipeline "{pipeline_name}" is not found, '
                f'please create the pipeline first.')

        activation_code_details = self.get_cwl_activation_code(
            project_name=project_name,
            pipeline_name=pipeline_name,
            activation_code_name=activation_code_name)

        analysis_storage_details = self.get_analysis_storage(
            project_name=project_name,
            analysis_storage_name=analysis_storage_name)

        headers = {'Content-Type': 'application/vnd.illumina.v4+json'}

        request_body = {
            "userReference": analysis_name,
            "pipelineId": pipeline_details["pipeline"]["id"],
            "tags": {
                "technicalTags": [],
                "userTags": [],
                "referenceTags": []
            },
            "activationCodeDetailId": activation_code_details["id"],
            "analysisStorageId": analysis_storage_details["id"],
            "outputParentFolderId": project_jobs_folder_details["data"]["id"],
            "analysisInput": {
                "objectType": "JSON",
                "inputJson": json.dumps(input_json),
                "dataIds": [x['dataId'] for x in mount_list],
                "mounts": mount_list
            }
        }
        request_body = json.dumps(request_body)
        endpoint = f'/projects/{project_details["id"]}/analysis:cwl'

        # ICA is brittle on this API, all kinds of xxxz can happen, retry in do or die mode
        for retry_index in range(max_retry):
            try:
                response = self._post(
                    endpoint=endpoint, headers=headers, data=request_body)
                return response
            except Exception as e:
                logging.warning(traceback.format_exc())
                logging.warning(
                    f'*WARNING* submission failed, reason = "{e}". '
                    f'remaining retries = {max_retry-retry_index-1}, '
                    f'now sleep {retry_sleep} seconds ...')
                time.sleep(retry_sleep)
        err_message = (f'*ERROR* failed to submit analysis "{analysis_name}".')
        logging.error(err_message)
        raise Exception(err_message)


# ======= low level AWS utils =======


class AWSClient:
    def __init__(
            self, aws_access_key_id: str, aws_secret_access_key: str, aws_session_token: str,
            region_name: str, retry_runner: Optional[RetryRunner] = None):
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.aws_session_token = aws_session_token
        self.region_name = region_name
        self.session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
            region_name=region_name)
        self.client = self.session.client('s3')
        self.retry_runner = retry_runner or RetryRunner()

    def _get_file(self, bucket_name: str, object_key: str):
        try:
            response = self.client.head_object(
                Bucket=bucket_name, Key=object_key)
            # size in byte is available in response['ContentLength']
            return response
        except Exception as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                logging.warning(
                    f's3 file does not exist, "s3://{bucket_name}/{object_key}"')
                return None
            else:
                # all other errors will trigger retry
                raise e

    def get_file(self, bucket_name: str, object_key: str):
        return self.retry_runner.run(self._get_file, bucket_name, object_key)

    def presign_file(self, bucket_name: str, object_key: str, expiration: int = 604800):
        file_details = self.get_file(
            bucket_name=bucket_name, object_key=object_key)
        if file_details == None:
            # do not retry if file does not exist
            raise Exception(
                f'Cannot presign file, s3 file does not exist "s3://{bucket_name}/{object_key}"')
        params = {'Bucket': bucket_name, 'Key': object_key}
        url = self.retry_runner.run(
            self.client.generate_presigned_url,
            ClientMethod='get_object',
            Params=params,
            ExpiresIn=expiration)
        size = file_details['ContentLength']
        return size, url

    def download_file(
            self, bucket_name: str, object_key: str, local_path: str,
            retry_sleep: int = 3, max_retry: int = 1000000):

        file_details = self.get_file(
            bucket_name=bucket_name, object_key=object_key)
        if file_details == None:
            # do not retry if file does not exist
            raise Exception(
                f'Failed to download file, s3 file does not exist "s3://{bucket_name}/{object_key}"')

        remote_file_size = file_details['ContentLength']
        prep_output_file(local_path)

        for retry_index in range(max_retry):
            logging.info(
                f'Downloading "s3://{bucket_name}/{object_key}" to "{local_path}"')
            self.retry_runner.run(
                self.client.download_file, Bucket=bucket_name, Key=object_key, Filename=local_path)
            local_file_size = os.path.getsize(local_path)
            if local_file_size == remote_file_size:
                logging.info(
                    f's3 file "s3://{bucket_name}/{object_key}" is successfully downloaded and file size match ({local_file_size})')
                return
            logging.warning(
                f'Error in downloading file "s3://{bucket_name}/{object_key}" '
                f'local/remote file size mismatch (local={local_file_size}, remote={remote_file_size}), '
                f'retry download in {retry_sleep} seconds ... '
                f'(attempt {retry_index} out of {max_retry})')
            time.sleep(retry_sleep)

        raise Exception(
            f'Failed to download file "s3://{bucket_name}/{object_key}", retry exhausted.')

    def upload_file(
            self, local_path: str, bucket_name: str, object_key: str,
            retry_sleep: int = 3, max_retry: int = 1000000):
        if not os.path.isfile(local_path):
            raise Exception(
                f'Cannot upload file, local path is not a file "{local_path}"')
        local_file_size = os.path.getsize(local_path)

        for retry_index in range(max_retry):
            logging.info(
                f'Uploading "{local_path}" to "s3://{bucket_name}/{object_key}"')
            self.retry_runner.run(
                self.client.upload_file, Filename=local_path, Bucket=bucket_name, Key=object_key)

            file_details = self.get_file(
                bucket_name=bucket_name, object_key=object_key)
            if file_details == None:
                logging.warning(
                    f'Error in uploading file "s3://{bucket_name}/{object_key}" '
                    f'remote file does not exist, '
                    f'retry download in {retry_sleep} seconds ... '
                    f'(attempt {retry_index} out of {max_retry})')
                time.sleep(retry_sleep)
                continue

            remote_file_size = file_details['ContentLength']
            if local_file_size == remote_file_size:
                logging.info(
                    f's3 file "s3://{bucket_name}/{object_key}" is successfully uploaded '
                    f'and file size match ({local_file_size})')
                return

            logging.warning(
                f'Error in uploading file "s3://{bucket_name}/{object_key}" '
                f'local/remote file size mismatch (local={local_file_size}, remote={remote_file_size}), '
                f'retry upload in {retry_sleep} seconds ... '
                f'(attempt {retry_index} out of {max_retry})')
            time.sleep(retry_sleep)

        raise Exception(
            f'Failed to upload file "s3://{bucket_name}/{object_key}", retry exhausted.')


# ======= high level ICA Uploader =======

class ICAUploader:
    def __init__(self, ica_client: ICAClient, retry_runner: Optional[RetryRunner] = None) -> None:
        self.ica_client = ica_client
        self.retry_runner = retry_runner

    def upload(self, local_dir, ica_url,
               region_name, storage_bundle_name, storage_configuration_name, max_workers=0):
        """
        steps to recursively upload a folder to ICA
        - get project id and project data id
        - get output dir upload session
        - currently upload using aws s3 and check size
        """

        scheme, project_name, project_data_path = parse_url(ica_url)
        if scheme != 'ica':
            raise Exception(f'Invalid URL "{ica_url}", scheme is not "ica"')
        if project_data_path == '' or project_data_path == '/':
            raise Exception(
                f'Uploading folder content to root folder is not supported, found "{ica_url}"')

        upload_session_details = self.ica_client.get_or_create_upload_sessions(
            project_name=project_name,
            region_name=region_name,
            storage_bundle_name=storage_bundle_name,
            project_data_path=project_data_path,
            storage_configuration_name=storage_configuration_name)

        _config = upload_session_details['tempCredentials']['rcloneTempCredentials']['config']
        aws_client = AWSClient(
            aws_access_key_id=_config['access_key_id'],
            aws_secret_access_key=_config['secret_access_key'],
            aws_session_token=_config['session_token'],
            region_name=_config['region'],
            retry_runner=self.retry_runner)

        file_path_prefix = upload_session_details['tempCredentials']['rcloneTempCredentials']['filePathPrefix']
        bucket_name, folder_prefix = file_path_prefix.split('/', 1)

        local_dir, file_size_dict = get_all_local_files(local_folder=local_dir)

        # turn off concurrency runner level retry as aws_client.upload_file() contains retry logic
        concurr_runner = ConcurrencyRunner(
            retry_runner=RetryRunner(max_retries=0), max_workers=max_workers)
        upload_jobs = []
        for file_relpath, file_size in file_size_dict.items():
            _local_path = os.path.join(local_dir, file_relpath)
            _object_key = folder_prefix + file_relpath
            upload_jobs.append({
                'local_path': _local_path,
                'bucket_name': bucket_name,
                'object_key': _object_key,
            })

        logging.info(
            f'Uploading {len(upload_jobs)} files under "{local_dir}" to "{ica_url}"')
        concurr_runner.run(funcs=aws_client.upload_file,
                           kwargs_list=upload_jobs)
        concurr_runner.shutdown()
        logging.info(
            f'Successfully uploaded {len(upload_jobs)} files under "{local_dir}" to "{ica_url}"')

# ======= high level ICA Downloader =======


class ICADownloader:
    def __init__(self, ica_client: ICAClient, retry_runner: Optional[RetryRunner] = None) -> None:
        self.ica_client = ica_client
        self.retry_runner = retry_runner

    def _parse_ica_url(self, ica_url):
        if ica_url.endswith('/'):
            raise Exception(f'Can not download/presign ICA folder, found "{ica_url}"'
                            f'provide files instead.')
        scheme, project_name, project_data_path = parse_url(ica_url)
        if scheme != 'ica':
            raise Exception(
                f'Can not download/presign non-ICA files "{ica_url}"')
        if project_data_path == '' or project_data_path == '/':
            raise Exception(
                f'project data path is missing in ICA URL "{ica_url}"')

        root_folder = self.ica_client.get_ica_root_folder(
            project_data_path=project_data_path)
        if root_folder == '/':
            raise Exception(f'Can not download/presign ICA files under root level, '
                            f'found {ica_url}, please move data under folders.')
        file_relpath = project_data_path[len(root_folder):]

        return project_name, project_data_path, root_folder, file_relpath

    def download(self, ica_url_list, local_path_list, max_workers=0):
        """
        linking is not supported as the folder name may be the same from different s3 bucket

        steps to download ICA files
        - get root folder temp creds, create aws client
        - currently download using aws s3 and check size
        """

        if len(ica_url_list) != len(local_path_list):
            raise Exception(
                f'Can not download files, file size do not match: '
                f'{len(ica_url_list)} source files vs {len(local_path_list)} target files')

        # prepare local files
        for f in local_path_list:
            prep_output_file(f)

        # get all the root level folders
        # ica_url => root folder => aws_client => download
        download_callers = []
        download_jobs = []
        root_folder_cache = dict()
        for ica_url, local_path in zip(ica_url_list, local_path_list):

            # handle https based input
            if ica_url.startswith('https://'):
                download_callers.append(download_using_aria2c)
                download_jobs.append({
                    'remote_file_url': ica_url,
                    'local_file_path': local_path,
                })
                continue

            project_name, project_data_path, root_folder, file_relpath = self._parse_ica_url(
                ica_url=ica_url)

            key = f'{project_name}:{root_folder}'
            if key in root_folder_cache:
                aws_client, bucket_name, folder_prefix = root_folder_cache[key]

            else:
                # get_temp_credentials() also cache the existing temp creds to save API calls
                temp_creds_details = self.ica_client.get_temp_credentials(
                    project_name=project_name,
                    project_data_path=root_folder,
                    project_data_type='FOLDER',
                    read_only=True)
                if temp_creds_details == None:
                    raise Exception(f'Can not get temp credentials of folder "{project_data_path}"'
                                    f'in project "{project_name}", check if it exists.')
                _config = temp_creds_details['rcloneTempCredentials']['config']
                file_path_prefix = temp_creds_details['rcloneTempCredentials']['filePathPrefix']

                if file_path_prefix.startswith('arn:aws:s3:'):
                    # seq store bucket
                    # arn:aws:s3:eu-west-2:000000:accesspoint/11111-22222/33333/sequenceStore/44444/readSet/
                    # bucket name is arn:aws:s3:eu-west-2:000000:accesspoint/11111-22222
                    # folder prefix is 33333/sequenceStore/44444/readSet/
                    seq_store_access_point, seq_store_id, folder_prefix = file_path_prefix.split('/', 2)
                    bucket_name = seq_store_access_point + '/' + seq_store_id
                    folder_prefix = folder_prefix
                else:
                    # s3 based bucket
                    bucket_name, folder_prefix = file_path_prefix.split('/', 1)

                aws_client = AWSClient(
                    aws_access_key_id=_config['access_key_id'],
                    aws_secret_access_key=_config['secret_access_key'],
                    aws_session_token=_config['session_token'],
                    region_name=_config['region'],
                    retry_runner=self.retry_runner)
                root_folder_cache[key] = aws_client, bucket_name, folder_prefix

            _object_key = folder_prefix + file_relpath
            download_callers.append(aws_client.download_file)
            download_jobs.append({
                'bucket_name': bucket_name,
                'object_key': _object_key,
                'local_path': local_path,
            })

        # turn off concurrency runner level retry as aws_client.upload_file() contains retry logic
        concurr_runner = ConcurrencyRunner(
            retry_runner=RetryRunner(max_retries=0), max_workers=max_workers)

        logging.info(
            f'Downloading {len(download_jobs)} ICA/HTTPS files to local paths')

        concurr_runner.run(download_callers, kwargs_list=download_jobs)
        concurr_runner.shutdown()
        logging.info(
            f'Successfully Downloaded {len(download_jobs)} ICA/HTTPS files to local paths')

    def presign(self, ica_url_list, max_workers=0):
        """
        linking is not supported as the folder name may be the same from different s3 bucket

        steps to presign ICA files
        - get root folder temp creds, create aws client
        - currently presign using aws s3 and check size
        """

        # get all the root level folders
        # ica_url => root folder => aws_client => download
        presign_callers = []
        presign_jobs = []
        root_folder_cache = dict()
        # presign jobs following input order
        for ica_url in ica_url_list:

            project_name, project_data_path, root_folder, file_relpath = self._parse_ica_url(
                ica_url=ica_url)

            key = f'{project_name}:{root_folder}'
            if key in root_folder_cache:
                aws_client, bucket_name, folder_prefix = root_folder_cache[key]

            else:
                # get_temp_credentials() also cache the existing temp creds to save API calls
                temp_creds_details = self.ica_client.get_temp_credentials(
                    project_name=project_name,
                    project_data_path=root_folder,
                    project_data_type='FOLDER',
                    read_only=True)
                if temp_creds_details == None:
                    raise Exception(f'Can not get temp credentials of folder "{project_data_path}"'
                                    f'in project "{project_name}", check if it exists.')
                _config = temp_creds_details['rcloneTempCredentials']['config']
                file_path_prefix = temp_creds_details['rcloneTempCredentials']['filePathPrefix']

                if file_path_prefix.startswith('arn:aws:s3:'):
                    # seq store bucket
                    # arn:aws:s3:eu-west-2:000000:accesspoint/11111-22222/33333/sequenceStore/44444/readSet/
                    # bucket name is arn:aws:s3:eu-west-2:000000:accesspoint/11111-22222
                    # folder prefix is 33333/sequenceStore/44444/readSet/
                    seq_store_access_point, seq_store_id, folder_prefix = file_path_prefix.split('/', 2)
                    bucket_name = seq_store_access_point + '/' + seq_store_id
                    folder_prefix = folder_prefix
                else:
                    # s3 based bucket
                    bucket_name, folder_prefix = file_path_prefix.split('/', 1)

                aws_client = AWSClient(
                    aws_access_key_id=_config['access_key_id'],
                    aws_secret_access_key=_config['secret_access_key'],
                    aws_session_token=_config['session_token'],
                    region_name=_config['region'],
                    retry_runner=self.retry_runner)
                root_folder_cache[key] = aws_client, bucket_name, folder_prefix

            _object_key = folder_prefix + file_relpath
            presign_callers.append(aws_client.presign_file)
            presign_jobs.append({
                'bucket_name': bucket_name,
                'object_key': _object_key,
            })

        # turn off concurrency runner level retry as aws_client.upload_file() contains retry logic
        concurr_runner = ConcurrencyRunner(
            retry_runner=RetryRunner(max_retries=0), max_workers=max_workers)

        logging.info(
            f'Presigning {len(presign_jobs)} ICA files')

        results = concurr_runner.run(
            funcs=presign_callers, kwargs_list=presign_jobs)
        concurr_runner.shutdown()
        logging.info(
            f'Successfully Presigned {len(presign_jobs)} ICA files')

        out_dict = dict()
        for ica_url, presign_result in zip(ica_url_list, results):
            out_dict[ica_url] = presign_result

        return out_dict


def json_to_b64str(data_dict: dict) -> str:
    return base64.b64encode(json.dumps(data_dict).encode('utf-8')).decode('utf-8')


def b64str_to_json(data_str: str) -> dict:
    return json.loads(base64.b64decode(data_str.encode('utf-8')).decode('utf-8'))


def get_unique_id(use_timestamp=False, length=14) -> str:
    if use_timestamp:
        # max length = 20, e.g. 2022 0110 195730 538956
        uid = datetime.datetime.now(
            datetime.timezone.utc).strftime('%Y%m%d%H%M%S%f')
    else:
        # max length = 32
        uid = str(uuid.uuid4()).replace('-', '')

    if length > 0:
        return uid[:length]
    return uid


def get_package_name():
    return f'popgen-cli'


def get_package_version():
    """Get the package version."""
    return __version__.__git_version__

def is_aws_ec2(endpoint='169.254.169.254'):
    # dragen use this endpoint to determine whether to further check /opt/instance-identity folder
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", endpoint], stderr=subprocess.STDOUT)
        logging.info(f'This is an AWS EC2 instance')
        return True
    except subprocess.CalledProcessError:
        logging.info(f'This is not an AWS EC2 instance')
        return False


class ICAConfig:
    """Q&A to set up ICA workflow (dragen-igg or dragen-mlr)
    """

    default_ica_server_url = 'ica.illumina.com'
    max_tries_on_user_error = 3

    supported_workflow_names = {
        'dragen-igg',
        'dragen-mlr',
    }

    supported_ica_aws_region_map = {
        'US': ['us-east-1', 'use1'],  # N. Virginia
        'CA': ['ca-central-1', 'cac1'],  # Canada
        'GB': ['eu-west-2', 'euw2'],  # London
        'EU': ['eu-central-1', 'euc1'],  # Frankfurt
        'AU': ['ap-southeast-2', 'apse2'],  # Sydney
        'SG': ['ap-southeast-1', 'apse1'],  # Singapore
        'KR': ['ap-northeast-2', 'apne2'],  # Seoul
        'JP': ['ap-northeast-1', 'apne1'],  # Tokyo
        'IN': ['ap-south-1', 'aps1'],  # Mumbai
        'ID': ['ap-southeast-3', 'apse3'],  # Jakarta
        'AE': ['me-central-1', 'mec1'],  # UAE
        'IL': ['il-central-1', 'ilc1'],  # Tel Aviv
    }

    def __init__(self, workflow_name, dragen_version_list) -> None:

        if workflow_name not in self.supported_workflow_names:
            raise Exception(
                f'*ERROR* workflow name "{self.workflow_name}" is not supported.')
        self.workflow_name = workflow_name
        self.dragen_version_list = dragen_version_list

        # self.max_tries_on_user_error = 3
        # self.default_ica_server_url = 'ica.illumina.com'

        # self.default_dragen_sw_license_server = 'license.edicogenome.com'
        # self.default_dragen_sw_license_username = None
        # self.default_dragen_sw_license_password = None

        # disable dragen sw license requirements (for ICA user they shard build in license)
        # self.dragen_sw_license_server = self.default_dragen_sw_license_server
        # self.dragen_sw_license_username = self.default_dragen_sw_license_username
        # self.dragen_sw_license_password = self.default_dragen_sw_license_password

        # self.ica_retry_runner = utils.RetryRunner(
        #     exceptions=[icav2_utils.RetriableException],
        #     tries=7, delay=7, max_delay=30, backoff=1.2)

        # # needed for output folder upload, regardless ICA or AWS
        # self.aws_retry_runner = utils.RetryRunner(
        #     exceptions=[aws_utils.RetriableException,
        #                 requests.exceptions.ConnectionError],
        #     tries=7, delay=7, max_delay=30, backoff=1.2)

        self.ica_client = None
        self.config_id = get_unique_id(use_timestamp=True)
        self.config_file_basename = f'project-config.{self.config_id}.json'
        self.config_file_project_path = f'/meta/secret/{self.config_file_basename}'
        self.config_file_local_path = f'project-data/secret/{self.config_file_basename}'

        self.ica_api_key = None
        self.enable_byob = None
        self.ica_region = None
        self.ica_storage_bundle = None
        self.ica_storage_configuration = None
        self.ica_job_project = None
        self.ica_job_project_meta_folder = None
        self.ica_job_project_jobs_folder = None
        self.ica_job_project_config_file = None
        self.ica_analysis_storage = None
        self.ica_analysis_docker_image = None
        self.ica_analysis_pipeline = None
        self.ica_analysis_activation_code = None

    def to_json(self):
        return {
            'ica_api_key': self.ica_api_key,
            'enable_byob': self.enable_byob,
            'ica_region': self.ica_region,
            'ica_storage_bundle': self.ica_storage_bundle,
            'ica_storage_configuration': self.ica_storage_configuration,
            'ica_job_project': self.ica_job_project,
            'ica_job_project_meta_folder': self.ica_job_project_meta_folder,
            'ica_job_project_jobs_folder': self.ica_job_project_jobs_folder,
            'ica_job_project_config_file': self.ica_job_project_config_file,
            'ica_analysis_storage': self.ica_analysis_storage,
            'ica_analysis_docker_image': self.ica_analysis_docker_image,
            'ica_analysis_pipeline': self.ica_analysis_pipeline,
            'ica_analysis_activation_code': self.ica_analysis_activation_code,
        }

    def run(self):

        self.config_ica_credentials()
        print()

        self.config_ica_region()
        print()

        self.config_ica_byob()
        print()

        self.config_ica_storage_bundle()
        print()

        self.config_ica_storage_configuration()
        print()

        self.config_ica_project()
        print()

        self.config_ica_project_folders()
        print()

        self.config_ica_analysis_storage()
        print()

        self.config_ica_analysis_pipeline()
        print()

        self.config_ica_activation_code()
        print()

        self.save_upload_project_config()
        print()

    def config_ica_credentials(self):

        ica_server_url = input(
            f'ICA server URL [default: {self.default_ica_server_url}]: ')

        if ica_server_url == '':
            ica_server_url = self.default_ica_server_url
        elif ica_server_url.startswith('https://'):
            ica_server_url = ica_server_url[len('https://'):]
        elif ica_server_url.startswith('http://'):
            ica_server_url = ica_server_url[len('http://'):]

        self.ica_api_key = getpass.getpass(
            f'ICA API key (input will not display): ')
        # remove preceeding and trailing space
        self.ica_api_key = self.ica_api_key.strip()
        # TODO: change this back after testing!
        # self.ica_api_key = read_json(
        #     f'{os.path.dirname(__file__)}/test/secret.popgen.json')['ica_api_key']
        if self.ica_api_key == '':
            exit(f'*ERROR* ICA API key is empty.')

        retry_runner = RetryRunner()
        base_url = f'https://{ica_server_url}/ica/rest/api'
        self.ica_client = ICAClient(
            api_key=self.ica_api_key, base_url=base_url, retry_runner=retry_runner)

    def config_ica_region(self):

        print(f'Checking regions available to your ICA subscription ...')
        ica_region_details_list = self.ica_client.get_regions()

        if len(ica_region_details_list) == 0:
            exit(f'*ERROR* No region is found in your ICA subscription, '
                 f'please contact ICA team for support.')

        # filter regions with PopGen CLI support
        ica_region_details_list = [
            x for x in ica_region_details_list
            if x['code'] in self.supported_ica_aws_region_map]

        if len(ica_region_details_list) == 0:
            exit(f'*ERROR* PopGen CLI is not deployed in your subscribed regions, '
                 f'please contact ICA team for support.')

        # let user choose a region
        choice_message_list = "\n".join(
            [f'[{i+1}] {x["code"]} ({x["country"]["name"]})'
             for i, x in enumerate(ica_region_details_list)])
        choice_index_list = [
            i+1 for i in range(len(ica_region_details_list))]

        prompt = (
            f'Choose a region with a number in {choice_index_list}:\n'
            f'{choice_message_list}\n'
            f'\n'
            f'    HELP: All the input, output data and compute will be in the same region.\n'
            f'    You will need subscription and entitlements (see below) in the same region.\n'
            f'    Please contact ICA team for support.\n'
            f'\n'
            f'Selection: '
        )

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    self.ica_region = ica_region_details_list[choice_index-1]
                    return
                print(f'Please make sure the selection is within range {choice_index_list}'
                      f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.ica_region == None:
            exit(f'*ERROR* Failed to configure ICA region.')

    def config_ica_byob(self):

        print(f'Checking storage provider options ...')
        choice_index_list = [1, 2]
        prompt = (
            f'Choose your storage provider with a number in {choice_index_list}:\n'
            f'[1] ICA  = input/output data in ICA (recommended)\n'
            f'[2] BYOB = input/output data in the cloud storage that you manage (Bring-Your-Own-Bucket)\n'
            f'\n'
            f'    HELP: If you choose BYOB, and DO NOT have a storage configuration yet,\n'
            f'    STOP and create storage credentials and a storage configuration from ICA Web UI, \n'
            f'    then retry this config command. For more details, please see\n'
            f'    https://help.ica.illumina.com/home/h-storage/s-awss3 \n'
            f'    or contact ICA team for support.\n'
            f'\n'
            f'Selection: ')

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    if choice_index == 2:
                        self.enable_byob = True
                    else:
                        self.enable_byob = False
                    break
                else:
                    print(f'Please make sure the selection is within range {choice_index_list}'
                          f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.enable_byob == None:
            exit(f'*ERROR* Failed to determine whether BYOB is needed.')

    def config_ica_storage_bundle(self):

        print(f'Checking storage bundle available to your ICA subscription ...')
        ica_storage_bundle_list = self.ica_client.get_storage_bundles()

        if len(ica_storage_bundle_list) == 0:
            exit(f'*ERROR* No storage bundle is found in your ICA subscription, '
                 f'please contact ICA team for support.')

        # filter by region
        ica_storage_bundle_list = [
            x for x in ica_storage_bundle_list
            if x['region']['id'] == self.ica_region['id']]

        if len(ica_storage_bundle_list) == 0:
            exit(f'*ERROR* No storage bundle is found in your ICA subscription '
                 f'in region "{self.ica_region["code"]}", '
                 f'please contact ICA team for support.')

        # filter by byob
        if self.enable_byob:
            ica_storage_bundle_list = [
                x for x in ica_storage_bundle_list
                if x['bundleName'].startswith('ICA_Ent-')]

        if len(ica_storage_bundle_list) == 0:
            exit(f'*ERROR* You chose to use BYOB feature, but no Enterprise storage bundle '
                 f'with name starting with "ICA_Ent-" '
                 f'is found in your ICA subscription in region "{self.ica_region["code"]}", '
                 f'please contact ICA team for support.')

        # let user choose a storage bundle
        choice_message_list = "\n".join(
            [f'[{i+1}] {x["bundleName"]}'
             for i, x in enumerate(ica_storage_bundle_list)])
        choice_index_list = [
            i+1 for i in range(len(ica_storage_bundle_list))]

        prompt = (
            f'Choose a storage bundle with a number in {choice_index_list}:\n'
            f'{choice_message_list}\n'
            f'\n'
            f'    HELP: If you use Bring-Your-Own-Bucket feature, you should choose a\n'
            f'    storage bundle with "Enterprise" entitlement (name starting with "ICA-Ent-")\n'
            f'    NOT a "Basic" entitlement.\n'
            f'    Please contact ICA team for support.\n'
            f'\n'
            f'Selection: '
        )

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    self.ica_storage_bundle = ica_storage_bundle_list[choice_index-1]
                    return
                print(f'Please make sure the selection is within range {choice_index_list}'
                      f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.ica_storage_bundle == None:
            exit(f'*ERROR* Failed to configure ICA storage bundle.')

    def config_ica_storage_configuration(self):

        if self.enable_byob == False:
            self.ica_storage_configuration = None
            return

        print(f'Checking storage configurations in your ICA subscription (required by BYOB) ...')
        ica_storage_configuration_list = self.ica_client.get_storage_configurations()

        # filter by region
        ica_storage_configuration_list = [
            x for x in ica_storage_configuration_list
            if x['region']['id'] == self.ica_region['id']]

        if len(ica_storage_configuration_list) == 0:
            exit(f'*ERROR* No storage configuration is found in your ICA subscription '
                 f'in region "{self.ica_region["code"]}", '
                 f'please contact ICA team for support.')

        # filter by status
        ica_storage_configuration_list = [
            x for x in ica_storage_configuration_list
            if x['status'] == 'OK']

        if len(ica_storage_configuration_list) == 0:
            exit(f'*ERROR* No storage configuration with status "OK" is found in your ICA subscription '
                 f'in region "{self.ica_region["code"]}", '
                 f'please contact ICA team for support.')

        # let user choose a storage configuration
        choice_message_list = "\n".join(
            [f'[{i+1}] {x["name"]}\n    provider: {x["type"]}\n    details: {x["storageConfigurationDetails"]}'
             for i, x in enumerate(ica_storage_configuration_list)])
        choice_index_list = [
            i+1 for i in range(len(ica_storage_configuration_list))]

        prompt = (
            f'Choose a storage configuration with a number in {choice_index_list}:\n'
            f'{choice_message_list}\n'
            f'\n'
            f'    HELP: If the storage provider, bucket name, key prefix are not what you expected,\n'
            f'    STOP and create a storage configuration with the correct setting\n'
            f'    then retry this config command. For more details, please see\n'
            f'    https://help.ica.illumina.com/home/h-storage/s-awss3 \n'
            f'\n'
            f'Selection: '
        )

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    self.ica_storage_configuration = ica_storage_configuration_list[choice_index-1]
                    return
                print(f'Please make sure the selection is within range {choice_index_list}'
                      f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.ica_storage_configuration == None:
            exit(f'*ERROR* Failed to configure ICA storage configuration.')

    def config_ica_project(self):

        print(
            f'Creating job project (in which you configure workflow and run analyses) ...')

        def _name_is_valid(name):

            supporetd_chars = string.ascii_lowercase + string.digits + '-'
            if len(name) < 8 or len(name) > 64:
                return False, 'project name is shorter than 8 chars or longer than 64 chars'
            if not name.endswith("-jobs"):
                return False, f'project name "{name}" does not end with "-jobs"'
            if name[0] not in string.ascii_lowercase:
                return False, f'project name "{name}" does not start with a lowercase letter'
            for c in name:
                if c not in supporetd_chars:
                    return False, f'char "{c}" in "{name}" is not supported'
            return True, ''

        # e.g. use1
        region_prefix = self.supported_ica_aws_region_map[self.ica_region['code']][1]
        timestamp = get_unique_id(use_timestamp=True)
        suggested_name = f'{region_prefix}-{self.workflow_name}-{timestamp}-jobs'
        prompt = (
            f'Let us create a job project (or use an existing one)\n'
            f'For better management of projects, please follow these naming conventions:\n'
            f'  - project name should start with a *lower* case char (a-z).\n'
            f'  - project name should end with "-jobs".\n'
            f'  - project name should only consist of *lower* case chars (a-z), digits (0-9) and dash (-)\n'
            f'  - project name length should be wihtin 8-64 characters\n'
            f'\n'
            f'The name of job project to create [default: {suggested_name}]: '
        )

        job_project_name = None
        for try_index in range(self.max_tries_on_user_error):
            job_project_name = input(prompt)
            if job_project_name == '':
                job_project_name = suggested_name
            else:
                job_project_name = job_project_name.strip()
                name_is_valid, reason = _name_is_valid(job_project_name)

                if not name_is_valid:
                    print(
                        f'Job project name "{job_project_name}" is invalid: {reason}. '
                        f'Please try a different name '
                        f'({self.max_tries_on_user_error-1-try_index} retries remaining)\n')
                    continue

            print()

            # check if project name exists
            print(
                f'Checking if project with name "{job_project_name}" already exists ...')

            job_project_details = self.ica_client.get_project(
                project_name=job_project_name)

            if job_project_details == None:

                print(
                    f'Project name "{job_project_name}" is unique, create the project now ...')

                # job project is always non-BYOB
                self.ica_job_project = self.ica_client.get_or_create_project(
                    project_name=job_project_name,
                    region_name=self.ica_region['code'],
                    storage_bundle_name=self.ica_storage_bundle['bundleName'],
                    storage_configuration_name=None)

                if self.ica_job_project != None:
                    print(
                        f'Project name "{job_project_name}" is created, '
                        f'project id = "{self.ica_job_project["id"]}"')
                    break

            else:

                print(f'Project name "{job_project_name}" already exists')

                # let user choose to reuse existing job project or create a new job project
                choice_index_list = [1, 2]
                prompt2 = (
                    f'Do you want to re-use existing projects or create new projects?\n'
                    f'[1] Re-use existing projects (e.g. you want to update pipeline)\n'
                    f'[2] Try again to create new projects\n'
                    f'\n'
                    f'    HELP: If you choose [1] existing project, you will take the region, BYOB,\n'
                    f'    storage bundle, storage configuration settings of the existing project,\n'
                    f'    but you can deploy new pipeline to this existing project.\n'
                    f'    Otherwise, choose [2] and create a new project with a different name.\n'
                    f'\n'
                    f'Selection: '
                )
                try:
                    choice_index = int(input(prompt2))
                    if choice_index in choice_index_list:
                        if choice_index == 2:
                            print(f'\nTry again to create a project with a unique name '
                                  f'({self.max_tries_on_user_error-1-try_index} retries remaining)\n')
                            continue
                        else:
                            self.ica_job_project = job_project_details
                            return
                    print(f'Please make sure the selection is within range {choice_index_list}'
                          f' ({self.max_tries_on_user_error-1-try_index} retries remaining)\n')
                except:
                    continue

        if self.ica_job_project == None:
            exit(f'*ERROR* Failed to configure ICA job project.')

    def config_ica_project_folders(self):

        print(
            f'Create or get "meta" and "jobs" folders, in job project "{self.ica_job_project["name"]}" ...')

        self.ica_job_project_meta_folder = self.ica_client.get_or_create_project_data(
            project_name=self.ica_job_project['name'],
            region_name=self.ica_region['code'],
            storage_bundle_name=self.ica_storage_bundle['bundleName'],
            project_data_path='/meta/',
            project_data_type='FOLDER',
            storage_configuration_name=None)

        if self.ica_job_project_meta_folder == None:
            exit(
                f'*ERROR* Failed to create "meta" folder in job project "{self.ica_job_project["name"]}".')

        self.ica_job_project_jobs_folder = self.ica_client.get_or_create_project_data(
            project_name=self.ica_job_project['name'],
            region_name=self.ica_region['code'],
            storage_bundle_name=self.ica_storage_bundle['bundleName'],
            project_data_path='/jobs/',
            project_data_type='FOLDER',
            storage_configuration_name=None)

        if self.ica_job_project_jobs_folder == None:
            exit(
                f'*ERROR* Failed to create "jobs" folder in job project "{self.ica_job_project["name"]}".')

    def config_ica_analysis_storage(self):

        print(f'Checking analysis storage options (and choose the option with lowest cost) ...')
        ica_analysis_storage_list = self.ica_client.get_analysis_storages(
            project_name=self.ica_job_project['name'])

        if ica_analysis_storage_list == None or len(ica_analysis_storage_list) == 0:
            exit(f'*ERROR* No analysis storage is found in project "{self.ica_job_project["name"]}", '
                 f'please contact ICA team for support.')

        choice_message_list = "\n".join(
            [f'[{i+1}] {x["name"]} ({x["description"]})'
             for i, x in enumerate(ica_analysis_storage_list)])
        choice_index_list = [
            i+1 for i in range(len(ica_analysis_storage_list))]
        prompt = (
            f'Choose an analysis storage option with a number in {choice_index_list}:\n'
            f'{choice_message_list}\n'
            f'\n'
            f'    HELP: It is recommended to use "Small" for cost saving.\n'
            f'\n'
            f'Selection: ')

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    self.ica_analysis_storage = ica_analysis_storage_list[choice_index-1]
                    return
                print(f'Please make sure the selection is within range {choice_index_list}'
                      f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.ica_analysis_storage == None:
            exit(f'*ERROR* Failed to configure ICA analysis storage.')

    def config_ica_analysis_pipeline(self):

        docker_ecr_region = self.supported_ica_aws_region_map[self.ica_region["code"]][0]
        docker_image_name = (
            f'699120554104.dkr.ecr.{docker_ecr_region}.amazonaws.com'
            f'/public/popgen/popgen-{self.workflow_name}')

        docker_image_tag = __version__.__docker_tag__
        # released_image_tags = '\n'.join(
        #     [f'- {x}' for x in self.workflow_version_list])

        # prompt = (
        #     f'Configure the docker image tag ...\n'
        #     f'Available Images:\n'
        #     f'{released_image_tags}\n'
        #     f'\n'
        #     f'    HELP: supported image tag format:\n'
        #     f'    - released images:   "v<cli-version>-d<dragen-version>"\n'
        #     f'    - internal images:   X.Y.Z[.postN.g<hash>]\n'
        #     f'\n'
        #     f'Select the tag of docker image to use: ')

        # for try_index in range(self.max_tries_on_user_error):
        #     try:
        #         docker_image_tag = input(prompt)
        #         if len(docker_image_tag) >= 5 or docker_image_tag in self.workflow_version_list:
        #             break
        #         print(
        #             f'Please make sure the image tag follows the format suggested, found "{docker_image_tag}"'
        #             f' ({self.max_tries_on_user_error-1-try_index} retries remaining)\n')
        #     except:
        #         continue

        # if docker_image_tag == '' or docker_image_tag == None:
        #     exit(f'*ERROR* Failed to configure docker image tag.')

        self.ica_analysis_docker_image = docker_image_name + ':' + docker_image_tag

        # ICA CP does not like dot in the pipeline code name, need to change it to dash
        # ICA CP promotes project pipeline name to be global so that two projects can not use the same
        # pipeline name unless they are linked and source project need to set to share, this introduces
        # binding between target and source project (change has to be sync-ed between now and past, and
        # the name you give today will consume names in the future)
        # so, we add project name to the pipeline name, so that the pipeline in the project does not
        # conflict with pipelines in another project
        pipeline_name = self.workflow_name + '-' + \
            docker_image_tag + '-' + self.ica_job_project['name']
        pipeline_name = pipeline_name.replace('.', '-').replace('_', '-')

        print(
            f'\nCreating/Getting DRAGEN PopGen pipeline "{pipeline_name}" ...')

        # e.g. src/popgen_cli/dragen_igg/workflow
        workflow_template_folder = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        workflow_template_folder += f'/{self.workflow_name.replace("-","_")}/workflow'
        internal_workflow_cwl = f'{workflow_template_folder}/workflow.cwl'
        internal_config_xml = f'{workflow_template_folder}/config.xml'

        temp_workflow_cwl_path = os.path.realpath(
            f'tmp.{self.workflow_name}.workflow.cwl')
        with open(temp_workflow_cwl_path, 'wt') as fout:
            workflow_text = open(internal_workflow_cwl).read()
            workflow_text = workflow_text.replace(
                '__PIPELINE_DOCKER_IMAGE__', self.ica_analysis_docker_image)
            print(workflow_text, file=fout)
        self.ica_analysis_pipeline = self.ica_client.get_or_create_cwl_pipeline(
            project_name=self.ica_job_project['name'],
            pipeline_name=pipeline_name,
            analysis_storage_name=self.ica_analysis_storage['name'],
            cwl_workflow_path=temp_workflow_cwl_path,
            config_xml_path=internal_config_xml,
            cwl_tool_path_list=[])
        run_command(f'rm -fr {temp_workflow_cwl_path}')

        if self.ica_analysis_pipeline == None:
            exit(f'*ERROR* Failed to configure analysis pipeline')

    def config_ica_activation_code(self):

        project_name = self.ica_job_project['name']
        pipeline_name = self.ica_analysis_pipeline['pipeline']['code']
        analysis_storage_name = self.ica_analysis_storage["name"]
        print(f'Checking activation code for pipeline "{pipeline_name}"')

        ica_activation_code_list = self.ica_client.get_cwl_activation_codes(
            project_name=project_name,
            pipeline_name=pipeline_name)

        if len(ica_activation_code_list) == 0:
            exit(
                f'*ERROR* Can not find entitled activation code for pipeline "{pipeline_name}" '
                f'that matches analysis storage name "{analysis_storage_name}". '
                f'Please contact ICA team for support.')

        choice_message_list = "\n".join(
            [f'[{i+1}] {x["pipelineBundle"]["name"]}'
             for i, x in enumerate(ica_activation_code_list)])
        choice_index_list = [
            i+1 for i in range(len(ica_activation_code_list))]
        prompt = (
            f'Choose an activation code with a number in {choice_index_list}: \n'
            f'{choice_message_list}\n'
            f'\n'
            f'    HELP: Between "ICA_Basic" and "ICA_Ent", select "ICA_Ent" ("Enterprise").\n'
            f'\n'
            f'Selection: '
        )

        for i in range(self.max_tries_on_user_error):
            try:
                choice_index = int(input(prompt))
                if choice_index in choice_index_list:
                    self.ica_analysis_activation_code = ica_activation_code_list[choice_index-1]
                    return
                print(f'Please make sure the selection is within range {choice_index_list}'
                      f' ({self.max_tries_on_user_error-1-i} retries remaining)\n')
            except:
                continue

        if self.ica_analysis_activation_code == None:
            exit(f'*ERROR* Failed to configure ICA analysis activation code.')

    def save_upload_project_config(self):

        print(f'Creating config file in "{self.config_file_project_path}" in '
              f'job project "{self.ica_job_project["name"]}", and save locally.')

        self.ica_job_project_config_file = self.ica_client.get_or_create_project_data(
            project_name=self.ica_job_project['name'],
            project_data_path=self.config_file_project_path,
            project_data_type='FILE',
            region_name=self.ica_region['code'],
            storage_bundle_name=self.ica_storage_bundle['bundleName'],
            storage_configuration_name=None)

        if self.ica_job_project_config_file == None:
            exit(
                f'*ERROR* Failed to create config file "{self.config_file_project_path}" '
                f'in job project "{self.ica_job_project["name"]}".')

        # write local config file
        tmp_config_dir = f'tmp.{self.config_id}'
        tmp_config_file = f'{tmp_config_dir}/{self.config_file_basename}'
        config_dict = self.to_json()
        write_json(config_dict, tmp_config_file, indent=2)

        # first time upload (status is still PARTIAL)
        uploader = ICAUploader(self.ica_client)
        ica_config_dir = f'ica://{self.ica_job_project["name"]}{os.path.dirname(self.config_file_project_path)}/'
        uploader.upload(
            local_dir=tmp_config_dir,
            ica_url=ica_config_dir,
            region_name=self.ica_region['code'],
            storage_bundle_name=self.ica_storage_bundle['bundleName'],
            storage_configuration_name=None)

        # wait until status is not PARTIAL
        while True:

            key = f'{self.ica_job_project["name"]}:{self.config_file_project_path}:FILE'
            self.ica_client._drop_cache('project_data', key)

            self.ica_job_project_config_file = self.ica_client.get_project_data(
                project_name=self.ica_job_project['name'],
                project_data_path=self.config_file_project_path,
                project_data_type='FILE')

            if self.ica_job_project_config_file == None:
                exit(
                    f'*ERROR* Failed to get config file "{self.config_file_project_path}" '
                    f'in job project "{self.ica_job_project["name"]}".')

            # print(self.ica_job_project_config_file)
            if self.ica_job_project_config_file['data']['details']['status'] == 'AVAILABLE':
                break

            logging.warning(
                f'Waiting for status of uploaded config file "{self.config_file_project_path}" '
                f'to become "AVAILABLE", current status: '
                f'"{self.ica_job_project_config_file["data"]["details"]["status"]}"')
            time.sleep(3)

        # write local config file again
        tmp_config_dir = f'tmp.{self.config_id}'
        tmp_config_file = f'{tmp_config_dir}/{self.config_file_basename}'
        config_dict = self.to_json()
        write_json(config_dict, tmp_config_file, indent=2)

        # second time upload (status is available)
        uploader = ICAUploader(self.ica_client)
        ica_config_dir = f'ica://{self.ica_job_project["name"]}{os.path.dirname(self.config_file_project_path)}/'
        uploader.upload(
            local_dir=tmp_config_dir,
            ica_url=ica_config_dir,
            region_name=self.ica_region['code'],
            storage_bundle_name=self.ica_storage_bundle['bundleName'],
            storage_configuration_name=None)

        prep_output_file(self.config_file_local_path)
        run_command(f'mv {tmp_config_file} {self.config_file_local_path}')
        run_command(f'rm -fr {tmp_config_dir}')

        print(
            f'\nAll configuration is uploaded to project file '
            f'"ica://{self.ica_job_project["name"]}{self.config_file_project_path}"')
        print(
            f'All configuration is saved to local file '
            f'"{self.config_file_local_path}"')

        print(
            f'\nPopGen workflow "{self.workflow_name}" configuration is done!')


def parser_add_arg(parser, dest, help, **kwargs):

    # Convert dest to a hyphenated option name to avoid repeat arg name twice once with - once with _
    option_name = f"--{dest.replace('_', '-')}"
    if 'default' in kwargs:
        help.append(f'[default: "{kwargs["default"]}"]')
    help = '\n'.join(help) + '\n '
    parser.add_argument(option_name, dest=dest, help=help, **kwargs)


def parse_int_range_str(int_range_str: str) -> list:
    # 1-2,2,34,5
    output_set = set()
    for x in int_range_str.split(','):
        if '-' in x:
            y = x.split('-')
            if len(y) != 2 or not y[0].isdigit() or not y[1].isdigit():
                raise Exception(
                    f'Failed to parse range "{x}" in number range str {int_range_str}')
            istart = int(y[0])
            iend = int(y[1])
            if istart > iend:
                raise Exception(
                    f'Failed to parse range "{x}" in number range str {int_range_str}')
            for i in range(istart, iend+1):
                output_set.add(i)
        else:
            if not x.isdigit():
                raise Exception(
                    f'Failed to parse range "{x}" in number range str {int_range_str}')
            output_set.add(int(x))
    return sorted(output_set)


def stage_output_data(file_path_list, output_folder):
    # create md5 of file in the input list and move all files to output folder
    prep_output_folder(output_folder)

    # concurrently create md5
    concurr_runner = ConcurrencyRunner(
        retry_runner=RetryRunner(max_retries=0))
    logging.info(
        f'Creating md5sum of {len(file_path_list)} output files')

    concurr_runner.run(create_md5, kwargs_list=[
                       {'file_path': x} for x in file_path_list])
    concurr_runner.shutdown()

    # move output to staging output folder (in serial)
    for file_path in file_path_list:
        run_command(
            f'mv -v {file_path} {file_path}.md5 {output_folder}/')


def check_input_data_md5(file_path_list):
    # check md5 of files in input list (if md5 exists)

    check_list = [x + '.md5' for x in file_path_list]
    concurr_runner = ConcurrencyRunner(
        retry_runner=RetryRunner(max_retries=0))
    logging.info(
        f'Checking md5sum of {len(check_list)} input files')

    results = concurr_runner.run(check_md5, kwargs_list=[
        {'md5_file_path': x} for x in check_list])
    concurr_runner.shutdown()

    for result, md5_file in zip(results, check_list):
        if result == False:
            raise Exception(f'md5sum file "{md5_file}" check failed.')
    logging.info(
        f'md5sum check of {len(check_list)} input files is successful')


def download_using_aria2c(remote_file_url, local_file_path,
                          aria2c_path='/usr/local/bin/aria2c', max_connection=16):

    def _download_using_aria2c():

        remote_file_size = get_remote_file_size(remote_file_url)

        _locaL_dir = os.path.dirname(os.path.realpath(local_file_path))
        _local_base = os.path.basename(local_file_path)
        _local_log = local_file_path + '.aria2c.log'

        run_command(f'rm -fr {local_file_path} {_local_log}')
        prep_output_file(local_file_path)

        download_cmd = [
            f'{aria2c_path}',
            f'-x {max_connection}',
            f'"{remote_file_url}"',
            f'-d {_locaL_dir}',
            f'-o {_local_base}',
            f'-l {_local_log}',
            f'--console-log-level=error',
            f'--check-certificate=false',
        ]

        # do not show full url in log
        remote_file_url_log = remote_file_url.split('?')[0]
        download_cmd_log = [
            f'{aria2c_path}',
            f'-x {max_connection}',
            f'"{remote_file_url_log}"',
            f'-d {_locaL_dir}',
            f'-o {_local_base}',
            f'-l {_local_log}',
            f'--console-log-level=error',
            f'--check-certificate=false',
        ]

        ecode = run_command(command=download_cmd, command_log=download_cmd_log)
        if ecode:
            raise Exception(f'aria2c exits with ecode: {ecode}')

        local_file_size = get_local_file_size(local_file_path)
        if local_file_size != remote_file_size:
            raise Exception(
                f'aria2c download size mismatch: remote={remote_file_size} local={local_file_size}')

        run_command(f'rm -fr {_local_log}')

    return RetryRunner().run(func=_download_using_aria2c)
