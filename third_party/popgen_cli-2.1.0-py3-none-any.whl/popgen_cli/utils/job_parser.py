import popgen_cli.utils.utils as utils
import argparse
import json


def parse_args():

    usage = f"""
  job-parser [args]

description:
  encode/decode job definition

"""
    parser = argparse.ArgumentParser(usage=usage, formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument('--mode', required=True,
                        help='encode or decode [required]')

    parser.add_argument('--job-def-str', required=True,
                        help='Job definition string encoded/decoded [required]')

    parser.add_argument('-v', '--version', action='version',
                        version=f'Version: {utils.get_package_version()}')

    return parser.parse_args()


def main():

    utils.config_logging()
    args = parse_args()

    if args.mode not in {'encode', 'decode'}:
        print(f'*ERROR*: supported mode is "encode"/"decode", found "{args.mode}"')

    if args.mode == 'decode':
        job_def_dict = utils.b64str_to_json(args.job_def_str)
        print(json.dumps(job_def_dict))

    else:
        job_def_str = utils.json_to_b64str(json.loads(args.job_def_str))
        print(job_def_str)


if __name__ == '__main__':

    main()
